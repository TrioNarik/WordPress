<?php
return [
    'admin' => [
        'active' => 1, // Włączony/wyłączony mailing powiadomień w formularzu
        'mail' => 'office@hussaria.pl',
        'secret_key' => 'fdc91d1b8d46eda896acf7ca3da923a1',
        'path_url' => 'https://electra.hussaria.pl/order/',
        'company_name' => 'HUSSARIA Sp. z o.o.',
        'company_address' => 'ul. Kwiatkowskiego 1, 37-450 Stalowa Wola',
        'bank_name' => 'PKO BP',
        'bank_account' => '48 1020 4939 0000 0402 0092 9224',
        'prepayment_period' => 7, // Termin płatności przedpłaty
        'office_phone' => '+48 535 207 881',
        'office_email' => 'office@hussaria.pl'
    ]
];
