<?php
// Załaduj konfigurację admina (zawiera secret_key)
$admin_config = require '../config_admin.php';

// Plik zamówień
$file = '../orders.txt';

// Funkcja deszyfrowania
function decryptData($data, $key) {
    $data = base64_decode($data); // Dekodowanie z Base64
    $ivLength = openssl_cipher_iv_length('AES-128-CBC'); // Długość IV
    $iv = substr($data, 0, $ivLength); // Pobierz IV z początku danych
    $encrypted = substr($data, $ivLength); // Pobierz zaszyfrowane dane
    return openssl_decrypt($encrypted, 'AES-128-CBC', $key, 0, $iv); // Odszyfrowanie danych
}

// Wczytaj plik zamówień
if (!file_exists($file)) {
    die("Plik zamówień nie istnieje.");
}

$orders = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$orders) {
    die("Brak zamówień do wyświetlenia.");
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statystyki - Hussaria Electra</title>
    <link rel="icon" href="../img/hussaria-electra-100x100.png" sizes="32x32">
</head>
<body>
<style type="text/css">
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    body {
        color: #000;
        background:#e1e1e1;
    }
    section {
        margin: 20px auto;
        padding: 20px;
        width: 80%;
        background: #fff;
        border-radius: 10px;
    }
    ul {
        margin: 10px;
        padding: 10px;
        list-style-position: inside;
    }
    li {
        padding: 5px;
        color: #707070;
    }
    .price {
        color: #000;
        padding: 5px;
        background: #f3f3f3;
        border-radius: 5px;
    }
    .prepayment {
        font-size: 1.2rem;
        color: #b11800;
    }
    .total {
        font-weight: bold;
        font-size: 1.5rem;
    }
    h4 {
        margin: .5rem 0;
        padding: .5rem;
        background: #d7def5;
    }
    p {
        padding: 5px;
    }
    .wait,
    .done {
        color: #000000;
        padding: 2px 6px;
        border-radius: 2em;
    }
    .wait {
        background: #f2b017;
    }
    .done {
        background: #b3e9a3;
    }
    .custom {
        position: relative;
        display: inline-block;
        padding: 10px;
        background: #f7f7f7;
        border: 1px dashed #bbbbbb;
    }
    .custom::before {
        content: '';
        position: absolute;
        width: 10px;
        height: 10px;
        left: -5px;
        border-radius: 3px;
        background: #b11800;
    }
    .custom strong {
        color: #d3d3d3;
    }
</style>


<?php

foreach ($orders as $index => $encryptedOrder) {
    // Odszyfruj dane
    $decryptedOrder = decryptData($encryptedOrder, $admin_config['admin']['secret_key']);
    
    if ($decryptedOrder === false) {
        echo "<p><strong>Zamówienie $index:</strong> Nie udało się odszyfrować danych.</p>";
        continue;
    }

    // Dekodowanie JSON
    $orderData = json_decode($decryptedOrder, true);

    if ($orderData === null) {
        echo "<p><strong>Zamówienie $index:</strong> Nie udało się zdekodować JSON.</p>";
        continue;
    }

    // Wyświetlenie zamówienia
    echo "<section>";
    echo "<h4>ID {$index}: <small style='font-size:15px; color:#007683; font-weight:400'>[{$orderData['timestamp']}]</small></h4>";

    echo "<p><strong>Imię/Nazwa firmy:</strong> {$orderData['name']}</p>";
    echo "<p><strong>Nazwisko/NIP:</strong> {$orderData['company']}</p>";
    echo "<p><strong>E-mail:</strong> {$orderData['email']}</p>";
    echo "<p><strong>Telefon:</strong> {$orderData['phone']}</p>";
    
    echo "<p><strong>Adres:</strong> {$orderData['street']} {$orderData['postCode']} {$orderData['city']} {$orderData['country']}</p>";
    echo "<p><strong>Adres wysyłki:</strong> {$orderData['shippingStreet']} {$orderData['shippingPostCode']} {$orderData['shippingCity']} {$orderData['shippingCountry']}</p>";


    echo "<p><strong>Produkty:</strong></p>";
    echo "<ul>";
    foreach ($orderData['products'] as $product => $price) {
        echo "<li>{$product}: <span class='price'>{$price}</span> PLN</li>";
    }
    echo "</ul>";
    echo "<p class='custom'><strong>Uwagi:</strong> {$orderData['customization']}</p>";
    echo "<p><strong>Łączna wartość zamówienia:</strong> <span class='total'>{$orderData['total']}</span> PLN</p>";

    echo "<p><strong>Kwota przedpłaty:</strong> <span class='prepayment'>{$orderData['prepaymentCount']}</span> PLN</p>";
    echo "<p><strong>Przedpłata:</strong> {$orderData['prepaymentMode']}</p>";
    echo "<p><strong>Status przedpłaty:</strong> <span class='{$orderData['prepaymentClass']}'>{$orderData['prepaymentStatus']}</span> {$orderData['paymentDeadlineText']} {$orderData['paymentDeadline']}</p>";
    echo "<hr>";
    echo "<p><small>Data zamówienia: {$orderData['date']}</small></p>";
    echo "</section>";
    
}
?>


</body>
</html>