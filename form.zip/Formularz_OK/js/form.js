// =====================================================
// ================ FORMLARZ ===========================
// ===================================================== 
document.addEventListener('DOMContentLoaded', () => {
    const totalPriceEl = document.getElementById('totalPrice');
    const countPriceEl = document.getElementById('countPrice');
    const productCheckboxes = document.querySelectorAll('#products input[type="checkbox"]');
    const productPrices = document.querySelectorAll('.product-price');

    const shippingCheckbox = document.getElementById('differentShippingAddress');
    const shippingAddressField = document.getElementById('shippingAddressField');

    const prepaymentCheckbox = document.getElementById('prepayment');
    const prepaymentFields = document.getElementById('prepaymentFields');
    
    const prepaymentRadios = document.querySelectorAll('input[name="prepaymentMode"]');  // disabled input jeśli nie są zaznaczone

    const prepaymentCount = document.querySelector('input[name="prepaymentCount"]');
    const orderForm = document.getElementById('orderForm');
    const confirmationMessage = document.getElementById('confirmationMessage');

    let products = {};

    // Inicjalizacja produktów z domyślnymi cenami
    productPrices.forEach((priceInput) => {
        products[priceInput.dataset.product] = parseFloat(priceInput.value);
    });

    const updatePrices = () => {
        const total = calculateTotalPrice(products, productCheckboxes);
        totalPriceEl.textContent = formatCurrency(total);

        const prepayment = parseFloat(prepaymentCount.value.replace(',', '.')) || 0;
        const remaining = updateRemainingAmount(total, prepayment);
        countPriceEl.textContent = formatCurrency(remaining);
    };

    // Obsługa zmiany wartości produktu
    productPrices.forEach((priceInput) => {
        priceInput.addEventListener('input', () => {
            const productName = priceInput.dataset.product;
            products[productName] = parseFloat(priceInput.value) || 0;
            updatePrices();
        });
    });

    // Obsługa zaznaczenia/odznaczenia produktów
    productCheckboxes.forEach((checkbox) => {
        checkbox.addEventListener('change', updatePrices);
    });

    // Obsługa przedpłaty
    prepaymentCheckbox.addEventListener('change', () => {
        if (prepaymentCheckbox.checked) {
            prepaymentFields.classList.add('show');
        } else {
            prepaymentFields.classList.remove('show');
            prepaymentCount.value = '';
            const total = calculateTotalPrice(products, productCheckboxes);
            countPriceEl.textContent = formatCurrency(total);
        }
    });

    prepaymentCount.addEventListener('input', updatePrices);

    // =====================
    const togglePrepaymentCount = () => {
        const isChecked = Array.from(prepaymentRadios).some(radio => radio.checked);
        prepaymentCount.disabled = !isChecked; // Włącz/wyłącz input kwoty przedpłaty w zależności od zaznaczenia
    };

    // Nasłuch na zmianę stanu radio
    prepaymentRadios.forEach(radio => {
        radio.addEventListener('change', togglePrepaymentCount);
    });

    // Wywołanie funkcji na starcie, aby ustawić stan początkowy
    togglePrepaymentCount();
    // ===================

    // Obsługa zmiany adresu wysyłki
    shippingCheckbox.addEventListener('change', () => {
        shippingAddressField.classList.toggle('show', shippingCheckbox.checked);
    });

    // Obsługa wysłania formularza
    orderForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(orderForm);

        productCheckboxes.forEach((checkbox) => {
            if (checkbox.checked) {
                const productName = checkbox.value;
                const productPrice = products[productName];
                formData.append('product[]', productName);
                formData.append(`price[${productName}]`, productPrice);
            }
        });

        fetch('include/order.php', {
            method: 'POST',
            body: formData,
        })
            .then((response) => response.text())
            .then((data) => {
                confirmationMessage.style.display = 'block';
                orderForm.style.display = 'none';
            })
            .catch((error) => {
                console.error('Błąd:', error);
            });
    });
});




// =====================================================
// ================ FUNKCJE POMOCNICZE =================
// =====================================================

// Funkcja do formatowania liczby jako waluty
const formatCurrency = (value) => {
    return new Intl.NumberFormat('pl-PL', {
        style: 'currency',
        currency: 'PLN',
        minimumFractionDigits: 2
    }).format(value);
};

// Funkcja aktualizacji pozostałej kwoty
const updateRemainingAmount = (total, prepayment) => {
    const remaining = total - (prepayment || 0);
    return remaining;
};

// Funkcja aktualizacji ceny zamówienia
const calculateTotalPrice = (products, productCheckboxes) => {
    let total = 0;
    productCheckboxes.forEach((checkbox) => {
        if (checkbox.checked) {
            const productName = checkbox.value;
            total += products[productName];
        }
    });
    return total;
};