<?php
// Załaduj konfigurację mailingów i klucza szyfrującego
$email_config = require '../config_mailer.php';
$admin_config = require '../config_admin.php';

// Logi
$logFile = '../errors.log';
// Plik zamówień
$file = '../orders.txt';

// Załaduj PHPMailer
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

// Funkcja szyfrowania
function encryptData($data, $key) {
    $iv = random_bytes(openssl_cipher_iv_length('AES-128-CBC')); // Generowanie losowego IV
    $encrypted = openssl_encrypt($data, 'AES-128-CBC', $key, 0, $iv); // Szyfrowanie danych
    return base64_encode($iv . $encrypted); // Dodanie IV do zaszyfrowanych danych
}



// Obsługa formularza
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $company = htmlspecialchars($_POST['company']);
    $address = htmlspecialchars($_POST['address']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $shippingAddress = isset($_POST['shippingAddress']) ? htmlspecialchars($_POST['shippingAddress']) : $address;
    $products = $_POST['product'] ?? []; // Nazwy produktów
    $productPrices = $_POST['price'] ?? []; // Ceny produktów

    // Przygotowanie danych zamówienia
    $orderData = [
        'name' => $name,
        'company' => $company,
        'address' => $address,
        'email' => $email,
        'phone' => $phone,
        'shippingAddress' => $shippingAddress,
        'products' => [], // Przechowujemy produkty jako asocjacyjną tablicę
        'total' => array_sum($productPrices),
        'timestamp' => date('Y-m-d H:i:s'),
    ];

    // Dodajemy produkty i ich ceny do tablicy zamówienia
    foreach ($products as $product) {
        if (isset($productPrices[$product])) {
            $orderData['products'][$product] = $productPrices[$product];
        }
    }

    // Serializacja i szyfrowanie
    $orderJson = json_encode($orderData, JSON_PRETTY_PRINT);
    $encryptedOrder = encryptData($orderJson, $admin_config['admin']['secret_key']);

    // Zapis do pliku zamówień
    if (file_put_contents($file, $encryptedOrder . "\n", FILE_APPEND) === false) {
        error_log("Nie udało się zapisać zamówienia do pliku: $file\n", 3, $logFile);
        exit;
    }

    // Przygotowanie wiadomości e-mail
    $subjectAdmin = "Nowe zamówienie od $name";
    $messageAdmin = "Zamówienie od klienta:\n\nImię i nazwisko: $name\nAdres: $address\n\nProdukty:\n";

    foreach ($products as $product) {
        if (isset($productPrices[$product])) {
            $messageAdmin .= "$product - " . $productPrices[$product] . " PLN\n";
        }
    }

    $total = $orderData['total'];
    $messageAdmin .= "\nŁączna kwota: $total PLN";

    $subjectClient = 'Potwierdzenie zamówienia';
    $messageClient = "Dziękujemy za zamówienie, $name!\n\nTwoje zamówienie zawiera:\n";

    foreach ($products as $product) {
        if (isset($productPrices[$product])) {
            $messageClient .= "$product - " . $productPrices[$product] . " PLN\n";
        }
    }

    $messageClient .= "\nŁączna wartość zamówienia: $total PLN";

    // Wysyłanie e-maili (PHPMailer)
    $mail = new PHPMailer(true);
    try {
        // Konfiguracja SMTP
        $mail->isSMTP();
        $mail->Host = $email_config['smtp']['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $email_config['smtp']['username'];
        $mail->Password = $email_config['smtp']['password'];
        $mail->SMTPSecure = $email_config['smtp']['encryption'];
        $mail->Port = $email_config['smtp']['port'];

        // Mail do admina
        $mail->setFrom($email_config['smtp']['from_email'], $email_config['smtp']['from_name']);
        $mail->addAddress($admin_config['admin']['mail']);
        $mail->Subject = $subjectAdmin;
        $mail->Body = $messageAdmin;
        $mail->send();

        // Mail do klienta
        $mail->clearAddresses();
        $mail->addAddress($email);
        $mail->Subject = $subjectClient;
        $mail->Body = $messageClient;
        $mail->send();

        echo "Zamówienie przyjęte! Wartość: " . number_format($total, 2) . " PLN";
    } catch (Exception $e) {
        // Zapisz błąd w pliku logów
        error_log("Błąd przy wysyłaniu e-maili: " . $e->getMessage() . "\n", 3, $logFile);
        echo "Nie udało się wysłać wiadomości e-mail. Błąd: {$mail->ErrorInfo}";
    }
} else {
    http_response_code(405);
    // Zapisz błąd w pliku logów
    error_log("Nieprawidłowa metoda żądania - " . $_SERVER['REQUEST_METHOD'] . "\n", 3, $logFile);
    echo "Nieprawidłowa metoda żądania.";
}
