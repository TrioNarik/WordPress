<?php
// Załaduj konfigurację admina (zawiera secret_key)
$admin_config = require '../config_admin.php';

// Plik zamówień
$file = '../orders.txt';

// Funkcja deszyfrowania
function decryptData($data, $key) {
    $data = base64_decode($data); // Dekodowanie z Base64
    $ivLength = openssl_cipher_iv_length('AES-128-CBC'); // Długość IV
    $iv = substr($data, 0, $ivLength); // Pobierz IV z początku danych
    $encrypted = substr($data, $ivLength); // Pobierz zaszyfrowane dane
    return openssl_decrypt($encrypted, 'AES-128-CBC', $key, 0, $iv); // Odszyfrowanie danych
}

// Wczytaj plik zamówień
if (!file_exists($file)) {
    die("Plik zamówień nie istnieje.");
}

$orders = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

if (!$orders) {
    die("Brak zamówień do wyświetlenia.");
}

foreach ($orders as $index => $encryptedOrder) {
    // Odszyfruj dane
    $decryptedOrder = decryptData($encryptedOrder, $admin_config['admin']['secret_key']);
    
    if ($decryptedOrder === false) {
        echo "<p><strong>Zamówienie $index:</strong> Nie udało się odszyfrować danych.</p>";
        continue;
    }

    // Dekodowanie JSON
    $orderData = json_decode($decryptedOrder, true);

    if ($orderData === null) {
        echo "<p><strong>Zamówienie $index:</strong> Nie udało się zdekodować JSON.</p>";
        continue;
    }

    // Wyświetlenie zamówienia
    echo "<h2>Zamówienie {$index}:</h2>";
    echo "<p><strong>Imię i nazwisko:</strong> {$orderData['name']}</p>";
    echo "<p><strong>Firma:</strong> {$orderData['company']}</p>";
    echo "<p><strong>Adres:</strong> {$orderData['address']}</p>";
    echo "<p><strong>Email:</strong> {$orderData['email']}</p>";
    echo "<p><strong>Telefon:</strong> {$orderData['phone']}</p>";
    echo "<p><strong>Adres wysyłki:</strong> {$orderData['shippingAddress']}</p>";
    echo "<p><strong>Produkty:</strong></p>";
    echo "<ul>";
    foreach ($orderData['products'] as $product => $price) {
        echo "<li>{$product}: {$price} PLN</li>";
    }
    echo "</ul>";
    echo "<p><strong>Łączna wartość zamówienia:</strong> {$orderData['total']} PLN</p>";
    echo "<p><strong>Data zamówienia:</strong> {$orderData['timestamp']}</p>";
    echo "<hr>";
}
