document.addEventListener('DOMContentLoaded', () => {
    const totalPriceEl = document.getElementById('totalPrice');
    const countPriceEl = document.getElementById('countPrice'); // Pole "Pozostała kwota"
    const productCheckboxes = document.querySelectorAll('#products input[type="checkbox"]');
    const productPrices = document.querySelectorAll('.product-price');
    const shippingCheckbox = document.getElementById('differentShippingAddress');
    const shippingAddressField = document.getElementById('shippingAddressField');

    const prepaymentCheckbox = document.getElementById('prepayment');
    const prepaymentFields = document.getElementById('prepaymentFields');

    const prepaymentCount = document.querySelector('input[name="prepaymentCount"]'); // Przedpłata
    
    let products = {};

    // Inicjalizacja produktów z domyślnymi cenami
    productPrices.forEach(priceInput => {
        products[priceInput.dataset.product] = parseFloat(priceInput.value);
    });

    // Funkcja aktualizacji Wartości zamówienia
    const updateTotalPrice = () => {
        let total = 0;
        productCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const productName = checkbox.value;
                total += products[productName];
            }
        });
        totalPriceEl.textContent = total.toFixed();

        updateRemainingAmount(total); // Aktualizacja "Pozostała kwota"
    };


    // Funkcja aktualizacji Pozostałej kwoty
    const updateRemainingAmount = (total) => {
        const prepayment = parseFloat(prepaymentCount.value) || 0; // Jeśli pole puste, domyślnie 0
        const remaining = total - prepayment;
        countPriceEl.textContent = remaining.toFixed();
    };

    // Aktualizacja ceny produktu po zmianie wartości w polu edycji
    productPrices.forEach(priceInput => {
        priceInput.addEventListener('input', event => {
            const productName = priceInput.dataset.product;
            const newPrice = parseFloat(priceInput.value) || 0; // Jeśli pole jest puste, domyślnie 0
            products[productName] = newPrice;
            updateTotalPrice();
        });
    });

    // Aktualizacja ceny po zaznaczeniu/odznaczeniu produktu
    productCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateTotalPrice);
    });

    // Pokazywanie/ukrywanie pola adresu wysyłki
    shippingCheckbox.addEventListener('change', () => {
        if (shippingCheckbox.checked) {
            shippingAddressField.classList.add('show');
        } else {
            shippingAddressField.classList.remove('show');
        }
    });

    // Pokazywanie/ukrywanie Przedpłaty
    prepaymentCheckbox.addEventListener('change', () => {
        if (prepaymentCheckbox.checked) {
            prepaymentFields.classList.add('show');
        } else {
            prepaymentFields.classList.remove('show');
        }
    });

    // Aktualizacja Pozostałej kwoty po zmianie przedpłaty
    prepaymentCount.addEventListener('input', () => {
        const total = parseFloat(totalPriceEl.textContent) || 0;
        updateRemainingAmount(total);
    });



    // ==============================
    // Obsługa formularza
    // ==============================
    const orderForm = document.getElementById('orderForm');
    const confirmationMessage = document.getElementById('confirmationMessage');

    orderForm.addEventListener('submit', e => {
        e.preventDefault();
        const formData = new FormData(orderForm);

        // Dodajemy wybrane produkty oraz ceny do danych formularza
        productCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                const productName = checkbox.value;
                const productPrice = products[productName];
                formData.append('product[]', productName);
                formData.append('price[' + productName + ']', productPrice);
            }
        });

        // Wysyłamy formularz do serwera
        fetch('include/order.php', {
            method: 'POST',
            body: formData
        })
            .then(response => response.text())
            .then(data => {
                confirmationMessage.style.display = 'block';
                orderForm.style.display = 'none';
            })
            .catch(error => {
                console.error('Błąd:', error);
            });
    });
});
