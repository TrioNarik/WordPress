<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zamówienia - Hussaria Electra</title>
    <link rel="icon" href="img/hussaria-electra-100x100.png" sizes="32x32">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
    <nav class="navbar navbar-default">
        <div class="container">
            <div class="row py-3">
                <div class="col-6 col-md-12">
                    <a class="navbar-brand text-sm-center" href="#">
                        <img src="img/he_logo.png" alt="Hussaria Electra" class="img-fluid" />
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="container">
        
        <div class="row">
            <section class="title py-5 d-flex justify-content-center">
                <h1>Formularz zamówienia</h1>
            </section>
        </div>

        
        <form id="orderForm">
            <main>
                <h2>Dane personalne</h2>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label>
                            Imię / Nazwa firmy:
                            <input type="text" name="name" required>
                        </label>
                    </div>
                    <div class="col-12 col-md-6">
                        <label>
                            Nazwisko / Numer NIP:
                            <input type="text" name="company">
                        </label>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6">
                        <label>
                            E-mail:
                            <input type="text" name="email">
                        </label>
                    </div>
                    <div class="col-12 col-md-6">
                        <label>
                            Telefon:
                            <input type="text" name="phone">
                        </label>
                    </div>
                </div>
                
                <h2>Adres do faktury</h2>
                <div class="row">
                    <div class="col-12 col-md-6">
                        <label>
                            Ulica i numer:
                            <input type="text" name="street">
                        </label>
                    </div>
                    <div class="col-12 col-md-6">
                        <label>
                            Kod pocztowy:
                            <input type="text" name="post">
                        </label>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-md-6">
                        <label>
                            Miejscowość:
                            <input type="text" name="city">
                        </label>
                    </div>
                    <div class="col-12 col-md-6">
                        <label>
                            Kraj:
                            <input type="text" name="country" value="Polska">
                        </label>
                    </div>
                </div>

                <div class="d-flex gap-3 align-items-center">
                <h2>Adres do wysyłki</h2>
                
                    <label class="switch">
                        <input type="checkbox" id="differentShippingAddress">
                        <span class="slider round"></span>
                    </label>

                    <label class="d-none d-md-block"> Inny adres</label>
                    
                </div>

                <div id="shippingAddressField">
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <label>
                                Ulica i numer:
                                <input type="text" name="shippingStreet">
                            </label>
                        </div>
                        <div class="col-12 col-md-6">
                            <label>
                                Kod pocztowy:
                                <input type="text" name="shippingPost">
                            </label>
                        </div>
                    </div>
        
                    <div class="row">
                        <div class="col-12 col-md-6">
                            <label>
                                Miejscowość:
                                <input type="text" name="shippingCity">
                            </label>
                        </div>
                        <div class="col-12 col-md-6">
                            <label>
                                Kraj:
                                <input type="text" name="shippingCountry" value="Polska">
                            </label>
                        </div>
                    </div>
                </div>

                <h2>Szczegóły zamówienia</h2>
                <div class="row" id="products">
                    <div class="col-12 col-md-6">

                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="checkbox" name="product[]" value="Elektryczna paka" data-price="19900"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Elektryczna paka</span>
                                </div>
                                <div class="d-flex justify-content-end align-items-center gap-1">
                                    <input type="number" class="product-price" data-product="Elektryczna paka" value="19900" min="0" step="10"> PLN
                                </div>
                            </label>
                        </div>

                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="checkbox" name="product[]" value="Pokrowiec" data-price="150"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Pokrowiec</span>
                                </div>
                                <div class="d-flex justify-content-end align-items-center gap-1">
                                    <input type="number" class="product-price" data-product="Pokrowiec" value="150" min="0" step="10"> PLN
                                </div>
                            </label>
                        </div>

                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="checkbox" name="product[]" value="Personalizacja" data-price="200"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Personalizacja</span>
                                </div>
                                <div class="d-flex justify-content-end align-items-center gap-1">
                                    <input type="number" class="product-price" data-product="Personalizacja" value="200" min="0" step="10"> PLN
                                </div>
                            </label>
                        </div>

                        <div class="">
                            <label for="customer" class="form-label">Dodatkowe uwagi</label>
                            <textarea class="form-control" id="customer" rows="3"></textarea>
                        </div>

                    </div>

                    <div class="col-12 col-md-6">

                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="checkbox" name="product[]" value="Dodatkowy akumulator" data-price="800"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Dodatkowy akumulator</span>
                                </div>
                                <div class="d-flex justify-content-end align-items-center gap-1">
                                    <input type="number" class="product-price" data-product="Dodatkowy akumulator" value="800" min="0" step="10"> PLN
                                </div>
                            </label>
                        </div>

                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="checkbox" name="product[]" value="Trap załadunkowy" data-price="1500"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Trap załadunkowy</span>
                                </div>
                                <div class="d-flex justify-content-end align-items-center gap-1">
                                    <input type="number" class="product-price" data-product="Trap załadunkowy" value="1500" min="0" step="10"> PLN
                                </div>
                            </label>
                        </div>

                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="checkbox" name="product[]" value="Pokrowiec do trapa" data-price="100"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Pokrowiec do trapa</span>
                                </div>
                                <div class="d-flex justify-content-end align-items-center gap-1">
                                    <input type="number" class="product-price" data-product="Pokrowiec do trapa" value="100" min="0" step="10"> PLN
                                </div>
                            </label>
                        </div>

                    </div>
                </div>


                <div class="row align-items-center">
                    <div class="col-12 col-md-6">
                        <div class="d-flex align-items-center gap-3">
                            <h2>Płatność</h2>
                            <label class="switch">
                                <input type="checkbox" id="prepayment">
                                <span class="slider round"></span>
                            </label>
                            <span class="custom-label">Przedpłata</span>
                        </div>  
                    </div>

                    <div class="col-12 col-md-6">
                        <h4 class="text-end">Wartość zamówienia <span id="totalPrice"></span> PLN</h4>
                    </div>

                </div>

                <div class="row align-items-center" id="prepaymentFields">
                    <div class="col-12 col-md-6">
                        <div class="d-flex flex-column">
                            <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="radio" name="payment" value="Gotówka/Płatność kartą" data-time="0"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Gotówka/Płatność kartą</span>
                                </div>
                                </label>
                                <label class="circle-checkbox d-flex flex-wrap justify-content-between align-items-center">
                                <div class="d-flex justify-content-start align-items-center gap-2 flex-shrink-0">
                                    <input type="radio" name="payment" value="Przelew" data-time="7"> 
                                    <span class="custom-circle"></span>
                                    <span class="custom-label">Przelew</span>
                                </div>
                            </label>
                        </div>
                    </div>

                    <div class="col-12 col-md-6">
                        <label>
                            Kwota przedpłaty:
                            <input type="number" name="prepaymentCount" min="0">
                        </label>
                    </div>

                </div>

            </main>
            <footer>  
                <div class="row">
                    <div class="col-12">
                        <h3>Pozostała kwota do zapłaty <span id="countPrice"></span></h3>
                        <button type="submit">Zamawiam</button>
                    </div>
                </div>     
            </footer>
        </form>
        <div id="confirmationMessage" style="display: none;">Dziękujemy za zamówienie!</div>
    </div>
    <script src="js/form.js"></script>
</body>
</html>
