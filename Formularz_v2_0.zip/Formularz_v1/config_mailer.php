<?php
return [
    'smtp' => [
        'host' => 'smtp.example.com',
        'username' => 'your-email@example.com',
        'password' => 'your-email-password',
        'port' => 587,
        'encryption' => 'tls', // Możliwe: 'tls', 'ssl'
        'from_email' => 'sklep@example.com',
        'from_name' => 'Sklep'
    ]
];
