<?php
return [
    'admin' => [
        'mail' => 'admin@example.com',
        'secret_key' => 'fdc91d1b8d46eda896acf7ca3da923a1',
        'path_url' => 'https://hussariaelectra.crk2024old.cfolks.pl/form/',
        'company_name' => 'Cerkamed',
        'company_address]]' => 'Kwiatkowskiego 2, Stalowa Wola',
        'bank_name' => 'PKO BP',
        'bank_account' => '343243423434 0000 3450 3034340',
        'prepayment_period' => 14,
        'office_phone' => '+48 8888888888',
        'office_email' => 'office@hussaria.pl'
    ]
];
