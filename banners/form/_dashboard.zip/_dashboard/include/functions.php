<?php

// errors, warning, info => LOGS
function logError($message, $logFile = 'errors') {
    $logDir = __DIR__ . '/../logs';
    $logFile = $logDir .'/'. $logFile .'.log';
    $htaccessFile = $logDir . '/.htaccess'; // Ścieżka do pliku .htaccess

        // Jeśli folder nie istnieje, utwórz go
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
    
            // Jeśli plik .htaccess nie istnieje, utwórz go
            if (!file_exists($htaccessFile)) {
                $htaccessContent = <<<HTACCESS
                    # Apache 2.2
                    <Files "*.log">
                        Order deny,allow
                        Deny from all
                    </Files>
                    
                    # Apache 2.4
                    <Files "*.log">
                        Require all denied
                    </Files>
                    HTACCESS;
                file_put_contents($htaccessFile, $htaccessContent);
            }
        }

    // Format loga: [Data] [IP] Treść błędu
    $logMessage = "[" . date("Y-m-d H:i:s") . "]" . $message . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}


// ==================================
// Sprawdź dostępne Motywy ==========
// ==================================
function getAvailableThemes($settings) {
    $availableThemes = [];
    
    if (isset($settings['themes']) && is_array($settings['themes'])) {

        foreach ($settings['themes'] as $key => $theme) {
            if ($theme['active'] ) {
                $availableThemes[$key] = $theme;
            }
        }
    }
    
    return $availableThemes;
}

// ==================================
// Sprawdź dostępne języki Motywu ===
// ==================================
function getThemeLanguages($langThemeDir) {
    $languages = [];

    foreach (glob($langThemeDir . '*.json') as $file) {
        $code = pathinfo($file, PATHINFO_FILENAME);
        $content = file_get_contents($file);
        $data = json_decode($content, true);
        
        $languages[] = [
            'name'      => isset($data['info']['name']) ? $data['info']['name'] : $code,
            'flag'      => isset($data['info']['flag']) ? $data['info']['flag'] : '',
            'iso'       => isset($data['info']['iso']) ? $data['info']['iso'] : '',
            'currency'  => isset($data['info']['currency']) ? $data['info']['currency'] : '',
        ];
    }

    return $languages;
}


function getHead($theme, $lang, $page) {
    include _HE_THEMES_ . $theme['path'] . _HE_THEME_PARTS_DIR_ . 'head.php';
}

function getHeader($theme) {
    include _HE_THEMES_ . $theme['path'] . _HE_THEME_PARTS_DIR_ . 'header.php';
}

function getSidebar($theme, $lang, $page, $userRole, $allowedForUserGroups) {
    include _HE_THEMES_ . $theme['path'] . _HE_THEME_PARTS_DIR_ . 'sidebar.php';
}

function getPage($theme, $lang, $page, $userRole, $allowedForUserGroups, $mode = false) {
    include _HE_THEMES_ . $theme['path'] . _HE_THEME_PAGES_DIR_ . $page . '.php';
}

function getFooter($theme) {
    include _HE_THEMES_ . $theme['path'] . _HE_THEME_PARTS_DIR_ . 'footer.php';
}


// ==============================
// Pobierz SVG
// ==============================
function svg_code($svg_file, $theme_path) {
    $full_path = _HE_THEMES_ . $theme_path . _HE_THEME_IMAGES_DIR_ . $svg_file;
   
    if (file_exists($full_path)) {
        echo file_get_contents($full_path);
        
    } else {
        logError("Plik SVG nie istnieje: $full_path", '404');
    }
}



// ==================================
// Sprawdź dostęp do danej strony
// ==================================
function checkPageAccess($page, $pages, $userRole) {
    // Jeśli strona nie istnieje lub nie jest aktywna
    if (!isset($pages[$page]) || $pages[$page]['active'] != 1) {
        return false;
    }

    // Jeśli role nie są ustawione, domyślnie blokuj dostęp
    if (!isset($pages[$page]['groups'])) {
        return false;
    }

    // Jeśli rola użytkownika jest w dozwolonych rolach strony
    return in_array($userRole, $pages[$page]['groups']);
}


function getAccessiblePages($pages, $userGroup) {
    $accessiblePages = [];
    foreach ($pages as $key => $page) {
        if (!isset($page['active']) || $page['active'] != 1) {
            continue; // pomijamy nieaktywne
        }
        if (!isset($page['groups']) || in_array($userGroup, $page['groups'])) {
            $accessiblePages[$key] = $page; // Użytkownik jest w grupie => strona
        }
    }
    return $accessiblePages;
}


function validate_login($login, $lang) {
    $errors = $lang['errors']['login'];

    if ($login === '') {
        return $errors['login_required'];
    }
    if (strlen($login) < 3 || strlen($login) > 32) {
        return $errors['login_length'];
    }
    if (!preg_match('/^[a-zA-Z0-9_\-\.@]+$/', $login)) {
        return $errors['login_invalid'];
    }
    return '';
}

function validate_password($password, $lang) {
    $errors = $lang['errors']['login'];
    
    if ($password === '') {
        return $errors['password_required'];
    }
    if (strlen($password) < 3 || strlen($password) > 64) {
        return $errors['password_length'];
    }
    return '';
}

?>