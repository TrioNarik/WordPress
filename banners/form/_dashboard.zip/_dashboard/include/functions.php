<?php

// ==================================
// Sprawdź dostępne Motywy zaplecza
// ==================================
function getAvailableThemesForUserRole($settings) {
    $availableThemes = [];
    
    if (isset($settings['themes']) && is_array($settings['themes']) && $settings['panel']['role']) {
        $userRole = $settings['panel']['role'];

        foreach ($settings['themes'] as $key => $theme) {
            if ($theme['active'] && isset($theme['roles']) && in_array($userRole, $theme['roles'])) {
                $availableThemes[$key] = $theme;
            }
        }
    }
    
    return $availableThemes;
}


// ==================================
// Sprawdź dostęp do danej strony
// ==================================
function checkPageAccess($page, $pages, $userRole) {
    // Jeśli strona nie istnieje lub nie jest aktywna
    if (!isset($pages[$page]) || $pages[$page]['active'] != 1) {
        return false;
    }

    // Jeśli role nie są ustawione, domyślnie blokuj dostęp
    if (!isset($pages[$page]['roles'])) {
        return false;
    }

    // Jeśli rola użytkownika jest w dozwolonych rolach strony
    return in_array($userRole, $pages[$page]['roles']);
}


function getAccessiblePages($pages, $userGroup) {
    $accessiblePages = [];
    foreach ($pages as $key => $page) {
        if (!isset($page['active']) || $page['active'] != 1) {
            continue; // pomijamy nieaktywne
        }
        if (!isset($page['groups']) || in_array($userGroup, $page['groups'])) {
            $accessiblePages[$key] = $page; // dodajemy stronę, jeśli użytkownik jest w grupie
        }
    }
    return $accessiblePages;
}


?>