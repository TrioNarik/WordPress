<?php
return [
    'tables' => [
        'languages'            => 'languages',
        'users'                => 'users',
        'user_address'         => 'user_address',
        'user_logs'            => 'user_logs',
        'user_reviews'         => 'user_reviews',
        'carts'                => 'carts',
        'orders'               => 'orders',
        'order_products'       => 'order_products',
        'configurations'       => 'configurations',
        'payment_methods'      => 'payment_methods',
        'payment_methods_lang' => 'payment_methods_lang',
        'payments'             => 'payments',
        'shipping_methods'     => 'shipping_methods',
        'shipping_methods_lang'=> 'shipping_methods_lang',
        'shippings'            => 'shippings',
        'coupons'              => 'coupons',
        'coupon_usage'         => 'coupon_usage',
    ]
];
