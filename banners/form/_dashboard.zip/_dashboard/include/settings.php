<?php
return [
    'db_sql' => [
        'host'          => 'localhost',
        'dbname'        => 'he_configurator',
        'user'          => 'root',
        'password'      => '',
        'prefix'        => 'he_',
        'mysql_engine'  => 'InnoDB'
    ],

    'logins' => [
        [
            'login'    => 'admin',
            'password' => 'admin',
            'role'     => 'administrator'
        ],
        [
            'login'    => 'manager',
            'password' => 'manager',
            'role'     => 'manager'
        ],
        [
            'login'    => 'demo',
            'password' => 'demo',
            'role'     => 'demo'
        ]
    ],

    'themes' => [
        'electra' => [
            'active'        => 1,
            'name'          => 'Theme Hussaria Electra',        // Title
            'version'       => '1.0.2',
            'path'          => 'classic',                       // Folder motywu
            'lang'          => 'pl',                            // Default'owy język
            'roles'         => ['administrator', 'manager'],    // Motyw dostępny dla użytkowników:
        ]
    ]
];
