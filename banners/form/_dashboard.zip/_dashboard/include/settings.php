<?php
return [
    'db_sql' => [
        'host'          => 'localhost',
        'dbname'        => 'he_configurator',
        'user'          => 'root',
        'password'      => '',
        'prefix'        => 'he_',
        'mysql_engine'  => 'InnoDB'
    ],

    'logins' => [
        [
            'login'    => 'admin',
            'password' => '$2y$10$Z9nhw1IbSGw.x7zB81EwM.qDcsDM5DyE2s9MkxX/Xf5DAwwVyhEza',      // hashowanie ('admin')
            'name'     => 'Administrator',
            'role'     => 'administrator'                                                      // określa dostęp do stron w theme > [groups]
        ],
        [
            'login'    => 'manager',
            'password' => '$2y$10$THIYESL96BpzU5UfSGYE..kmfxD8ySva7QjDZ4ILn5WHSWNusXHX2',       // hashowanie ('manger')
            'name'     => 'Manager',
            'role'     => 'manager'
        ],
        [
            'login'    => 'demo',
            'password' => '$2y$10$BzXHtQn0DD5.fdDzJbdR9OBd/WEGeXIVr8Mkol1P9yHdh5npBpSga',       // hashowanie ('demo')
            'name'     => 'Demo',
            'role'     => 'demo'
        ]
    ],

    'themes' => [
        'default' => [
            'active'        => 1,
            'name'          => 'Hussaria Electra',              // Title
            'version'       => '1.0.2',                         // Media Files
            'path'          => 'classic',                       // Folder motywu
            'languages'     => ['pl', 'en', 'es'],              // Aktywne języki w motywie
            'lang'          => 'pl',                            // Default
            'mode'          => ['light', 'dark', 'txt'],        // Tryb motywu
            'logo'          => 'hussaria-electra-100x100.png',  // Image
            'sidebar'       => 2,                               // Panel Size *col-md- [max.12]
        ],
    ]
];
