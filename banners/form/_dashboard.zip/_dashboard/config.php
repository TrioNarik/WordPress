<?php

/** Absolute path */
if ( ! defined( '_HE_PATH_' ) ) {
	define( '_HE_PATH_', __DIR__ . '/' );
}

define('AUTH_KEY',         'fwZgH&.8z&-e#,bifEG%F(#MH#,VcZ7 b<.9+Jj.WxQLKMkH_kjCaUyGPn7ae QE');
define('SECURE_AUTH_KEY',  '~yqmM-Iy;VKZl47?j`ZV$&vIp|Ki8 CU&8kC~+3zmOe^k?bT&g:]> xY,)}=;jnt');
define('LOGGED_IN_KEY',    'w9V=bSgvcSrYJrQbGr<?=|z&o@Y}HQirJ)s|k]:[rn0^Z7SINKBnv:*1.^G=#pQb');
define('NONCE_KEY',        '@WF}3*8I3WWNJvth.Akz1+mPAWi=86gZxt*%?k7+4^RI5XL~ZGUHaFxW`]j=qG:1');
define('AUTH_SALT',        '7g7ka@Y~{w;y#t/)b!BM6:ZLH)FmwCj5?Ob^iSY|jfLY3[-Sp/&$e^2:-A,-I.aH');
define('SECURE_AUTH_SALT', '?#l#M&)_Ug%^nj>8N<0d4-DRA1(P2t:<6;$ee(io?BUqFFq3^S<1^kA&pV)2Q04r');
define('LOGGED_IN_SALT',   'p,xRL?_EZO-&8S<!S@0dy4_eC5R6hlsGXcvhu-@8|<:~ludp@)-N6kx=LTl_/gYZ');
define('NONCE_SALT',       'Y.0|)C1A|0Sw~l{NA?8v VTB&$#EQMa|KJEo.$BM|-+DsnlE>Qvtma>YTCS>@l[a');

