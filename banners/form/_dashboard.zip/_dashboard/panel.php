<?php
session_start();

// Załaduj COFIG ze stałymi
$config = require_once 'config.php';

if (!defined('_HE_PATH_')) {
	exit;
}

if (!isset($_SESSION['HE_logged_in']) || $_SESSION['HE_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// ================================
// ======== SETTINGS ==============
// ================================
$settings   = require_once _HE_PATH_ . 'include/settings.php';


require_once _HE_PATH_ . 'include/functions.php';
// ================================

$availableThemes = [];
// Dostępne Motywy dla uzytkownika z 'rolą'
$availableThemes = getAvailableThemesForUserRole($settings);

if (!empty($availableThemes)) {
    foreach ($availableThemes as $key => $theme) {
        echo "Dostępny motyw: $key ({$theme['name']})<br>";
    }
}


if (isset($settings['themes'])) {
    print_r($settings['themes']);

    

    foreach($settings['themes'] as $theme) {

    }

    $header     = include 'includes/header.php';
    $footer     = include 'includes/sidebar.php';

}


// Pobierz strony dostępne dla tej grupy
$accessiblePages = getAccessiblePages($pages['pages'], $userGroup);


$page = $_GET['page'] ?? 'dashboard';
$allowed_pages = ['dashboard', 'posts', 'users', 'settings'];

if (in_array($page, $allowed_pages)) {
    include "pages/{$page}.php";
} else {
    echo "<h2>Strona nie istnieje</h2>";
}

include 'includes/footer.php';

?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Panel administracyjny</title>
</head>
<body>
    <h1>Witaj w panelu administracyjnym!</h1>
    <p><a href="logout.php">Wyloguj</a></p>
</body>
</html>



