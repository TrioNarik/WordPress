<?php
session_start();

// SETUP
require_once 'setup.php';
if (!defined('_HE_PATH_')) {
	exit;
}
// HELPER
require_once _HE_INCLUDE_DIR_ . 'functions.php';

$settings = require_once _HE_INCLUDE_DIR_ . 'settings.php';

// Jeśli użytkownik nie zalogowany => przekieruj do LOGIN
if (!isset($_SESSION['HE_logged_in']) || $_SESSION['HE_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// ================================
// ======== PANEL BO ==============
// ================================
$availableThemes = [];
// Dostępne Motywy
$availableThemes = getAvailableThemes($settings);

if (!empty($availableThemes)) {

    // * start - Active Theme *
    foreach ($availableThemes as $key => $theme) {

        
        //======= LANG ==========
        // ======================

        // Lang from GET lub theme => default lang
        $lang_theme = (isset($_GET['lang']) && preg_match('/^[a-z]{2}$/', $_GET['lang'])) ? $_GET['lang'] : $theme['lang'];

        // Session
        $_SESSION['HE_lang'] = $lang_theme;

        // Pobierz dostępne langs z settings => themes => languages
        $availableLanguages = getThemeLanguages(_HE_THEMES_DIR_ . $theme['path'] . _HE_THEME_LANG_DIR_);

        // Pobierz language file z folderu /theme/
        $lang_file = _HE_THEMES_DIR_ . $theme['path'] . _HE_THEME_LANG_DIR_ . $lang_theme . '.json';

        if (file_exists($lang_file)) {
            $lang_json = file_get_contents($lang_file);
            $lang = json_decode($lang_json, true);

            if ($lang === null) {
                // JSON decode error
                $lang = [];
            }

        } else {
            // Pusty lang
            $lang = [];
        }
    // * end - Active Theme *
    }

  
    // Pobieranie roli użytkownika z sesji
    $userRole = isset($_SESSION['HE_role']) ? $_SESSION['HE_role'] : 'guest';

    // Pobieranie listy dostępnych PAGE [slug], które są aktywne i dozwolone dla użytkowników [Groups]
    $allowedPages = [];
    foreach ($lang['pages'] as $pageName => $pageData) {
        if ($pageData['active'] == 1 && in_array($userRole, $pageData['groups'])) {
            $allowedPages[] = $pageName;
        }
    }


    // Pobieranie i sanitacja danych wejściowych
    $page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'dashboard';
    $mode = isset($_GET['mode']) ? htmlspecialchars($_GET['mode']) : false;


    if (!in_array($page, $allowedPages)) {
        $page = 'dashboard'; // Domyślna strona
    }

    // Pobieranie listy dozwolonych trybów MENU dla danej strony [slug]
    $allowedModes = isset($lang['pages'][$page]['content']['menu']) ? array_keys($lang['pages'][$page]['content']['menu']) : [];

    if ($mode && !in_array($mode, $allowedModes)) {
        $mode = false; // Domyślny tryb
    }

} else {
    header('Location: index.php');
    exit;
}



?>



<?php getHead($theme, $lang, $page); ?>

<main class="container-fluid">
    <div class="row">
    
        <?php getSidebar($theme, $lang, $page, $userRole, $allowedPages); ?>

        <!-- Content -->
        <div class="col ms-sm-auto p-1 p-md-3">

        <?php 

            if ($page) {

                getPage($theme, $lang, $page, $userRole, $allowedPages, $mode);

            } else {

                echo "<h2>Strona nie istnieje</h2>";

            }
        ?>

            <p><a href="logout.php">Wyloguj</a></p>

        </div>
    </div>
</main>

<?php getFooter($theme); ?>
