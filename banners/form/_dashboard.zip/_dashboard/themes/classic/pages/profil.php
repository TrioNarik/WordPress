<?php
ob_start();
if (isset($mode) && $mode === 'logout') {
    header('Location: ../../../logout.php');
    exit();
}
?>

<!-- Content -->
<section class="content">
    <?php if ($lang['pages'][$page]['active']): ?>
        <?php if ($lang['pages'][$page]['content']['message']['header']) : ?>
            <h4><?= htmlspecialchars($lang['pages'][$page]['content']['message']['header']) ?></h4>
        <?php endif; ?>

        <?php if ($lang['pages'][$page]['content']['message']['txt']) : ?>
            <div class="txt"><?= htmlspecialchars($lang['pages'][$page]['content']['message']['txt']) ?></div>
        <?php endif; ?>
    <?php endif; ?> 
</section>
