<!-- Content -->
<section>Tu treść z Dashboard</section>