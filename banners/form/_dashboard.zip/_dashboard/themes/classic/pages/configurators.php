<!-- Content -->
<section class="content">

<?php if ($lang['pages'][$page]['active']): ?>

    <?php if ($lang['pages'][$page]['content']['message']['header']) : ?>
        <h4><?= $lang['pages'][$page]['content']['message']['header'] ?></h4>
    <?php endif; ?>

    <?php if ($lang['pages'][$page]['content']['message']['txt']) : ?>
        <div class="txt"><?= $lang['pages'][$page]['content']['message']['txt'] ?></div>
    <?php endif; ?>

    <!-- Modyfikacje -->
    <?php if ($mode) : ?>
        <?php if ($mode === 'add') : ?>
            <form>
                <?= $lang['form']['labels']['name'] ?>
            </form>
        <?php endif; ?>

    <?php endif; ?>
        
<?php endif; ?> 

</section>

