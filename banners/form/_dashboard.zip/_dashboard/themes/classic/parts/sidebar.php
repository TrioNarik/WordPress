<?php
$current_page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'dashboard';
$current_mode = isset($_GET['mode']) ? htmlspecialchars($_GET['mode']) : false;

?>

<!-- Sidebar -->
<nav class="col-12 col-md-<?= $theme['sidebar'] ?> bg-dark text-light sidebar vh-100 p-1 p-md-3">
    <div class="logo-wrapper mb-3">
        <a href="https://electra.hussaria.pl/configurator">
            <img id="logo" class="logo" src="<?= _HE_THEMES_ . $theme['path'] . _HE_THEME_MEDIA_ .'img/hussaria_electra_logo_white.png?v='. $theme['version'] ?>" alt="Hussaria Electra">
        </a>
    </div>

    <ul class="nav flex-column">
        <?php foreach ($lang['pages'] as $key => $pageData): ?>

            <?php if (!empty($pageData['active']) && in_array($userRole, $pageData['groups'])): ?>

                <li class="menu <?= $current_page === $key ? 'current' : '' ?>">
                    <a class="pageMenu d-flex gap-3 align-items-center justify-content-start <?= $current_page === $key ? 'active' : '' ?>" href="?page=<?= htmlspecialchars($key) ?>">
                        <div class="dashIcon">
                            <?= svg_code($pageData['icon'] ?? '', $theme['path']) ?>
                        </div>
                        <div class="dashTitle">
                            <?= htmlspecialchars($pageData['title'] ?? ucfirst($key)) ?>
                        </div>
                    </a>

                    <?php if (!empty($pageData['content']['menu']) && is_array($pageData['content']['menu'])): ?>
                        <ul class="subMenu">
                            <?php foreach ($pageData['content']['menu'] as $menuKey => $menuLabel): ?>

                                <?php if ($userRole != 'aministrator'): ?>
                                    ddddd
                                <?php endif; ?>
                                <li><a class="mode <?= ($current_page === $key && $current_mode === $menuKey) ? 'active' : '' ?>" href="?page=<?= htmlspecialchars($key) ?>&mode=<?= htmlspecialchars($menuKey) ?>"><?= htmlspecialchars($menuLabel) ?></a></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                </li>
            <?php endif; ?>

        <?php endforeach; ?>
    </ul>
</nav>
