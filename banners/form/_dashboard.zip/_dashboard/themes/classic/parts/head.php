<!DOCTYPE html>
<html lang="<?= $_SESSION['HE_lang'] ?>" data-theme-mode="<?= $theme['mode'][0]?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($lang['pages'][$page]['title']) ?> ⚡ Hussaria Electra</title>
    <link rel="icon" href="<?= _HE_THEMES_ . $theme['path'] . _HE_THEME_IMAGES_DIR_ . 'hussaria-electra-100x100.png' ?>" sizes="32x32">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="token" content="">

    <?php
    foreach ($theme['languages'] as $code) {
        echo '<link rel="alternate" href="panel.php?lang=' . $code . '" hreflang="' . $code . '">';
    }
    ?>

    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="https://electra.hussaria.pl/configurator/img/elektryczna_paka-site.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="315">
    <meta property="og:image:alt" content="">
    <meta property="og:url" content="https://electra.hussaria.pl/configurator/_dashboard">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Theme CSS-->
    <link rel="stylesheet" href="<?= _HE_THEMES_ . $theme['path'] . _HE_THEME_MEDIA_ .'css/bootstrap.min.css' ?>">
    <link rel="stylesheet" href="<?= _HE_THEMES_ . $theme['path'] . _HE_THEME_MEDIA_ .'css/theme.css?v='. $theme['version'] .'' ?>">
</head>
<body>