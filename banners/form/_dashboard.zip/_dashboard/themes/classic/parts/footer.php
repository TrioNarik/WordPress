    <footer class="container-fluid fixed-bottom" id="footer">
        <div class="row">
            <div class="copyright text-center bg-dark text-light py-1">© Copyright 2025 | <?= $theme['name'] ?></div>
        </div>
    </footer>

    <!-- Theme JS -->
    <script src="<?= _HE_THEMES_ . $theme['path'] . _HE_THEME_MEDIA_ .'js/theme.js?v='. $theme['version'] ?>"></script>
</body>
</html>