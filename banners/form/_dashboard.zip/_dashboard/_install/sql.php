<?php

$db_config  = require_once _HE_PATH_ . '/include/settings.php'; // _DB && Login
$tables     = require_once _HE_PATH_ . '/include/tables.php';   // TABELE

$host       = $db_config['db_sql']['host'];
$dbname     = $db_config['db_sql']['db_name'];
$user       = $db_config['db_sql']['user'];
$pass       = $db_config['db_sql']['password'];
$prefix     = $db_config['db_sql']['prefix'];
$engine     = $db_config['db_sql']['mysql_engine'];



try {
    $pdo = new PDO("mysql:host={$host};dbname={$dbname};charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Błąd połączenia z bazą danych: " . $e->getMessage());
}

$sql = [];

// -- Języki
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['languages'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 0,
    `code` CHAR(2) NOT NULL UNIQUE,
    `name` VARCHAR(15) NOT NULL,
    `iso` CHAR(2) NOT NULL,
    `currency` CHAR(3) NOT NULL,
    `img` VARCHAR(8)
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Użytkownicy
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['users'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 0,
    `name` VARCHAR(50),
    `lastname` VARCHAR(50) NOT NULL,
    `phone` VARCHAR(20),
    `email` VARCHAR(255) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM("visitor", "user", "member", "manager", "administrator") DEFAULT "user",
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Adresy użytkowników
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['user_address'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 0,
    `is_default` TINYINT(1) DEFAULT 0,
    `user_id` INT NOT NULL,
    `type` ENUM("shipping", "billing") DEFAULT "shipping",
    `company` VARCHAR(255) DEFAULT NULL,
    `street` VARCHAR(255) NOT NULL,
    `local` VARCHAR(50) DEFAULT NULL,
    `postcode` VARCHAR(10) NOT NULL,
    `city` VARCHAR(50) NOT NULL,
    `state` VARCHAR(50) NOT NULL,
    `country` CHAR(2) NOT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `' . $prefix . $tables['users'] . '`(`id`) ON DELETE CASCADE,
    INDEX (`user_id`)
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Logi użytkowników
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['user_logs'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NOT NULL,
    `action` ENUM("login", "logout", "register", "password_change", "profile_update", "address_update") NOT NULL,
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `' . $prefix . $tables['users'] .'`(`id`) ON DELETE CASCADE,
    INDEX (`user_id`)
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Opinie użytkowników
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['user_reviews'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 0,
    `user_id` INT NOT NULL,
    `review` TEXT,
    `rating` INT,
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `' . $prefix . $tables['users'] .'`(`id`) ON DELETE CASCADE,
    INDEX (`user_id`)
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Koszyki
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['carts'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_ref` VARCHAR(100) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `lastname` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(50),
    `address` TEXT,
    `total` DECIMAL(10,2) NOT NULL,
    `status` ENUM("pending", "paid", "failed") DEFAULT "pending",
    `payment_method` VARCHAR(50),
    `coupon_code` VARCHAR(50),
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Zamówienia
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['orders'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `cart_id` INT DEFAULT NULL,
    `user_id` INT DEFAULT NULL,
    `total` DECIMAL(10,2) NOT NULL,
    `status` ENUM("pending", "paid", "failed", "cancelled") DEFAULT "pending",
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`cart_id`) REFERENCES `' . $prefix . $tables['carts'] .'`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`user_id`) REFERENCES `' . $prefix . $tables['users'] .'`(`id`) ON DELETE SET NULL,
    INDEX (`cart_id`),
    INDEX (`user_id`)
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Produkty w zamówieniu
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['order_products'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `product_id` INT NOT NULL,
    `quantity` INT NOT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (`order_id`) REFERENCES `' . $prefix . $tables['orders'] .'`(`id`) ON DELETE CASCADE,
    INDEX (`order_id`)
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Konfiguracje produktu
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['configurations'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT DEFAULT NULL,
    `user_id` INT DEFAULT NULL,
    `data` TEXT,
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`order_id`) REFERENCES `' . $prefix . $tables['orders'] .'`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`user_id`) REFERENCES `' . $prefix . $tables['users'] .'`(`id`) ON DELETE SET NULL
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Metody płatności
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['payment_methods'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 0,
    `name` VARCHAR(100) NOT NULL
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['payment_methods_lang'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `method_id` INT NOT NULL,
    `lang` VARCHAR(5) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    FOREIGN KEY (`method_id`) REFERENCES `' . $prefix . $tables['payment_methods'] .'`(`id`) ON DELETE CASCADE
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Płatności
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['payments'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `method_id` INT NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `status` ENUM("pending", "paid", "failed") DEFAULT "pending",
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`order_id`) REFERENCES `' . $prefix . $tables['orders'] .'`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`method_id`) REFERENCES `' . $prefix . $tables['payment_methods'] .'`(`id`) ON DELETE CASCADE
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Metody dostawy
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['shipping_methods'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 0,
    `name` VARCHAR(100) NOT NULL
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['shipping_methods_lang'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `method_id` INT NOT NULL,
    `lang` VARCHAR(5) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    FOREIGN KEY (`method_id`) REFERENCES `' . $prefix . $tables['shipping_methods'] .'`(`id`) ON DELETE CASCADE
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Dostawy
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['shippings'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `method_id` INT NOT NULL,
    `tracking_number` VARCHAR(100),
    `status` VARCHAR(50),
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`order_id`) REFERENCES `' . $prefix . $tables['orders'] .'`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`method_id`) REFERENCES `' . $prefix . $tables['shipping_methods'] .'`(`id`) ON DELETE CASCADE
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Kupony
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['coupons'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `active` TINYINT(1) DEFAULT 1,
    `lang` VARCHAR(50) DEFAULT NULL,
    `code` VARCHAR(15) NOT NULL UNIQUE,
    `type` ENUM("percent", "fixed", "free_product", "free_shipping", "first_order", "loyalty") DEFAULT "percent",
    `value` DECIMAL(10,2) DEFAULT NULL,
    `min_order_value` DECIMAL(10,2) DEFAULT NULL,
    `usage_limit` INT DEFAULT 1,
    `used_count` INT DEFAULT 0,
    `start` DATE DEFAULT CURRENT_DATE,
    `finish` DATE DEFAULT NULL,
    `created` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// -- Użycie kuponów
$sql[] = 'CREATE TABLE IF NOT EXISTS `' . $prefix . $tables['coupon_usage'] . '` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `coupon_id` INT NOT NULL,
    `user_id` INT DEFAULT NULL,
    `order_id` INT DEFAULT NULL,
    `used_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`coupon_id`) REFERENCES `' . $prefix . $tables['coupons'] .'`(`id`) ON DELETE CASCADE,
    FOREIGN KEY (`user_id`) REFERENCES `' . $prefix . $tables['users'] .'`(`id`) ON DELETE SET NULL,
    FOREIGN KEY (`order_id`) REFERENCES `' . $prefix . $tables['orders'] .'`(`id`) ON DELETE SET NULL
) ENGINE=' . $engine . ' DEFAULT CHARSET=utf8mb4;';

// Wykonanie zapytań
foreach ($sql as $query) {
    try {
        $pdo->exec($query);
    } catch (PDOException $e) {
        echo "Błąd SQL: " . $e->getMessage() . "\n";
    }
}
