<?php
session_start();

// SETUP
require_once 'setup.php';
if (!defined('_HE_PATH_')) {
	exit;
}
// HELPER
require_once _HE_INCLUDE_DIR_ . 'functions.php';

$settings = require_once _HE_INCLUDE_DIR_ . 'settings.php';

// Jeśli użytkownik już zalogowany => przekieruj do BO
if (isset($_SESSION['HE_logged_in']) && $_SESSION['HE_logged_in'] === true && isset($_SESSION['HE_role'])) {
    header('Location: panel.php');
    exit;
}

// ===============================================
// ================== LOGOWANIE ==================
// ===============================================
$availableThemes = [];
// Dostępne Motywy
$availableThemes = getAvailableThemes($settings);

if (!empty($availableThemes)) {

    // * start - Active Theme *
    foreach ($availableThemes as $key => $theme) {


        //======= LANG ==========
        // ======================

        // Lang from GET lub theme => default lang
        $lang_theme = (isset($_GET['lang']) && preg_match('/^[a-z]{2}$/', $_GET['lang'])) ? $_GET['lang'] : $theme['lang'];

        // Session
        $_SESSION['HE_lang'] = $lang_theme;

        // Pobierz dostępne langs z settings => themes => languages
        $availableLanguages = getThemeLanguages(_HE_THEMES_DIR_ . $theme['path'] . _HE_THEME_LANG_DIR_);

        // Pobierz language file z folderu /theme/
        $lang_file = _HE_THEMES_DIR_ . $theme['path'] . _HE_THEME_LANG_DIR_ . $lang_theme . '.json';

        if (file_exists($lang_file)) {
            $lang_json = file_get_contents($lang_file);
            $lang = json_decode($lang_json, true);

            if ($lang === null) {
                // JSON decode error
                $lang = [];
            }

        } else {
            // Pusty lang
            $lang = [];
        }



        //======= LOGIN =========
        // ======================
        $error = '';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $login    = trim($_POST['login'] ?? '');    // Form => input
            $passw    = $_POST['password'] ?? '';       // Form => input

            // Sprawdź token
            if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
                $error = $lang['errors']['login']['token'];
            }


            // 1. Login
            $error = validate_login($login, $lang);

            if (!$error) {
                // 2. Password
                $error = validate_password($passw, $lang);
            }

            if (!$error) {

                $found['managers']  = false; // Brak w Settings
                $found['users']     = false; // Brak w BD

                // A. Sprawdź formularz i dostępnych użytkowników z settings => logins
                foreach ($settings['logins'] as $user) {
                    if ($login === $user['login'] && password_verify($passw, $user['password'])) { 

                        // Regenerate session ID
                        session_regenerate_id();
                        $_SESSION['HE_logged_in']   = true;
                        $_SESSION['HE_login']       = $user['login'];
                        $_SESSION['HE_role']        = $user['role'];

                        $found['managers'] = true;

                        header('Location: panel.php');
                        exit;
                    }
                }

                // B. Sprawdź bazę danych użytkowników
                if(!$found['managers']) {
                    
                    // połączenie BD, checking.....
                    
                }

                

                if (!$found['managers'] && !$found['users']) {

                    $error = $lang['errors']['login']['incorrect'];

                }
            }
        }

    // * end - Active Theme *
    }

} else {
    header('Location: index.php');
    exit;
}


if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}


?>

<?php getHead($theme, $lang, 'login'); ?>

<main class="container-fluid">
    <div class="row">

        <!-- Content -->
        <div class="col ms-sm-auto p-1 p-md-3">
            <section class="d-flex flex-column align-items-center justify-content-center">
                <div class="logo">
                    <img src="<?= _HE_THEMES_ . $theme['path'] . _HE_THEME_IMAGES_DIR_ . $theme['logo'] .'?v='. $theme['version'] ?>" alt="<?= $theme['name'] ?>">
                </div>
                <form method="post">
                    <div class="languages">
                    <?php if ($availableLanguages && isset($theme['languages'])) {
                        echo '<ul>';
                        // Loop through theme languages array to maintain order
                        foreach($theme['languages'] as $lang_code) {
                            // Find matching language in availableLanguages
                            foreach($availableLanguages as $language) {
                                if ($language['iso'] === $lang_code) {
                                    echo '<li>';
                                    echo '<a href="?lang='. $language['iso'] .'">';
                                    echo '<img src="' . _HE_THEMES_ . $theme['path'] . _HE_THEME_IMAGES_DIR_ . $language['flag'] .'" title="'. $language['name'] .'" alt="'. $language['name'] .'">';
                                    echo '</a>';
                                    echo '</li>';
                                    break;
                                }
                            }
                        }
                        echo '</ul>';
                    }?>
                    </div>
                    
                    <h5><?= htmlspecialchars($lang['form']['login']['header']) ?></h5>
                    <input type="text" name="login" placeholder="<?= htmlspecialchars($lang['form']['login']['input_login']) ?>" value="admin" required>
                    <input type="password" name="password" placeholder="<?= htmlspecialchars($lang['form']['login']['input_password']) ?>" value="admin" required>
                    <input type="submit" class="btn btn-warning" value="<?= htmlspecialchars($lang['form']['login']['submit']) ?>">

                    <input type="hidden" name="lang"    id="lang"    value="<?= $_SESSION['HE_lang'] ?>">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    <input type="hidden" name="human"   id="human"   value="">
                    <input type="hidden" name="isForm"  id="isForm"  value="">
                    <input type="hidden" name="isVisit" id="isVisit" value="">

                    <?php if ($error): ?>
                        <div class="error"><?= htmlspecialchars($error) ?></div>
                    <?php endif; ?>
                </form>
                <div>&#8592; <a href="https://electra.hussaria.pl/configurator/"><?= htmlspecialchars($lang['pages']['login']['content']['message']['view']) ?></a></div>
            </section>
        </div>
    </div>
</main>


<?php getFooter($theme); ?>
