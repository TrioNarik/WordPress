<?php
session_start();
// Załaduj COFIG ze stałymi
$config = require_once 'config.php';

if (!defined('_HE_PATH_')) {
	exit;
}

$settings = require_once _HE_PATH_ . 'include/settings.php';

// Jeśli użytkownik już zalogowany – przekieruj
if (isset($_SESSION['HE_logged_in']) && $_SESSION['HE_logged_in'] === true) {
    header('Location: panel.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';

    if ( $login === $settings['panel']['login'] && $password === $settings['panel']['password'] ) {
        $_SESSION['HE_logged_in'] = true;
		$_SESSION['HE_role'] = $settings['panel']['role'];
        header('Location: panel.php');
        exit;
    } else {
        $error = 'Nieprawidłowy login lub hasło.';
    }
}
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Logowanie do panelu</title>
    <style>
        body { font-family: sans-serif; background: #f7f7f7; padding: 50px; }
        form { max-width: 300px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
        input { width: 100%; padding: 10px; margin-top: 10px; }
        .error { color: red; margin-top: 10px; }
    </style>
</head>
<body>

<form method="post">
    <h2>Logowanie</h2>
    <input type="text" name="login" placeholder="Login" required>
    <input type="password" name="password" placeholder="Hasło" required>
    <input type="submit" value="Zaloguj">
    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
</form>

</body>
</html>
