<?php
session_start();
require_once 'functions.php';

if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 'error', 'message' => 'Błędny token!']);
    logError('Błędny token generowania PDF/JPEG prez użytkownika w JS functions => getSVGContent()', 'error');
    exit;
}

// Pobranie danych SVG z DIV
$svgContent = isset($_POST['svg']) ? $_POST['svg'] : null;
if (!$svgContent) {
    echo json_encode(['status' => 'error', 'message' => 'Brak danych SVG!']);
    logError('Brak danych SVG! w JS functions => getSVGContent()', 'error');
    exit;
}

// Pobranie FONTS z SVG
$fonts = isset($_POST['fonts']) ? $_POST['fonts'] : null;
if (!$fonts) {
    logError('Użytkownik wygenerował PDF/JPEG bez napisów [czcionek]. Brak ich nazw w JS functions => getSVGContent()', 'info');
}


if (!isset($_POST['generate'])) {
    logError('Brak parametru generate=... w URL! podczas generowania PDF/JPEG prez użytkownika', 'warning');
    echo json_encode(['status' => 'error', 'message' => 'Brak parametrów!']);
    exit;
}

$generateType = trim(htmlspecialchars($_POST['generate']));

switch ($generateType) {
    case 'pdf':
        generatePDF($svgContent, $generateType, $fonts);
        break;

    case 'jpeg':
        generateImage($svgContent, $generateType, $fonts);
        break;

    default:
        logError("Nierozpoznany typ generowania pliku: $generateType", 'error_type_generate');
        echo json_encode(['status' => 'error', 'message' => 'Nierozpoznany typ generowania pliku!']);
        exit;
}



// Funkcja generująca PDF
function generatePDF($svgContent, $generateType) {
    // Sprawdzenie, czy Imagick jest dostępny
    if (!class_exists('Imagick')) {
        logError('Biblioteka Imagick nie jest dostępna!', 'error_generate_pdf');
        echo json_encode(['status' => 'error', 'message' => 'Biblioteka Imagick nie jest dostępna!']);
        exit;
    }

    // Ścieżki do folderów
    $uploadsDir = __DIR__ . '/../uploads';
    $pdfDir = $uploadsDir . '/' . $generateType;

    // Tworzenie katalogów, jeśli nie istnieją
    if (!file_exists($uploadsDir) && !mkdir($uploadsDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $uploadsDir, 'error_generate_pdf');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $uploadsDir]);
        exit;
    }

    if (!file_exists($pdfDir) && !mkdir($pdfDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $pdfDir, 'error_generate_pdf');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $pdfDir]);
        exit;
    }

    // Ścieżka do pliku wynikowego
    $fileName = 'hussaria_electra_' . time() . '.pdf';
    $filePath = $pdfDir . '/' . $fileName;

    // Tworzenie PDF za pomocą Imagick
    try {
        $image = new Imagick();
        $image->readImageBlob($svgContent); // Odczytanie treści SVG

        // Ustawienie rozdzielczości na 300 DPI
        $image->setImageResolution(300, 300);

        // Powiększenie obrazu do rozmiaru A4 (2480x3508 pikseli)
        $a4Width = 2480;
        $a4Height = 3508;
        $image->resizeImage($a4Width, $a4Height, Imagick::FILTER_LANCZOS, 1);

        // Zmniejszenie obrazu do docelowego rozmiaru
        $image->resizeImage(800, null, Imagick::FILTER_LANCZOS, 1);

        // Zastosowanie maski rozmycia, aby poprawić ostrość
        $image->unsharpMaskImage(0, 0.5, 1, 0.05);

        // Konwersja do formatu PDF
        $image->setImageFormat('pdf');
        $image->writeImage($filePath); // Zapisanie pliku
        $image->clear();
        $image->destroy();
    } catch (Exception $e) {
        logError('Błąd przy generowaniu PDF: ' . $e->getMessage(), 'error_generate_pdf');
        echo json_encode(['status' => 'error', 'message' => 'Błąd generowania PDF: ' . $e->getMessage()]);
        exit;
    }

    // Sprawdzenie, czy plik został zapisany
    if (!file_exists($filePath)) {
        logError('Nie udało się zapisać PDF!', 'error_generate_save');
        echo json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać PDF!']);
        exit;
    }

    // Generowanie URL do pliku
    $baseUrl = '/order_v4/uploads/' . $generateType . '/';
    $fileUrl = $baseUrl . $fileName;

    // Zwrócenie poprawnej odpowiedzi JSON
    echo json_encode(['status' => 'success', 'file_url' => $fileUrl]);
    exit;
}





// Funkcja generująca obraz
function generateImage($svgContent, $generateType, $fonts = null, $format = 'jpeg', $width = 800, $padding = 50, $bgColor = '#FFFFFF') {

    // Ścieżki do czcionek
    $fontPaths = [
        'annabelle-jf' => realpath('../fonts/AnnabelleJF-Regular.ttf'),
        'century' => realpath('../fonts/Century.ttf'),
        'relation-one' => realpath('../fonts/Relation.ttf'),
        'open-sans' => realpath('../fonts/Open-Sans-Regular.ttf'),
        'nunito' => realpath('../fonts/Nunito-Sans-Regular.ttf'),
        'noto-sans' => realpath('../fonts/Noto-Sans-Regular.ttf'),

        // default font
        'montserrat' => realpath('../fonts/Montserrat-Regular.ttf'),
    ];

    // 
    

    // Sprawdzenie, czy Imagick jest dostępny
    if (!class_exists('Imagick')) {
        logError('Biblioteka Imagick PHP do generowania JPEG nie jest dostępna!', '404');
        echo json_encode(['status' => 'error', 'message' => 'Biblioteka Imagick nie jest dostępna!']);
        exit;
    }

    // Ścieżki do folderów
    $uploadsDir = '../uploads';
    $imgDir = $uploadsDir . '/' . $generateType;

    // Tworzenie katalogów, jeśli nie istnieją
    if (!file_exists($uploadsDir) && !mkdir($uploadsDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $uploadsDir .' do generowania plików z SVG' , 'error_dir');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $uploadsDir]);
        exit;
    }

    if (!file_exists($imgDir) && !mkdir($imgDir, 0777, true)) {
        logError('Nie można utworzyć podkatalogu: ' . $imgDir .' do generowania plików z SVG' , 'error_dir');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $imgDir]);
        exit;
    }

    // Ścieżka do pliku wynikowego
    $fileName = 'hussaria_electra_' . uniqid() . '.' . $format;
    $filePath = $imgDir . '/' . $fileName;

    // Tworzenie obrazu za pomocą Imagick
    try {
        $image = new Imagick();
        $image->readImageBlob($svgContent); // Odczytanie treści SVG

        // Dodanie tła (prostokąt o pełnej szerokości i wysokości)
        $image->setImageBackgroundColor($bgColor); // Kolor tła
        $image->extentImage($image->getImageWidth() + $padding, $image->getImageHeight() + $padding, -($padding / 2), -($padding / 2)); // Padding 50px i odstępy -25px

        // Załadowanie czcionek z SVG
        preg_match_all('/font-family="([^"]+)"/', $svgContent, $matches);
        $usedFonts = array_unique($matches[1]); // Zbieramy wszystkie używane czcionki w SVG

        // Załaduj czcionki, które są używane w SVG
        foreach ($usedFonts as $fontFamily) {
            if (isset($fontPaths[$fontFamily])) {
                // Ścieżka do czcionki
                $fontPath = $fontPaths[$fontFamily];
                if (file_exists($fontPath)) {
                    Imagick::queryFontMetrics($fontPath); // Upewnij się, że czcionka jest dostępna
                } else {
                    // Jeśli czcionka nie jest dostępna, logujemy błąd, ale używamy czcionki domyślnej
                    logError("Czcionka nie została znaleziona: {$fontFamily}, używto podstawowej czcionki do generowania JPEG", 'warning');
                    // Ustawiamy domyślną czcionkę, jeśli nie znaleziono
                    $fontPath = $fontPaths['montserrat']; // Użyj czcionki domyślnej
                }
            } else {
                // Jeśli czcionka nie jest w tablicy, używamy domyślnej czcionki
                $fontPath = $fontPaths['montserrat']; // Użyj czcionki domyślnej
            }

            // Zastosowanie czcionki do SVG w przypadku, gdy czcionka jest dostępna
            $image->setFont($fontPath);
        }


        // Ustawienie rozmiaru obrazka w pikselach, jeśli podano
        if ($width !== null) {
            $image->resizeImage($width, null, Imagick::FILTER_LANCZOS, 1);
        }

        // Ustawienie jakości kompresji dla formatu JPEG
        $image->setImageCompressionQuality(90);

        // Zastosowanie maski rozmycia, aby poprawić ostrość
        $image->unsharpMaskImage(0, 0.5, 1, 0.05);

        // Ustawienie formatu obrazu
        $image->setImageFormat($format);

        // Zapisanie pliku
        $image->writeImage($filePath);
        $image->clear();
        $image->destroy();
    } catch (Exception $e) {
        logError('Błąd przy generowaniu obrazu: ' . $e->getMessage(), 'error_image_generate');
        echo json_encode(['status' => 'error', 'message' => 'Błąd generowania JPEG']);
        exit;
    }

    // Sprawdzenie, czy plik został zapisany
    if (!file_exists($filePath)) {
        logError('Nie udało się zapisać obrazu! ' . $e->getMessage(), 'error_save_generate');
        echo json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać obrazu!']);
        exit;
    }

    // Generowanie URL do pliku
    $baseUrl = '/order_v4/uploads/' . $generateType . '/';
    $fileUrl = $baseUrl . $fileName;

    // Zwrócenie poprawnej odpowiedzi JSON
    echo json_encode(['status' => 'success', 'file_url' => $fileUrl]);
    exit;
}



?>
