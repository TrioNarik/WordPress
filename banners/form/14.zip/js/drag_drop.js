addObjectOverPathSVGforDrag_n_Drop('svg_paka', 'front-door');
// addObjectOverPathSVGforDrag_n_Drop('svg_paka', 'left-panel');
// addObjectOverPathSVGforDrag_n_Drop('svg_paka', 'top-bar');   

function uploadImage(file, progressElement, imageWrapper) {
    const formData = new FormData();
    formData.append('image', file);

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'include/upload.php', true);

    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) {
        const percentComplete = (e.loaded / e.total) * 100;
        progressElement.style.width = percentComplete + '%';
      }
    });

    xhr.onload = function() {
      if (xhr.status === 200) {
        const response = JSON.parse(xhr.responseText);
        if (response.success) {
          console.log('Obrazek przesłany:', response.file);
          progressElement.style.backgroundColor = '#4caf50';
          uploadedFiles.push({ filePath: response.file, wrapper: imageWrapper });

          const fileNameInput = document.createElement('input');
          fileNameInput.type = 'hidden';
          fileNameInput.name = 'fileNames[]';
          fileNameInput.value = response.file;
        //   fileNamesContainer.appendChild(fileNameInput);

        //   emailForm.style.display = 'block';

        } else {
          console.error('Błąd:', response.error);
          progressElement.style.backgroundColor = 'red';
        }
      } else {
        console.error('Błąd podczas przesyłania:', xhr.statusText);
        progressElement.style.backgroundColor = 'red';
      }
    };

    xhr.onerror = function() {
      console.error('Błąd połączenia');
      progressElement.style.backgroundColor = 'red';
    };

    xhr.send(formData);
  }

  function removeImage(imageWrapper, file) {
    imageWrapper.remove();

    const uploadedFile = uploadedFiles.find(item => item.wrapper === imageWrapper);
    if (uploadedFile) {
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'include/delete.php', true);
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onload = function() {
        if (xhr.status === 200) {
          console.log('Plik usunięty z serwera:', uploadedFile.filePath);
        } else {
          console.error('Błąd podczas usuwania pliku:', xhr.statusText);
        }
      };
      xhr.send(JSON.stringify({ filePath: uploadedFile.filePath }));

      const index = uploadedFiles.indexOf(uploadedFile);
      if (index > -1) {
        uploadedFiles.splice(index, 1);
      }

      const fileNameInputs = fileNamesContainer.querySelectorAll('input[name="fileNames[]"]');
      fileNameInputs.forEach(input => {
        if (input.value === uploadedFile.filePath) {
          input.remove();
        }
      });
    }

    if (uploadedFiles.length < MAX_FILES) {
      fileInput.disabled = false;
    }

    if (uploadedFiles.length === 0) {
      emailForm.style.display = 'none';
    }
  }


// Funkcja do dodawania input type="file" do każdego .preview-container
function addFileInputToPreviewContainers(designElement) {
    // Pobierz wszystkie elementy .preview-container wewnątrz .design
    const previewContainers = designElement.querySelectorAll('.preview-container');
  
    // Iteruj przez każdy element .preview-container
    previewContainers.forEach(previewContainer => {
      // Sprawdź, czy input już istnieje
      if (!previewContainer.querySelector('.file-input')) {
        // Utwórz kontener dla input i label
        const fileInputContainer = document.createElement('div');
        fileInputContainer.classList.add('file-input');
  
        // Utwórz element input type="file"
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.classList.add('file');
        fileInput.accept = 'image/jpeg, image/png';
        fileInput.multiple = false;
        fileInput.style.display = 'none'; // Ukryj domyślny przycisk wyboru pliku
  
        // Utwórz etykietę dla przycisku
        const fileLabel = document.createElement('label');
        fileLabel.htmlFor = fileInput.id = 'fileInput' + previewContainer.id; // Unikalne ID dla każdego input
        fileLabel.innerHTML = '<img src="add.svg" width="24" height="24" alt="">';
        fileLabel.style.cursor = 'pointer';
  
        // Dodaj input i etykietę do kontenera
        fileInputContainer.appendChild(fileInput);
        fileInputContainer.appendChild(fileLabel);
  
        // Dodaj kontener do elementu .preview-container
        previewContainer.appendChild(fileInputContainer);


        // Dodaj obsługę zdarzenia change dla input
        fileInput.addEventListener('change', (event) => {
            const files = event.target.files;
            // errorMessage.textContent = '';
  
            if (uploadedFiles.length + files.length > MAX_FILES) {
            //   errorMessage.textContent = `Możesz przesłać maksymalnie ${MAX_FILES} obrazki.`;
              fileInput.value = '';
              return;
            }
  
            Array.from(files).forEach((file) => {
              if (file.size > 5 * 1024 * 1024) {
                // errorMessage.textContent = 'Rozmiar pliku nie może przekraczać 5 MB!';
                fileInput.value = '';
                return;
              }
  
              if (!['image/jpeg', 'image/png'].includes(file.type)) {
                // errorMessage.textContent = 'Tylko pliki JPG, JPEG i PNG są dozwolone!';
                fileInput.value = '';
                return;
              }
  
              const reader = new FileReader();
              reader.onload = function(e) {
                const imageWrapper = document.createElement('div');
                imageWrapper.classList.add('image-wrapper');
  
                const img = document.createElement('img');
                img.src = e.target.result;
                imageWrapper.appendChild(img);
  
                const progressBar = document.createElement('div');
                progressBar.classList.add('progress-bar');
  
                const progress = document.createElement('div');
                progress.classList.add('progress');
                progressBar.appendChild(progress);
  
                imageWrapper.appendChild(progressBar);
  
                const removeBtn = document.createElement('button');
                removeBtn.classList.add('remove-btn');
                removeBtn.innerHTML = '<img src="trash.svg" width="16" height="16" alt="">';
                removeBtn.addEventListener('click', () => removeImage(imageWrapper, file));
                imageWrapper.appendChild(removeBtn);
  
                previewContainer.appendChild(imageWrapper);
  
                uploadImage(file, progress, imageWrapper, previewContainer);
              };
  
              reader.readAsDataURL(file);
            });
  
            if (uploadedFiles.length + files.length >= MAX_FILES) {
              fileInput.disabled = true;
            }
        });
      }
    });
  }
  



const designs = document.querySelectorAll('.design');
const frontPanel = document.getElementById('svg_paka_front-door');

const previewContainer = document.querySelectorAll('.preview-container');

const uploadedFiles = [];
const MAX_FILES = 2;

let offsetX, offsetY;

designs.forEach(design => {
    design.addEventListener('dragstart', (e) => {
        e.dataTransfer.setData('text/plain', design.id);
        design.classList.add('dragging');

        // Dodaj klasę do front-panel, aby rozpocząć oscylowanie
        frontPanel.classList.add('highlight');
    });

    design.addEventListener('dragend', () => {
        design.classList.remove('dragging');

        // Usuń klasę z front-panel, aby zakończyć oscylowanie
        frontPanel.classList.remove('highlight');
    });
});

frontPanel.addEventListener('dragover', (e) => {
    e.preventDefault();
});

frontPanel.addEventListener('drop', (e) => {
    e.preventDefault();
    const designId = e.dataTransfer.getData('text/plain');
    const draggedDesign = document.getElementById(designId);


    // Usuń poprzedni element w frontPanel
    frontPanel.innerHTML = '';

    const newDesign = draggedDesign.cloneNode(true);
    newDesign.classList.remove('dragging');
    newDesign.setAttribute('draggable', 'false'); // Wyłącz przeciąganie

    // Ustaw dokładną pozycję upuszczenia
    const rect = frontPanel.getBoundingClientRect();
    newDesign.style.left = `${e.clientX - rect.left - newDesign.offsetWidth / 2}px`;
    newDesign.style.top = `${e.clientY - rect.top - newDesign.offsetHeight / 2}px`;

    // Dodaj przycisk usuwania
    const deleteBtn = document.createElement('button');
    deleteBtn.classList.add('delete-btn');
    deleteBtn.innerHTML = '<img src="cancel.svg" width="16" height="16" alt="">';


    deleteBtn.onclick = (event) => {
        event.stopPropagation();
        newDesign.remove();
    };
    newDesign.appendChild(deleteBtn);

    // Dodaj input type="file" do każdego .preview-container w nowym designie
    addFileInputToPreviewContainers(newDesign);

    frontPanel.appendChild(newDesign);


    


    enableDragging(newDesign, frontPanel);
});

function enableDragging(element, container) {
    element.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('delete-btn')) return;

        offsetX = e.clientX - element.getBoundingClientRect().left;
        offsetY = e.clientY - element.getBoundingClientRect().top;

        const onMouseMove = (moveEvent) => {
            const rect = container.getBoundingClientRect();
            let x = moveEvent.clientX - rect.left - offsetX;
            let y = moveEvent.clientY - rect.top - offsetY;

            // Ograniczenia ruchu w obrębie frontPanel z marginesem 10px
            x = Math.max(10, Math.min(x, rect.width - element.offsetWidth - 10));
            y = Math.max(10, Math.min(y, rect.height - element.offsetHeight - 10));

            element.style.left = `${x}px`;
            element.style.top = `${y}px`;
        };

        const onMouseUp = () => {
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };

        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
    });
}