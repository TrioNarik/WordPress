const textInput = document.getElementById("personalizationText");
const customText = document.getElementById("previewText");

// ✅ Aktualizuje tekst na SVG w czasie rzeczywistym
textInput.addEventListener("input", () => {
    customText.textContent = textInput.value || "Domyślny tekst";
});

// ✅ Event Delegation dla wyrównania tekstu
const textAlignList = document.getElementById("textAlignt");
textAlignList.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;

    // Pobranie wyrównania z data-align
    const align = button.getAttribute("data-align");
    setAlignment(align);

    // Zarządzanie klasą "active"
    textAlignList.querySelectorAll("button").forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");
});

// ✅ Event Delegation dla rozmiaru tekstu
const textSizeList = document.getElementById("textSize");
textSizeList.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;

    // Pobranie rozmiaru z data-size
    const size = button.getAttribute("data-size");
    setSize(size);

    // Zarządzanie klasą "active"
    textSizeList.querySelectorAll("button").forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");
});


// ✅ Event Delegation dla stylów tekstu (bold, italic, underline)
const textStyleList = document.getElementById("textStyle");
textStyleList.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;

    // Pobranie stylu z data-style
    const style = button.getAttribute("data-style");
    toggleTextStyle(style);

    // Toggle klasy "active" dla stylów
    button.classList.toggle("active");
});


// ✅ Funkcja do ustawienia wyrównania tekstu
function setAlignment(align) {
    const alignments = {
        left: { anchor: "start", x: "25", y: "18", fontSize: "3", transform: "rotate(0.5 10 10) scale(1, 0.5)" },
        middle: { anchor: "middle", x: "52", y: "18", fontSize: "3", transform: "rotate(0.5 10 10) scale(1, 0.5)" },
        right: { anchor: "end", x: "76", y: "18", fontSize: "3", transform: "rotate(0.5 10 10) scale(1, 0.5)" }
    };

    const props = alignments[align];
    if (props) {
        customText.setAttribute("text-anchor", props.anchor);
        customText.setAttribute("x", props.x);
        customText.setAttribute("y", props.y);
        customText.setAttribute("font-size", props.fontSize);
        customText.setAttribute("transform", props.transform);
    }
}

// ✅ Funkcja do ustawienia rozmiaru tekstu
function setSize(size) {
    const sizeSettings = {
        '2': { fontSize: '2', transform: "rotate(0.5 10 10) scale(1, 0.5)" },
        '4': { fontSize: '4', transform: "rotate(0.5 10 10) scale(1, 0.5)" },
        '6': { fontSize: '6', transform: "rotate(0.5 10 10) scale(1, 0.5)" }
    };

    const settings = sizeSettings[size];
    if (settings) {
        customText.setAttribute("font-size", settings.fontSize);
        customText.setAttribute("transform", settings.transform);
    }
}
    
// ✅ Funkcja do zmiany stylu tekstu (bold, italic, underline)
function toggleTextStyle(style) {
    if (style === 'bold') {
        const currentWeight = customText.getAttribute('font-weight') || 'normal';
        customText.setAttribute('font-weight', currentWeight === 'bold' ? 'normal' : 'bold');
    } else if (style === 'italic') {
        const currentStyle = customText.getAttribute('font-style') || 'normal';
        customText.setAttribute('font-style', currentStyle === 'italic' ? 'normal' : 'italic');
    } else if (style === 'underline') {
        const currentDeco = customText.getAttribute('text-decoration') || 'none';
        customText.setAttribute('text-decoration', currentDeco === 'underline' ? 'none' : 'underline');
    }
}