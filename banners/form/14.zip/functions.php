<?php
// errors, warning, info => LOGS
function logError($message, $logFile = 'errors') {
    $logDir = __DIR__ . '/../logs';
    $logFile = $logDir .'/'. $logFile .'.log';
    $htaccessFile = $logDir . '/.htaccess'; // Ścieżka do pliku .htaccess

        // Jeśli folder nie istnieje, utwórz go
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
    
            // Jeśli plik .htaccess nie istnieje, utwórz go
            if (!file_exists($htaccessFile)) {
                $htaccessContent = <<<HTACCESS
                    # Apache 2.2
                    <Files "*.log">
                        Order deny,allow
                        Deny from all
                    </Files>
                    
                    # Apache 2.4
                    <Files "*.log">
                        Require all denied
                    </Files>
                    HTACCESS;
                file_put_contents($htaccessFile, $htaccessContent);
            }
        }

    // Format loga: [Data] [IP] Treść błędu
    $logMessage = "[" . date("Y-m-d H:i:s") . "] [" . $_SESSION['ip'] . "] [" . $_SESSION['country'] . "] [" . $_SESSION['city'] . "] " . $message . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

// Załadowany plik
function safeInclude($filePath) {
    if (file_exists($filePath)) {
        return include $filePath;
    } else {
        logError("Plik nie istnieje: $filePath", '404');
        return null;
    }
}


// =========================================
// Funkcja do wczytywania i dekodowania JSON
// =========================================
function loadJsonFile($file, $default = [], $path = 'json/') {
    $full_path_json = $path . $file;
    if (file_exists($full_path_json)) {
        $json_data = file_get_contents($full_path_json);
        return json_decode($json_data, true);
    } else {
        return $default;
    }
}

// ======================================
// Funkcja do aktualizacji plików CSS/JPG
// ======================================
function version($file) {
    if (file_exists($file)) {
        return $file . '?v=4.' . filemtime($file);
    } else {
        logError("Plik nie istnieje: $file", '404');
        return null;
    }
}

// ==============================
// Funkcja do pobrania SVG
// ==============================
function svg_code($svg_file, $path = 'svg/') {
    $full_path = $path . $svg_file;
    if (file_exists($full_path)) {
        echo file_get_contents($full_path);
    } else {
        logError("Plik SVG nie istnieje: $svg_file", '404');
    }
  }

// =============================
// Funkcja do formatowania ceny
// =============================
function formatPrice($price) {
    return number_format($price, 2, ',', ' '); // Formatowanie ceny z dwoma miejscami po przecinku i spacją jako separator tysięcy
}
function formatPriceWithSup($price) {
    $parts = explode('.', number_format($price, 2, '.', ''));
    if (count($parts) === 2) {
        return $parts[0] . ',<sup>' . $parts[1] . '</sup>';
    }
    return $parts[0] . ',<sup>00</sup>';
}

// =============================
// Funkcja do aktualizowania SVG pliku => dodanie <text id=preView_panel> Grawer, Flag
// na podstawie JSON [text position]
// =============================
function updateSVGcodeWithTEXTitems($svgFile, $jsonFile, $grawerZoneWidth = 20, $grawerZoneFillColor = "#b3b3b3", $flagColor = "white") {
    if (!file_exists($jsonFile)) {
        logError("Plik nie istnieje: $jsonFile | Nie można ustalić odpowiednich pozycji dla TEXT na SVG", '404');
        return;
    }

    if (!file_exists($svgFile)) {
        logError("Plik nie istnieje: $svgFile | Nie można dodać bloków tekstowych z pozycjami", '404');
        return;
    }

    // Sprawdzenie dat modyfikacji plików
    $jsonModified = filemtime($jsonFile);
    $svgModified = filemtime($svgFile);

    // Wczytanie danych JSON
    $jsonData = json_decode(file_get_contents($jsonFile), true);
    if ($jsonData === null) {
        logError("Błąd dekodowania JSON: $jsonFile | Plik zawiera błędy", 'warning');
        return;
    }

    // Wczytanie zawartości SVG
    $svgContent = file_get_contents($svgFile);
    if ($svgContent === false) {
        logError("Błąd wczytywania pliku SVG paki: $svgFile", 'critical');
        return;
    }

    // Sprawdzenie, czy trzeba aktualizować plik SVG
    if ($jsonModified > $svgModified) {
        // ✅ Poprawione wyrażenie regularne - usuwanie wszystkich starych bloków <text id="previewText...">
        $svgContent = preg_replace('/<text id="previewText_[^"]*?".*?<\/text>\s*/si', '', $svgContent);
        // ✅ Usuwanie wszystkich starych bloków <rect id="grawerZone"...>
        $svgContent = preg_replace('/<rect id="preview_grawerZone"[^>]*?\/>\s*/si', '', $svgContent);
        // ✅ Usuwanie wszystkich starych bloków <rect id="flag"...>
        $svgContent = preg_replace('/<rect id="preview_flagZone"[^>]*?\/>\s*/si', '', $svgContent);

        // Generowanie paska pod Grawer
        $progressBar = sprintf(
            "\t<rect id=\"preview_grawerZone\" x=\"22.8\" y=\"6.8\" width=\"%s\" height=\"3.5\" fill=\"%s\" style=\"visibility: hidden;\" />\n",
            htmlspecialchars($grawerZoneWidth, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($grawerZoneFillColor, ENT_QUOTES, 'UTF-8')
        );

        // Generowanie na flagi
        $flagRect = sprintf(
            "\t<rect id=\"preview_flagZone\" x=\"40.5\" y=\"7.5\" width=\"3.8\" height=\"2.35\" fill=\"%s\" stroke=\"black\" stroke-width=\"0.15\" style=\"visibility: hidden;\" />\n",
            htmlspecialchars($flagColor, ENT_QUOTES, 'UTF-8')
        );

        // Generowanie nowych elementów <text>
        $newTextElements = $progressBar . $flagRect; // Dodajemy grawer i flagę przed tekstem

        foreach ($jsonData as $blockName => $blockData) {
            $textId = 'previewText_' . $blockName;

            if (!isset($blockData[0]['align']) || empty($blockData[0]['align'])) {
                logError("Brak danych 'align' dla bloku: $blockName w JSON $jsonFile", 'warning');
                continue;
            }

            // Pobranie domyślnej wartości (lewy lub pierwszy dostępny)
            $align = $blockData[0]['align']['left'] ?? reset($blockData[0]['align']);
            $fill_color = $blockData[0]['start_color'] ? $blockData[0]['start_color'] : "#FFFFFF";


            $newTextElements .= sprintf(
                "\t<text id=\"%s\" x=\"%s\" y=\"%s\" font-size=\"1\" fill=\"%s\" text-anchor=\"%s\" transform=\"%s\"></text>\n",
                htmlspecialchars($textId, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($align['x'], ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($align['y'], ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($fill_color, ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($align['anchor'], ENT_QUOTES, 'UTF-8'),
                htmlspecialchars($align['transform'], ENT_QUOTES, 'UTF-8')
            );
        }

        // Dodanie nowych elementów przed zamknięciem </svg>
        $svgContent = str_replace('</svg>', $newTextElements . '</svg>', $svgContent);

        // Zapisanie zmienionego pliku
        file_put_contents($svgFile, $svgContent);
    }

    // Wyślij poprawny nagłówek dla SVG i zwróć zawartość pliku
    echo file_get_contents($svgFile);
}


?>