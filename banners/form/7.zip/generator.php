<?php
session_start();
require_once 'functions.php';

if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 'error', 'message' => 'Błędny token!']);
    logError('Błędny token', 'error_token');
    exit;
}

// Pobranie danych SVG z DIV
$svgContent = isset($_POST['svg']) ? $_POST['svg'] : null;
if (!$svgContent) {
    echo json_encode(['status' => 'error', 'message' => 'Brak danych SVG!']);
    logError('Brak danych SVG! w getSVGContent() JS', 'error_svg_content');
    exit;
}


if (!isset($_POST['generate'])) {
    logError('Brak parametru generate=... w URL', 'error_generate');
    echo json_encode(['status' => 'error', 'message' => 'Brak parametru generate!']);
    exit;
}

$generateType = trim(htmlspecialchars($_POST['generate']));

switch ($generateType) {
    case 'pdf':
        generatePDF($svgContent, $generateType);
        break;

    case 'jpeg':
        generateImage($svgContent, $generateType);
        break;

    default:
        logError("Nierozpoznany typ generowania pliku: $generateType", 'error_generate_type');
        echo json_encode(['status' => 'error', 'message' => 'Nierozpoznany typ generowania pliku!']);
        exit;
}




// Funkcja generująca PDF
function generatePDF($svgContent, $generateType) {
    require_once('tcpdf/tcpdf.php'); // Załaduj bibliotekę TCPDF

    // Ścieżki do folderów
    $uploadsDir = '../uploads';
    $pdfDir = $uploadsDir . '/' . $generateType;

    // Tworzenie katalogów, jeśli nie istnieją
    if (!file_exists($uploadsDir) && !mkdir($uploadsDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $uploadsDir, 'error_folder');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $uploadsDir]);
        exit;
    }

    if (!file_exists($pdfDir) && !mkdir($pdfDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $pdfDir, 'error_folder');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $pdfDir]);
        exit;
    }

    // Tworzenie nowego PDF
    $pdf = new TCPDF();
    $pdf->AddPage();
    $pdf->SetFont('helvetica', '', 12);
    $pdf->writeHTML($svgContent, true, false, true, false, '');

    // Ścieżka zapisu PDF
    $filePath = $pdfDir . '/hussaria_electra_' . time() . '.pdf';

    // Zapisywanie PDF na serwerze
    $pdf->Output($filePath, 'F');

    if (!file_exists($filePath)) {
        logError('Nie udało się zapisać PDF!', 'error_pdf');
        echo json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać PDF!']);
        exit;
    }

    // Zwrócenie poprawnej odpowiedzi JSON
    echo json_encode(['status' => 'success', 'file_url' => $filePath]);
    exit;
}



// Funkcja generująca obraz
function generateImage($svgContent, $generateType) {
    // Sprawdzenie, czy Imagick jest dostępny
    if (!class_exists('Imagick')) {
        logError('Biblioteka Imagick nie jest dostępna!', 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Biblioteka Imagick nie jest dostępna!']);
        exit;
    }

    // Ścieżki do folderów
    $uploadsDir = '../uploads';
    $imgDir = $uploadsDir . '/' . $generateType;

    // Tworzenie katalogów, jeśli nie istnieją
    if (!file_exists($uploadsDir) && !mkdir($uploadsDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $uploadsDir, 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $uploadsDir]);
        exit;
    }

    if (!file_exists($imgDir) && !mkdir($imgDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $imgDir, 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $imgDir]);
        exit;
    }

    // Ścieżka do pliku wynikowego
    $filePath = $imgDir . '/hussaria_electra_' . time() . '.png';

    // Tworzenie obrazu za pomocą Imagick
    try {
        $image = new Imagick();
        $image->readImageBlob($svgContent); // Odczytanie treści SVG
        // $image->setImageFormat("png"); // Ustawienie formatu na PNG
        $image->setImageFormat("jpeg"); // zamiast "png"
        $image->writeImage($filePath); // Zapisanie pliku
        $image->clear();
        $image->destroy();
    } catch (Exception $e) {
        logError('Błąd przy generowaniu obrazu: ' . $e->getMessage(), 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Błąd generowania obrazu: ' . $e->getMessage()]);
        exit;
    }

    // Sprawdzenie, czy plik został zapisany
    if (!file_exists($filePath)) {
        echo json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać obrazu!']);
        exit;
    }

    // Zwrócenie poprawnej odpowiedzi JSON
    echo json_encode(['status' => 'success', 'file_url' => $filePath]);
    exit;
}


?>
