// ====================================================
// ================ THEME MODE ========================
// ====================================================
document.addEventListener('DOMContentLoaded', () => {

    document.documentElement.setAttribute("data-device", getDeviceType());

    document.getElementById('toggleTheme').addEventListener('click', toggleTheme);

    // czy użytkownik wybrał motyw
    const savedTheme = localStorage.getItem('HEisTheme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }


    // ======== Tooltips =========
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
})

// Switch Theme
// ============
function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('HEisTheme', newTheme); // Theme
    localStorage.setItem('HEisDevice', getDeviceType()); // Device

    // Zmiana logo w zależności od wybranego motywu
    const logo = document.getElementById('logo');
    // const he_icon = document.getElementById('he_icon');
    if (newTheme === 'dark') {
        logo.src = 'img/hussaria_electra_logo_white.png';
        // he_icon.src = 'img/he_icon_white.png';
    } else {
        logo.src = 'img/hussaria_electra_logo_black.png';
        // he_icon.src = 'img/he_icon_black.png';
    }
}

// Check Device
// ============
function getDeviceType() {
    const width = window.innerWidth;
    if (width < 768) {
        return "mobile";
    } else if (width < 1024) {
        return "tablet";
    } else {
        return "desktop";
    }
}