// Zabezpiczenie inputów => CrossSiteInjection
function encodeHTML(str) {
    return str.replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
}

function showError(message) {
    // Wyszukaj element <footer>
    let footer = document.querySelector('footer');
    
    // Sprawdzenie, czy sekcja <footer> istnieje
    if (!footer) {
        return;
    }

    // Tworzenie dynamicznego div dla błędu
    let errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;

    // Dodanie błędu przed <footer>
    footer.parentNode.insertBefore(errorDiv, footer);

    // Wyświetlenie błędu (animacja fade-in)
    setTimeout(() => {
        errorDiv.style.opacity = '1';
    }, 100);

    // Ukrycie błędu po 2 sekundach (animacja fade-out) i usunięcie z DOM
    setTimeout(() => {
        errorDiv.style.opacity = '0';
        setTimeout(() => {
            errorDiv.remove(); // Usunięcie błędu z DOM po animacji
        }, 500);
    }, 2000);
}




// Pobranie zawartości SVG z DIV
function getSVGContent(div_ID, element = 'svg') {
    const svgElement = document.querySelector(`#${div_ID} ${element}`);  // Poprawny selektor
    const svgContent = svgElement ? svgElement.outerHTML : null;  // Sprawdzamy, czy znaleziono element
    return svgContent;
}


// =======================================
// ==== Generator PDF/JPG ================
// =======================================
function generateFile(type) {
    // Pobranie tokena z meta
    const token = document.querySelector('meta[name="token"]').getAttribute('content');

    // Pobranie zawartości SVG z #paka
    const svgData = getSVGContent('paka'); 

    if (!svgData) {
        alert('Błąd: Nie znaleziono elementu SVG!');
        return;
    }

    // Wysłanie danych do PHP
    fetch('include/generator.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
            token: token,
            svg: svgData,
            generate: type
        })
    })
    .then(response => response.text())  // Pobierz odpowiedź jako tekst
    .then(data => {
        console.log(data);  // Sprawdź, co faktycznie wraca z serwera
        try {
            const jsonData = JSON.parse(data);  // Spróbuj sparsować odpowiedź jako JSON
            if (jsonData.status === 'error') {
                showError(jsonData.message);  // Wyświetla błąd, jeśli status to 'error'
            } else {
                window.location.href = jsonData.file_url;
            }
        } catch (e) {
            console.error("Błąd parsowania JSON: ", e);
        }
    })
    .catch(error => {
        console.error('Błąd:', error);
    });
}
