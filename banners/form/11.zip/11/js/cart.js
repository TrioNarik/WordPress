document.addEventListener('DOMContentLoaded', function() {
    const cartButtons = document.querySelectorAll('.addToCart');
    const cartItemsElement = document.getElementById('button_cart_total');
    const cartContainer = document.getElementById('cartBoxPromo');

    // Pobranie istniejących elementów total, delivery, value
    const cartTotalElement = document.getElementById('cartTotal');   // Razem
    const cartDeliveryElement = document.getElementById('cartDelivery'); // Koszt dostawy
    const cartValueElement = document.getElementById('cartValue'); // Wartość zamówienia

    const transInfo = document.getElementById('featured_info_toCart');
    const buttonDeleteText = transInfo.getAttribute('data-delete-button');
    const errorAddToCart = transInfo.getAttribute('data-error-add-message');

    // Obiekt koszyka
    const Cart = {
        items: [],

        async addItem(itemKey, image, name, price, shipping) {
            try {
                const response = await fetch('include/verify-add-to-cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key: itemKey, image, name, price, shipping })
                });

                if (!response.ok) throw new Error(errorAddToCart);
                const result = await response.json();
                if (result.status !== 'success') throw new Error(errorAddToCart);

                const verifiedItem = result.item;
                const existingItem = this.items.find(item => item.key === verifiedItem.key);

                if (existingItem) {
                    existingItem.quantity += 1;
                } else {
                    this.items.push({ ...verifiedItem, quantity: 1 });
                }

                this.updateView();
            } catch (error) {
                showError(error.message);
            }
        },

        removeItem(itemKey) {
            this.items = this.items.filter(item => item.key !== itemKey);
            this.updateView();
        },

        updateView() {
            cartContainer.innerHTML = '';

            let totalPrice = 0;
            let totalShipping = 0;

            this.items.forEach(item => {
                const itemTotal = item.price * item.quantity;
                totalPrice += itemTotal;

                const shippingCost = typeof item.shipping === 'number' ? item.shipping : parseFloat(item.shipping.price || 0);
                totalShipping += shippingCost * item.quantity;

                const itemElement = document.createElement('div');
                itemElement.classList.add('cart-items');
                itemElement.innerHTML = `
                    <div class="row">
                        <div class="col-2">
                            <img class="img-fluid" src="img/${item.image}" alt="${item.name}">
                        </div>
                        <div class="col-4">
                            <span class="name">${item.name}</span>
                            <span class="shipping">${shippingCost.toFixed(2)}</span>
                        </div>
                        <div class="col-2">
                            <span class="price">${itemTotal.toFixed(2)}</span>
                        </div>
                        <div class="col-2">
                            <span class="quantity">${item.quantity}</span>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn btn-danger removeFromCart" data-key="${item.key}">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                    <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `;
                cartContainer.appendChild(itemElement);
            });

            // Aktualizacja wartości w HTML-u
            cartValueElement.textContent = totalPrice.toFixed(2); // Wartość zamówienia
            cartDeliveryElement.textContent = totalShipping.toFixed(2); // Koszt dostawy
            cartTotalElement.textContent = (totalPrice + totalShipping).toFixed(2); // Razem

            cartItemsElement.textContent = this.items.reduce((total, item) => total + item.quantity, 0);

            document.querySelectorAll('.removeFromCart').forEach(button => {
                button.addEventListener('click', function() {
                    Cart.removeItem(this.getAttribute('data-key'));
                });
            });
        }
    };

    // Obsługa przycisków dodawania do koszyka
    cartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const itemKey = this.getAttribute('data-key');
            const image = this.getAttribute('data-img');
            const name = this.getAttribute('data-name');
            const price = parseFloat(this.getAttribute('data-price'));
            const shipping = parseFloat(this.getAttribute('data-shipping'));
            
            Cart.addItem(itemKey, image, name, price, shipping);
        });
    });

});
