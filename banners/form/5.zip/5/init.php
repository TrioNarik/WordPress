<?php
session_start();

$cid = uniqid();

// Pobierz adres IP klienta
$clientIP = $_SERVER['REMOTE_ADDR'];
$accessKey = 'fe78233cc21df3'; // Klucz API z ipinfo.io

// Pobieranie informacji o lokalizacji IP
$response = @file_get_contents("http://ipinfo.io/{$clientIP}?token={$accessKey}");

if ($response === FALSE) {
    // W przypadku błędu pobierania danych (np. z braku połączenia z ipinfo.io)
    $country = '';
    $city = '';
} else {
    // Dekodowanie odpowiedzi
    $details = json_decode($response, true);

    // Sprawdzenie, czy odpowiedź zawiera dane
    if (isset($details['country']) && isset($details['city'])) {
        $country = $details['country'];
        $city = $details['city'];
    } else {
        // Jeżeli brak danych o kraju lub mieście
        $country = '';
        $city = '';
    }
}

$_SESSION['ip'] = $clientIP;
$_SESSION['country'] = $country;
$_SESSION['city'] = $city;
$_SESSION['flagUrl'] = "https://flagcdn.com/16x12/" . strtolower($country) . ".png";

// Generowanie tokena CSRF
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Jeśli użytkownik ma ustawienia w sesji, przekazujemy je do JS
$userConfig = isset($_SESSION['config']) ? json_encode($_SESSION['config']) : 'null';

// Ustawienia konfiguracji
$settings = [
    'color' => $_POST['color'] ?? '',
    'glitter' => $_POST['glitter'] ?? '',
    'text' => $_POST['text'] ?? '',
    'place' => $_POST['place'] ?? '',
    'align' => $_POST['align'] ?? '',
    'font-color' => $_POST['font-color'] ?? '',
    'font-family' => $_POST['font-family'] ?? '',
    'font-size' => $_POST['font-size'] ?? '',
];

// Zapisanie ustawień w sesji
$_SESSION['config'][$cid] = $settings;

?>