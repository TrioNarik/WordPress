<?php
require 'config.php';

// Odbiór danych z PayU
$data = json_decode(file_get_contents('php://input'), true);
$orderId = $data['order']['extOrderId'];
$status = $data['order']['status'];

// Aktualizacja statusu w bazie
$stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_number = ?");
if ($status == 'COMPLETED') {
    $stmt->execute(['paid', $orderId]);
} elseif ($status == 'CANCELED' || $status == 'REJECTED') {
    $stmt->execute(['failed', $orderId]);
}

// Odpowiedź PayU
http_response_code(200);
echo 'OK';
?>
