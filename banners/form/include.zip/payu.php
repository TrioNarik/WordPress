<?php
// Konfiguracja bazy danych
require 'config.php';

// Odbiór danych z formularza
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$totalAmount = $_POST['total_amount'];

// Generowanie numeru zamówienia
$orderNumber = 'ORD' . date('Ymd') . '-' . rand(1000,9999);

// Zapis do bazy danych
$stmt = $pdo->prepare("INSERT INTO orders (order_number, customer_name, customer_email, customer_phone, address, total_amount) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->execute([$orderNumber, $name, $email, $phone, $address, $totalAmount]);

// ID zamówienia
$orderId = $pdo->lastInsertId();

// Przygotowanie do PayU (przykład)
$payuUrl = 'https://secure.snd.payu.com/api/v2_1/orders'; // Sandbox
$clientId = 'YOUR_CLIENT_ID';
$clientSecret = 'YOUR_CLIENT_SECRET';

// Pobranie tokenu dostępu
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://secure.snd.payu.com/pl/standard/user/oauth/authorize");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Basic " . base64_encode("$clientId:$clientSecret")
]);
$response = json_decode(curl_exec($ch), true);
$accessToken = $response['access_token'];
curl_close($ch);

// Utworzenie zamówienia PayU
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $payuUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: Bearer $accessToken",
    "Content-Type: application/json"
]);
$payuData = json_encode([
    "notifyUrl" => "https://twojadomena.pl/payu_notify.php",
    "customerIp" => $_SERVER['REMOTE_ADDR'],
    "merchantPosId" => $clientId,
    "description" => "Zamówienie $orderNumber",
    "currencyCode" => "PLN",
    "totalAmount" => intval($totalAmount * 100), // grosze
    "buyer" => [
        "email" => $email,
        "firstName" => $name,
        "phone" => $phone
    ],
    "products" => [
        [
            "name" => "Produkty z koszyka",
            "unitPrice" => intval($totalAmount * 100),
            "quantity" => 1
        ]
    ]
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, $payuData);
$response = json_decode(curl_exec($ch), true);
curl_close($ch);

// Przekierowanie do płatności
header("Location: " . $response['redirectUri']);
exit;
?>
