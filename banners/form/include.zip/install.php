<?php

// ✅ Formularz z polami: imię, e-mail, telefon, adres, koszyk.
// ✅ Podsumowanie: suma zamówienia, przycisk „Opłać zamówienie”.
// ✅ Przekierowanie do strony „Sukces” / „Błąd płatności”.
// ✅ Regulamin, polityka prywatności, dane kontaktowe.

// Dane dostępowe do MySQL
$host = 'localhost';
$user = 'twoj_user';
$pass = 'twoje_haslo';
$dbname = 'twoja_baza';

// Połączenie z MySQL
$mysqli = new mysqli($host, $user, $pass);

if ($mysqli->connect_error) {
    die("❌ Błąd połączenia z MySQL: " . $mysqli->connect_error);
}
echo "✅ Połączono z MySQL.<br>";

// Utworzenie bazy danych
$mysqli->query("CREATE DATABASE IF NOT EXISTS `$dbname` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
echo "✅ Baza danych '$dbname' utworzona (jeśli nie istniała).<br>";

// Wybór bazy
$mysqli->select_db($dbname);

// Utworzenie tabeli 'orders'
$createOrders = "
CREATE TABLE IF NOT EXISTS `orders` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order` VARCHAR(100) NOT NULL,
    `name` VARCHAR(255) NOT NULL,
    `lastname` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `phone` VARCHAR(50),
    `address` TEXT,
    `total_amount` DECIMAL(10,2) NOT NULL,
    `status` ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    `payment_method` VARCHAR(50),
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if ($mysqli->query($createOrders)) {
    echo "✅ Tabela 'orders' utworzona.<br>";
} else {
    die("❌ Błąd tworzenia tabeli 'orders': " . $mysqli->error);
}

// Utworzenie tabeli 'order_items'
$createItems = "
CREATE TABLE IF NOT EXISTS `order_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `order_id` INT NOT NULL,
    `product` VARCHAR(255) NOT NULL,
    `quantity` INT NOT NULL,
    `price` DECIMAL(10,2) NOT NULL,
    `color` VARCHAR(50),
    `text` VARCHAR(255),
    `font` VARCHAR(100),
    `size` VARCHAR(50),
    `other_options` TEXT,
    FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
";

if ($mysqli->query($createItems)) {
    echo "✅ Tabela 'order_items' utworzona.<br>";
} else {
    die("❌ Błąd tworzenia tabeli 'order_items': " . $mysqli->error);
}



echo "<br>🎉 Instalacja zakończona pomyślnie. Usuń plik <code>install.php</code> dla bezpieczeństwa.";

$mysqli->close();
?>
