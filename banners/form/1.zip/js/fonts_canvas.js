function updateCanvas(canvasEl, font, text, name, rating, badge, colorText = false, backgroundColor = false) {
    const canvas = canvasEl; // Użyj przekazanego elementu canvas zamiast pobierania go ponownie
    const container = canvas.parentNode;
    const ctx = canvas.getContext("2d");

    // Ustaw szerokość i wysokość canvas na 100% szerokości 
    canvas.width = container.clientWidth;
    canvas.height = 85;

    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = backgroundColor ? backgroundColor : "#F0F0F0";
    ctx.fillRect(0, 0, width, height);

    // Draw a Ranking circle
    for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.arc(width - (6 * (i + 1)), 10, 2, 0, 2 * Math.PI);
        ctx.strokeStyle = "#000000"; // Kolor obrysu
        ctx.stroke();
    }

    // Wypełnianie kół na podstawie oceny
    for (let i = 0; i < rating; i++) {
        ctx.beginPath();
        ctx.arc(width - (6 * (i + 1)), 10, 2, 0, 2 * Math.PI);
        ctx.fillStyle = "#000000"; // Kolor wypełnienia
        ctx.fill();
    }

    // Draw name
    ctx.font = "10px Montserrat, sans-serif";
    ctx.fillStyle = "#000000";
    ctx.textAlign = "left";
    ctx.fillText(name, 5, 10);

    // Draw badge
    ctx.font = "9px Montserrat, sans-serif";
    ctx.fillStyle = "#000000";
    ctx.fontVariantCaps = "small-caps";
    ctx.letterSpacing = "5px";
    ctx.textAlign = "left";
    ctx.fillText(badge, 5, height / 2);

    ctx.font = font;
    ctx.fillStyle = colorText ? colorText : "#000000";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const displayText = text.trim() ? text : `${name}`;
    ctx.fillText(displayText, width / 2, height / 2);
}

function updateAllCanvases() {
    const inputText = encodeHTML(document.getElementById("text_toppanel").value);
    // const backgroundColor = document.getElementById("favcolor").value;
    const textColor = document.querySelector('.color-txt.selected')?.getAttribute('data-color') || '#000000';

    document.querySelectorAll('canvas').forEach(canvasEl => {
        const font = canvasEl.getAttribute('data-font');
        const name = canvasEl.getAttribute('data-name');
        const family = canvasEl.getAttribute('data-family');
        const rating = parseInt(canvasEl.getAttribute('data-rating'), 10); // Rating jest liczbą
        const badge = canvasEl.getAttribute('data-badge');
        updateCanvas(canvasEl, font, inputText, name, rating, badge, textColor);

        // Dodaj obsługę zdarzenia click
        canvasEl.addEventListener('click', () => {
            // Usuń klasę .selected z wszystkich canvasów
            document.querySelectorAll('canvas').forEach(c => c.classList.remove('selected'));
            // Dodaj klasę .selected do klikniętego canvasu
            canvasEl.classList.add('selected');

            // Ustaw font na SVG
            document.getElementById("previewText").setAttribute("font-family", family);

        });

        // Ustaw kolor font na SVG
        document.getElementById("previewText").setAttribute("fill", textColor);
    });

}


document.getElementById("text_toppanel").addEventListener("input", updateAllCanvases);
// document.getElementById("favcolor").addEventListener("input", updateAllCanvases);

document.querySelectorAll('.color-txt').forEach(colorOption => {
    colorOption.addEventListener('click', event => {
        event.preventDefault();
        document.querySelectorAll('.color-txt').forEach(c => c.classList.remove('selected'));
        colorOption.classList.add('selected');
        updateAllCanvases();
    });
});

updateAllCanvases(); // Initial update
