<?php
require_once __DIR__ . '/includes/db/connection.php';
require_once __DIR__ . '/includes/core/BlockManager.php';
require_once __DIR__ . '/includes/core/helpers.php';

$theme = ['name' => 'default'];
$lang = 'pl';

$bm = new BlockManager($pdo);
$bm->registerBlock('header', 'FO', 'Nagłówek strony');
$bm->registerBlock('article', 'FO', 'Treść artykułu');
$bm->registerBlock('footer', 'FO', 'Stopka strony');

// Przykład dynamicznego hooka:
add_hook('displayHeaderBefore', function() use ($theme) {
    echo "<div class='notice'>Dynamiczny komunikat przed nagłówkiem</div>";
}, 5);
