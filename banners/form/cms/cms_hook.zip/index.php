<?php
require_once __DIR__ . '/init.php';
require_once __DIR__ . '/themes/' . THEME . '/layout.php';
