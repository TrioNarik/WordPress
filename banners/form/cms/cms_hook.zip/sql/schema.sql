CREATE TABLE IF NOT EXISTS cms_blocks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    category ENUM('FO', 'BO', 'API', 'AJAX') DEFAULT 'FO',
    description TEXT,
    active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cms_hooks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    block_name VARCHAR(50) NOT NULL,
    hook_name VARCHAR(100) NOT NULL,
    category ENUM('FO', 'BO', 'API', 'AJAX') DEFAULT 'FO',
    description TEXT,
    UNIQUE(block_name, hook_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS cms_module_hooks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    module_alias CHAR(15) NOT NULL,
    hook_name VARCHAR(100) NOT NULL,
    priority INT DEFAULT 10,
    active TINYINT(1) DEFAULT 1,
    settings JSON DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
