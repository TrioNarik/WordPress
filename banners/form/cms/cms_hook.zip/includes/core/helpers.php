<?php

require_once __DIR__ . '/HookManager.php';

global $hookManager;
$hookManager = null;

function add_hook(string $hookName, callable $callback, int $priority = 10): void {
    global $hookManager;
    if (!$hookManager) {
        global $pdo;
        $hookManager = new HookManager($pdo);
    }
    $hookManager->addHook($hookName, $callback, $priority);
}

function do_hook(string $hookName, ...$args): void {
    global $hookManager;
    if (!$hookManager) {
        global $pdo;
        $hookManager = new HookManager($pdo);
    }
    $hookManager->doHook($hookName, $args);
}

function renderBlock(string $blockName): void {
    do_hook("display" . ucfirst($blockName) . "Before");
    do_hook("display" . ucfirst($blockName));
    do_hook("display" . ucfirst($blockName) . "After");
}


function renderThemeBlock(string $blockName): void {
    global $theme, $lang;

    if (!isset($theme) || !is_array($theme) || empty($theme['name'])) {
        trigger_error("Brak zdefiniowanego globalnego \$theme lub niepoprawna struktura.", E_USER_WARNING);
        return;
    }
    if (!isset($lang)) {
        trigger_error("Brak zdefiniowanego globalnego \$lang.", E_USER_WARNING);
        $lang = null; // albo $lang = 'pl'; — domyślny język
    }

    // Ścieżka do pliku bloku w aktywnym motywie
    $blockFile = __DIR__ . "/../../themes/{$theme['name']}/blocks/{$blockName}.php";

    // Hook przed blokiem
    do_hook("display" . ucfirst($blockName) . "Before");

    if (file_exists($blockFile)) {
        include $blockFile;
    } else {
        renderBlock($blockName);
    }

    // Hook po bloku
    do_hook("display" . ucfirst($blockName) . "After");
}
