<?php

class BlockManager {
    private PDO $pdo;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function registerBlock(string $blockName, string $category = 'FO', string $description = ''): void {
        $stmt = $this->pdo->prepare("INSERT IGNORE INTO cms_blocks (name, category, description) VALUES (?, ?, ?)");
        $stmt->execute([$blockName, $category, $description]);
        $this->generateHooksForBlock($blockName, $category);
    }

    private function generateHooksForBlock(string $blockName, string $category): void {
        $base = ucfirst($blockName);
        $hooks = [
            "display{$base}Before",
            "display{$base}",
            "display{$base}After",
            "action{$base}"
        ];

        foreach ($hooks as $hookName) {
            $stmt = $this->pdo->prepare("INSERT IGNORE INTO cms_hooks (block_name, hook_name, category) VALUES (?, ?, ?)");
            $stmt->execute([$blockName, $hookName, $category]);
        }
    }
}
