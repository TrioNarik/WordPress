<?php
class HookManager {
    private PDO $pdo;
    private array $dynamicHooks = [];

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
    }

    public function addHook(string $hookName, callable $callback, int $priority = 10): void {
        if (!isset($this->dynamicHooks[$hookName])) {
            $this->dynamicHooks[$hookName] = [];
        }
        $this->dynamicHooks[$hookName][] = ['callback' => $callback, 'priority' => $priority];
        usort($this->dynamicHooks[$hookName], fn($a, $b) => $a['priority'] <=> $b['priority']);
    }

    public function doHook(string $hookName, array $args = []): void {
        // 1. Dynamic hooks (PHP closures)
        if (!empty($this->dynamicHooks[$hookName])) {
            foreach ($this->dynamicHooks[$hookName] as $item) {
                call_user_func_array($item['callback'], $args);
            }
        }

        // 2. Moduły z bazy
        $stmt = $this->pdo->prepare("SELECT module_alias, settings FROM cms_module_hooks WHERE hook_name = ? AND active = 1 ORDER BY priority ASC");
        $stmt->execute([$hookName]);
        $modules = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($modules as $module) {
            $alias = $module['module_alias'];
            $settings = json_decode($module['settings'] ?? '{}', true);
            $modulePath = __DIR__ . "/../../modules/$alias/hook.php";
            if (file_exists($modulePath)) {
                include_once $modulePath;
                $func = "hook_" . $alias;
                if (function_exists($func)) {
                    call_user_func($func, ...$args, $settings);
                }
            }
        }
    }
}
