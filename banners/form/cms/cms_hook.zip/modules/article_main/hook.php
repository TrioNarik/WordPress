<?php
function hook_article_main($theme, $lang, $settings = []) {
    echo "<h2>{$settings['title'] ?? 'Domyślny tytuł artykułu'}</h2>";
    echo "<p>Zawartość z modułu <strong>article_main</strong></p>";
}
