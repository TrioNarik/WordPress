<?php
function hook_footer_logo($theme, $lang, $settings = []) {
    echo "<div class='text-center mt-3'><small>Powered by Hussaria</small></div>";
}
