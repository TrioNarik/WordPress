<main class="site-article container my-5">
    <?php renderBlock('article'); ?>
</main>
