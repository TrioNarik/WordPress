<header class="site-header bg-light p-3">
    <?php renderBlock('header'); ?>
</header>
