<footer class="site-footer bg-dark text-white p-3">
    <?php renderBlock('footer'); ?>
</footer>
