<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>CMS z motywami</title>
    <link rel="stylesheet" href="/themes/default/assets/css/style.css">
</head>
<body>

    <?php renderThemeBlock('header'); ?>

    <main>
        <?php renderThemeBlock('article'); ?>
    </main>

    <?php renderThemeBlock('footer'); ?>

</body>
</html>
