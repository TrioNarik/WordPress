<?php

class LanguageList {
    protected $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function getLanguages($prefix = '') {
        $stmt = $this->pdo->query("SELECT name, iso, flag, currency FROM {$prefix}cms_languages WHERE active = 1");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}