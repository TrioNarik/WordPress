<?php
$current_page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'dashboard';
$current_mode = isset($_GET['mode']) ? htmlspecialchars($_GET['mode']) : false;

$userRole = isset($_SESSION['HE_role']) ? $_SESSION['HE_role'] : 'guest';

// $modules = $pdo->fetchAll("SELECT * FROM " . $settings['prefix'] . "cms_modules WHERE active = 1 AND hook = 'sidebar'");

// // Include active modules
// if (!empty($modules)) {
//     foreach ($modules as $module) {
//         $modulePath = _HE_MODULES_DIR_ . $module['path'] . '/' . $module['path'] . '.php';
//         if (file_exists($modulePath)) {
//             include_once $modulePath;
//         }
//     }
// }

// ====================
// Dodaj LOGO
// ====================
add_hook('sidebar_top', function() use ($theme) {
    renderLogo($theme);
}, 20);

function renderLogo($theme) {
    echo '<div class="logo-wrapper mb-2 mb-md-4 d-flex gap-3 align-items-top justify-content-between">
        <div class="logo">
            <a href="https://electra.hussaria.pl/configurator">
                <img id="logo" class="img-fluid" 
                     src="' . _HE_THEMES_ . $theme['path'] . _HE_THEME_MEDIA_ . 'img/hussaria_electra_logo_white.png?v=' . $theme['version'] . '" 
                     alt="Hussaria Electra">
            </a>
        </div>
        <span>powered by <strong>HE</strong></span>
    </div>';
}

add_hook('sidebar_top', function() use ($theme) {
    renderLang($theme);
}, 10);

function renderLang($theme) {
        echo 'Tu będą języki';
}

// ====================
// Dodaj MENU
// ====================
add_hook('sidebar_content', function() use ($lang, $theme, $userRole, $current_page, $current_mode) {
    renderMenuPages($lang, $theme, $userRole, $current_page, $current_mode);
}, 10);

function renderMenuPages($lang, $theme, $userRole, $current_page, $current_mode) {
    echo '<ul class="nav flex-column">';

    foreach ($lang['pages'] as $key => $pageData) {

        if (!empty($pageData['active']) && in_array($userRole, $pageData['groups'])) {
            echo '<li class="menu ' . ($current_page === $key ? 'current' : '') . '">
                <a class="pageMenu ' . $key . ' d-flex gap-3 align-items-center justify-content-start ' . ($current_page === $key ? 'active' : '') . '" href="?page=' . htmlspecialchars($key) . '">
                    <div class="dashIcon d-flex align-items-center justify-content-center">
                        ' . svg_code($pageData['icon'] ?? '', $theme['path']) . '
                    </div>
                    <div class="dashTitle">
                        ' . htmlspecialchars($pageData['title'] ?? ucfirst($key)) . '
                    </div>
                </a>';

            if (!empty($pageData['content']['menu']) && is_array($pageData['content']['menu'])) {
                echo '<ul class="subMenu">';
                foreach ($pageData['content']['menu'] as $menuKey => $menuLabel) {
                    $isRestricted = false;
                    
                    if (isset($pageData['content']['limited'])) {
                        $limitedGroups = $pageData['content']['limited']['groups'] ?? [];
                        $limitedMenuKeys = $pageData['content']['limited']['menuKey'] ?? [];
                        
                        if (in_array($menuKey, $limitedMenuKeys) && !in_array($userRole, $limitedGroups)) {
                            $isRestricted = true;
                        }
                    }

                    if (!$isRestricted) {
                        echo '<li>';
                        echo '<a class="mode ' . ($current_page === $key && $current_mode === $menuKey ? 'active' : '') . '" 
                                href="?page=' . htmlspecialchars($key) . '&mode=' . htmlspecialchars($menuKey) . '">
                                ' . htmlspecialchars($menuLabel) . '</a>';
                        echo '</li>';
                    }
                }
                echo '</ul>';
            }
            echo '</li>';
        }
    }

    echo '</ul>';
}

?>


<!-- Sidebar -->
<nav class="col-12 col-md-<?= $theme['sidebar'] ?> bg-dark text-light sidebar vh-100 p-1 p-md-3 flex-column">

    <div class="sidebar-before">
        <?php do_hook('sidebar_before'); ?>        
    </div>

    <div class="sidebar-top">
        <?php do_hook('sidebar_top'); ?>        
    </div>

    <div class="sidebar-content">
        <?php do_hook('sidebar_content'); ?>
    </div>

    <div class="sidebar-bottom">
        <?php do_hook('sidebar_bottom'); ?>        
    </div>
    
    <div class="sidebar-after">
        <?php do_hook('sidebar_after'); ?>
    </div>


    

    <ul class="nav flex-column">
        <?php foreach ($lang['pages'] as $key => $pageData): ?>

            <?php if (!empty($pageData['active']) && in_array($userRole, $pageData['groups'])): ?>

                <li class="menu <?= $current_page === $key ? 'current' : '' ?>">
                    <a class="pageMenu <?= $key; ?> d-flex gap-3 align-items-center justify-content-start <?= $current_page === $key ? 'active' : '' ?>" href="?page=<?= htmlspecialchars($key) ?>">
                        <div class="dashIcon d-flex align-items-center justify-content-center">
                            <?= svg_code($pageData['icon'] ?? '', $theme['path']) ?>
                        </div>
                        <div class="dashTitle">
                            <?= htmlspecialchars($pageData['title'] ?? ucfirst($key)) ?>
                        </div>
                    </a>

                    <?php if (!empty($pageData['content']['menu']) && is_array($pageData['content']['menu'])): ?>
                        <ul class="subMenu">
                            <?php foreach ($pageData['content']['menu'] as $menuKey => $menuLabel): ?>

                                <?php
                                // Ogranicz zdefionowane w lang => JSON dostęp do subMenu dla wybranych grup użytkowników
                                $isRestricted = false;
                                
                                if (isset($pageData['content']['limited'])) {
                                    
                                    $limitedGroups = $pageData['content']['limited']['groups'] ?? [];
                                    $limitedMenuKeys = $pageData['content']['limited']['menuKey'] ?? [];
                                    
                                    if (in_array($menuKey, $limitedMenuKeys) && !in_array($userRole, $limitedGroups)) {
                                        $isRestricted = true;
                                    }
                                }
                                // ========================
                                if (!$isRestricted): ?>
                                    <li>
                                        <a class="mode <?= ($current_page === $key && $current_mode === $menuKey) ? 'active' : '' ?>" 
                                           href="?page=<?= htmlspecialchars($key) ?>&mode=<?= htmlspecialchars($menuKey) ?>">
                                            <?= htmlspecialchars($menuLabel) ?>
                                        </a>
                                    </li>
                                <?php endif; ?>
                                
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>

                </li>
            <?php endif; ?>

        <?php endforeach; ?>
    </ul>
</nav>
