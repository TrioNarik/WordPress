<?php
// ============================
// Sprawdzenie czy użytkownik jest zalogowany
// ============================
if (!isset($_SESSION['user_id'])) {
    echo '<div class="alert alert-danger">' . $lang['errors']['page']['access_denied'] . '</div>';
    // exit;
}
?>


<!-- Content -->
<section class="content p-1 p-md-3 mb-2 mb-md-4">

<?php if ($lang['pages'][$page]['active']): ?>

    <?php if (isset($lang['pages'][$page]['content']['message']['header'])): ?>
        <div class="title">
            <h4><?= $lang['pages'][$page]['content']['message']['header'] ?></h4>
        </div>
    <?php endif; ?>

    <?php if (isset($lang['pages'][$page]['content']['message']['txt'])): ?>
        <div class="txt"><?= $lang['pages'][$page]['content']['message']['txt'] ?></div>
    <?php endif; ?>
    
<?php endif; ?>

</section>

<section class="tables">
    <hr />
    <table>
       TU tabele z podsumowaniem
    </table>
    <hr />
</section>


 <?php
 add_hook('page_bottom', function() {
    echo '<p>Informacja w stopce</p>';
});
    do_hook('page_bottom');
?>

<section class="tables">
    <hr />
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Lp.</th>
                <th>Nazwa klienta</th>
                <th>Liczba zamówień</th>
                <th>Suma zamówień [PLN]</th>
            </tr>
        </thead>
        <tbody>
        <?php

        
        $users = $pdo->fetchAll("SELECT * FROM " . $settings['prefix'] . "users");

        print_r($users);
        
        if (!$users) {
            echo '<tr><td colspan="4" class="text-center">Brak danych do wyświetlenia.</td></tr>';
            exit;
        }

        // Pobranie danych użytkownika
        $userId = $_SESSION['user_id'];
        $userQuery = $pdo->prepare("SELECT * FROM " . $settings['prefix'] . "users WHERE id = ?");
        $userQuery->execute([$userId]);
        $currentUser = $userQuery->fetch();

        if (!$currentUser) {
            echo '<div class="alert alert-danger">Błąd: Nie znaleziono danych użytkownika.</div>';
            exit;
        }
        
       

        

        // // Przykładowe zapytanie: podsumowanie zamówień wg klientów
        // $sql = "SELECT c.name AS client_name, COUNT(o.id) AS orders_count, SUM(o.total) AS orders_sum
        //         FROM he_customers c
        //         LEFT JOIN he_orders o ON o.customer_id = c.id
        //         GROUP BY c.id
        //         ORDER BY orders_sum DESC
        //         LIMIT 10";
        // $stmt = $pdo->query($sql);
        // $lp = 1;
        // foreach ($stmt as $row) {
        //     echo '<tr>';
        //     echo '<td>' . $lp++ . '</td>';
        //     echo '<td>' . htmlspecialchars($row['client_name']) . '</td>';
        //     echo '<td>' . (int)$row['orders_count'] . '</td>';
        //     echo '<td>' . number_format($row['orders_sum'], 2, ',', ' ') . '</td>';
        //     echo '</tr>';
        // }
        ?>
        </tbody>
    </table>
    <hr />
</section>
