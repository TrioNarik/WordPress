<?php
session_start();

// SETUP
require_once 'setup.php';
if (!defined('_HE_PATH_')) {
	exit;
}

// HOOKS
require_once _HE_INCLUDE_DIR_ . 'hooks.php';

// HELPER
require_once _HE_INCLUDE_DIR_ . 'functions.php';

$settings = require_once _HE_INCLUDE_DIR_ . 'settings.php';

// Jeśli użytkownik nie zalogowany => przekieruj do LOGIN
if (!isset($_SESSION['HE_logged_in']) || $_SESSION['HE_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// ==== CLASSES ====
require_once _HE_CLASSES_DIR_ . 'Database.php';

require_once _HE_CLASSES_DIR_ . 'Languages.php';


$pdo = new Database($settings['db_sql']['host'], $settings['db_sql']['dbname'], $settings['db_sql']['user'], $settings['db_sql']['password']);



$langList = new LanguageList($pdo);
$languages = $langList->getLanguages($settings['db_sql']['prefix']);

foreach ($languages as $lang) {
    echo '<li>';
    echo '<img src="path/do/flag/' . htmlspecialchars($lang['flag']) . '" alt="' . htmlspecialchars($lang['name']) . '">';
    echo htmlspecialchars($lang['name']) . ' (' . htmlspecialchars($lang['iso']) . ')';
    echo '</li>';
}

// ================================
// ======== PANEL BO ==============
// ================================
$availableThemes = [];
// Dostępne Motywy
$availableThemes = getAvailableThemes($settings);

if (!empty($availableThemes)) {

    // * start - Active Theme *
    foreach ($availableThemes as $key => $theme) {

        
        //======= LANG ==========
        // ======================

        // Lang from GET lub theme => default lang
        $lang_theme = (isset($_GET['lang']) && preg_match('/^[a-z]{2}$/', $_GET['lang'])) ? $_GET['lang'] : $theme['lang'];

        // Session
        $_SESSION['HE_lang'] = $lang_theme;

        // Pobierz dostępne langs z settings => themes => languages
        $availableLanguages = getThemeLanguages(_HE_THEMES_DIR_ . $theme['path'] . _HE_THEME_LANG_DIR_);

        // Pobierz language file z folderu /theme/
        $lang_file = _HE_THEMES_DIR_ . $theme['path'] . _HE_THEME_LANG_DIR_ . $lang_theme . '.json';

        if (file_exists($lang_file)) {
            $lang_json = file_get_contents($lang_file);
            $lang = json_decode($lang_json, true);

            if ($lang === null) {
                // JSON decode error
                $lang = [];
            }

        } else {
            // Pusty lang
            $lang = [];
        }
    // * end - Active Theme *
    }

  
    // Pobieranie roli użytkownika z sesji
    $userRole = isset($_SESSION['HE_role']) ? $_SESSION['HE_role'] : 'guest';

    // Pobieranie listy dostępnych PAGE [slug], które są aktywne i dozwolone dla użytkowników [Groups]
    $allowedPages = [];
    foreach ($lang['pages'] as $pageName => $pageData) {
        if ($pageData['active'] == 1 && in_array($userRole, $pageData['groups'])) {
            $allowedPages[] = $pageName;
        }
    }


    // Pobieranie i sanitacja danych wejściowych
    $page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'dashboard';
    $mode = isset($_GET['mode']) ? htmlspecialchars($_GET['mode']) : false;


    if (!in_array($page, $allowedPages)) {
        $page = 'dashboard'; // Domyślna strona
    }

    // Pobieranie listy dozwolonych trybów MENU dla danej strony [slug]
    $allowedModes = isset($lang['pages'][$page]['content']['menu']) ? array_keys($lang['pages'][$page]['content']['menu']) : [];

    if ($mode && !in_array($mode, $allowedModes)) {
        $mode = false; // Domyślny tryb
    }

} else {
    header('Location: index.php');
    exit;
}



?>



<?php getHead($theme, $lang, $page); ?>

<main class="container-fluid">
    <div class="row">
    
        <?php getSidebar($theme, $lang, $page, $allowedPages, $settings['db_sql'], $pdo); ?>

        <!-- Content -->
        <div class="col ms-sm-auto p-1 p-md-3">
            <?php do_hook('content_before'); ?>
            <?php do_hook('content_top'); ?>
            <?php do_hook('content_center'); ?>
            <?php do_hook('content_bottom'); ?>
            <?php do_hook('content_after'); ?>

        <?php if ($page): ?>
            <?php getPage($theme, $lang, $page, $allowedPages, $settings['db_sql'], $pdo, $mode ); ?>
        <?php endif; ?>


            <pre>
            ==============
            <a href="logout.php">Wyloguj</a> => PANEL.PHP
            ==============
            </pre>

        </div>
    </div>
</main>

<?php do_hook('footer_before'); ?>
<?php do_hook('footer_top'); ?>
<?php do_hook('footer_center'); ?>
<?php do_hook('footer_bottom'); ?>
<?php do_hook('footer_after'); ?>

<?php getFooter($theme); ?>
