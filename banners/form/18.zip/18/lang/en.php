<?php
return [
    'settings' => [
        'theme' => 'Change theme',
        'currency' => 'EUR',
        'discount' => [
            'name' => 'Discount',
            'value' => 0,
        ],
        'fees' => [
            'name' => 'Fees' ,
            'value' => 0,
        ]
    ],

    'title' => 'Configurator ⚡ Electric Tack Locker 🔋 Hussaria Electra 🚀',
    'header' => 'Order form',
    'helper' => 'Configure your package and submit the form, and we will contact you and guide you through the next stage of the order 😊',
    'form' => [
        'colors' => [
            'title' => 'Color tack locker',
            'fields' => [
                'label' => 'Color',
                'help' => 'Select the color',
                'info' => '',
            ]
        ],
        'glitter' => [
            'title' => 'Brocade',
            'fields' => [
                'label' => 'Brocade',
                'help' => '',
                'info' => '',
            ],
            'price' => [
                'show' => 0,
                'value' => 0,
                'promo' => '',
            ]
        ],
        'marker' => [
            'title' => 'Personalization',
            'fields' => [
                'label' => 'Personalization',
                'help' => 'Select options',
                'info' => 'Available package personalization options',
                'holder' => 'Text',
            ],
            'options' => [
                'grawer' => [
                    'title' =>'Engraving',
                    'price' => [
                        'show' => 0,
                        'value' => 0,
                        'promo' => '',
                    ],
                ],
                'texts' => [
                    'title' =>'Text',
                    'price' => [
                        'show' => 0,
                        'value' => 0,
                        'promo' => '',
                    ],
                ],
            ],
            'tools' => [
                'font-color' => 'Color',
                'font-align' => 'Alignment',
                'font-style' => 'Formatting',
                'font-size' => 'Size',
                'font-family' => 'Font',
                
            ],
            'flag' => [
                'title' => 'Flag',
                'fields' => [
                    'label' => 'Flag',
                    'holder' => 'Country',
                    'info' => '',
                ],
                'price' => [
                        'show' => 0,
                        'value' => 0,
                        'promo' => '',
                    ],
            ]
        ],
        'info' => [
            'send-pdf' => 'Send additional high-quality images files into PDF format',
            'send-mail' => 'biuro@hussaria.pl'
        ],
        'buttons' => [
            'save' => 'Save configuration',
            'cart' => 'Cart',
            'add' => 'Add to cart',
            'view' => 'View cart',
            'submit' => 'Order',
            'delete' => 'Remove'
        ],
        'cart' => [
            'product-image' => 'Image',
            'product-name' => 'Name',
            'product-quantity' => 'Quantity',
            'product-total' => 'Total',
        ],
        'errors' => [
            'add-product' => 'Error: Cannot add product to cart!',
            'del-product' => 'Error: Cannot remove product from cart!',
        ],
        
        // ========================

        'person' => [
            'title' => 'Personal data',
            'fields' => [
                'first_name' => 'First Name / Company',
                'last_name' => 'Last Name / Tax Identification',
                'email' => 'E-mail',
                'phone' => 'Phone',
            ],
        ],

        'prepayment' => [
            'active' => 1,
            'title' => 'Payment',
            'fields' => [
                'checkbox' => 'Payment',
                'amount' => 'Prepayment amount'
                ],
        ],
        'order' => [
            'title' => 'Order',
            'accept' => [
                'title' => 'I consent to the processing of personal data entered in the form in order to respond to the submitted inquiry in accordance with',
                'name' => 'the Privacy Policy',
                'link' => 'https://electra.hussaria.pl/en/content/17-privacy-policy',
            ],
            'agree' => [
                'title' => 'I accept',
                'name' => 'statute',
                'link' => 'https://electra.hussaria.pl/pl/content/16-regulamin',
                'shop' => 'of online shop'
            ]
        ],
        'order_summary' => [
            'value' => 'Order value',
            'cost' => 'Shipping cost',
            'amount' => 'Total',
            'back' => 'Return',
            'notification' => 'The product has been added!',
            'confirm' => 'Thank you for ordering!',
        ]
    ],
    
    //===============
    'package' => [
        'active' => 1,
        'name' => 'Electric Tack Locker',
        'desc' => 'Electric Tack Locker - order ⚙️🛒 the perfect solution for storing saddles and riding equipment for demanding competitors and equestrian enthusiasts. Equipped with large wheels and an electric drive, it eliminates physical effort and ensures easy maneuverability.',
        'keywords' => 'tack locker, hussaria electra, electric tack locker, electric drive, powered tack locker',
        'thumb' => 'he_thumb_elektryczna_paka.png',
        'status' => 'In stock',
        'deadline' => 'When the goods are not in stock, the delivery time is extended to 3-4 weeks',
        
        'show_price' => 1,
        'price' => 8890,
        'promo' => '',
        'shipping' => [
            'active' => 1,
            'free' => 1,
            'price' => 0,
            'promo' => '',
            'class' => 'dark',
            'content' => 'Free shipping',
            'info' => 'all over Poland',
            'source' => 'Only on electra.hussaria.pl',
        ],
        'include' => [
            'intro_products' => 'Included',
            'products' => [
                'battery' => [
                    'active' => 1,
                    'name' => 'Battery',
                    'desc' => 'Capacity: 4 Ah',
                    'image' => 'battery.png',
                ],
                'charger' => [
                    'active' => 1,
                    'name' => 'Charger',
                    'desc' => 'To battery',
                    'image' => 'charger.png',
                ],
                'pomp' => [
                    'active' => 1,
                    'name' => 'Electric pump',
                    'desc' => 'with powerbank function',
                    'image' => 'pomp.png',
                ],
                'pharmacy' => [
                    'active' => 1,
                    'name' => 'First aid kit',
                    'desc' => 'Medical kit',
                    'image' => 'pharmacy.png',
                ],
                'lock' => [
                    'active' => 1,
                    'name' => 'Combination padlock',
                    'desc' => 'Protective clasp',
                    'image' => 'lock.png',
                ],
                'powerbank' => [
                    'active' => 1,
                    'name' => 'PowerBank',
                    'desc' => 'With quick charge function',
                    'image' => 'powerbank.png',
                ],
                'cables' => [
                    'active' => 1,
                    'name' => 'Cable set',
                    'desc' => '3in1 Phone Charging Cable Set',
                    'image' => 'cables.png',
                ],
                'gadgets' => [
                    'active' => 1,
                    'name' => 'Gadget Set',
                    'desc' => 'A fabric shopping bag, a stylish baseball cap, tactical scissors with a screwdriver set, a thermos mug, a magnetic dry erase board with a set of accessories.',
                    'image' => 'gadgets.png',
                ],
            ],
            

        ]
    ],
    // ==============
    'extra' => 'Additionally in the offer',
    'products' => [
        'promo_battery' => [
            'active' => 1,
            'name' => 'Battery',
            'desc' => '',
            'parameters' => [
                'name' => 'Capacity',
                'value' => '4 Ah',
            ],
            'status' => 'In stock',
            'delivery' => 'Immediate shipping possible',
            'image' => 'battery_4ah.png',
            'show_price' => 1,
            'price' => 980,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Delivery from',
            ],
        ],
        'promo_charger' => [
            'active' => 1,
            'name' => 'Battery charger',
            'desc' => '',
            'parameters' => [
                'name' => '',
                'value' => '',
            ],
            'status' => 'In stock',
            'delivery' => 'Immediate shipping possible',
            'image' => 'charger_4_5ah.png',
            'show_price' => 1,
            'price' => 560,
            'shipping' => [
                'active' => 0,
                'free' => 0,
                'price' => 0,
                'class' => '',
                'content' => 'Delivery from',
            ],
        ],
        'promo_ramp' => [
            'active' => 1,
            'name' => 'Foldable loading ramp',
            'desc' => 'Convenient to use and easy to store, ideal for quick loading and unloading. When folded, it takes up very little space.',
            'parameters' => [
                'name' => 'Max load',
                'value' => '270 kg',
            ],
            'status' => 'In stock',
            'delivery' => 'Immediate shipping possible',
            'image' => 'ramp_270kg.png',
            'show_price' => 1,
            'price' => 1490,
            'shipping' => [
                'active' => 0,
                'free' => 0,
                'price' => 200,
                'class' => '',
                'content' => 'Delivery from',
            ],
        ],
        'promo_battery5' => [
            'active' => 1,
            'name' => 'Battery',
            'desc' => '',
            'parameters' => [
                'name' => 'Capacity',
                'value' => '5 Ah',
            ],
            'status' => 'In stock',
            'delivery' => 'Immediate shipping possible',
            'image' => 'battery_4ah.png',
            'show_price' => 1,
            'price' => 1100,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Delivery from',
            ],
        ],
        'promo_cover' => [
            'active' => 1,
            'name' => 'Case',
            'desc' => '',
            'parameters' => [
                'name' => 'Color',
                'value' => 'black',
            ],
            'status' => 'In stock',
            'delivery' => 'Immediate shipping possible',
            'image' => 'tack_cover.png',
            'show_price' => 1,
            'price' => 2078.70,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Delivery from',
            ],
        ],
        'promo_cover_trap' => [
            'active' => 1,
            'name' => 'Gangway cover',
            'desc' => '',
            'parameters' => [
                'name' => 'Color',
                'value' => 'black',
            ],
            'status' => 'In stock',
            'delivery' => 'Immediate shipping possible',
            'image' => 'ramp_cover.png',
            'show_price' => 1,
            'price' => 479.70,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Delivery from',
            ],
        ],
        
    ],
];