<?php
session_start();

// Sprawdzenie tokena CSRF
if (!isset($_SERVER['HTTP_X_CSRF_TOKEN']) || $_SERVER['HTTP_X_CSRF_TOKEN'] !== $_SESSION['csrf_token']) {
    http_response_code(403);

    if (!isset($_SESSION['security']['cart']['invalid_token'])) {
        $_SESSION['security']['cart']['invalid_token'] = 1;
    } else {
        $_SESSION['security']['cart']['invalid_token']++;
    }

    echo json_encode(['status' => 'error', 'message' => 'Nieautoryzowany dostęp.']);
    logError('Nieautoryzowany dostęp podczas dodawania dodatkowych produktów do Koszyka. Błędny token !', 'invalid_token');
    exit;
}

// ===================
$admin_config = require '../config/admin.php'; // ustawienia

// Blokoda prób
// if ($_SESSION['security']['cart']['invalid_token'] > $admin_config['admin']['attempts']) {
//     logError('Zbyt wiele nieudanych prób z błędnym tokenem CSRF podczas dodawania dodatkowych produktów do Koszyka.', 'invalid_token');

//     http_response_code(429);

//     echo json_encode(['status' => 'error', 'message' => 'Zbyt wiele nieudanych prób. Spróbuj ponownie później.']);
//     exit;
// }

// Blokada timera
if (
    !isset($_SESSION['csrf_token']) ||
    !isset($_SESSION['csrf_token_created']) ||
    (time() - $_SESSION['csrf_token_created'] > $admin_config['admin']['token_age'])
) {
    unset($_SESSION['csrf_token']);
    unset($_SESSION['csrf_token_created']);
    http_response_code(419); // Authentication Timeout
    echo json_encode(['status' => 'error', 'message' => 'Token wygasł. Odśwież stronę.']);
    exit;
}
// ======================


if (!isset($_SESSION['lang'])) {
    echo json_encode(['status' => 'error', 'message' => 'Nie wybrano języka.']);
    logError('Nie wykryto języka podczas dodawania dodatkowych produktów do Koszyka', 'invalid_lang');
    exit;
}

$lang = $_SESSION['lang'];

// Pobierz dane produktu z żądania POST
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['key']) || !isset($data['image']) || !isset($data['name']) || !isset($data['price']) || !isset($data['shipping'])) {
    echo json_encode(['status' => 'error', 'message' => 'Niepoprawne dane wejściowe.']);
    exit;
}

$itemKey        = $data['key'];
$itemImage      = $data['image'];
$itemName       = $data['name'];
$itemPrice      = $data['price'];
$itemShipping   = $data['shipping'];

// Załaduj dane produktów z pliku językowego
$productsFile = '../lang/' . $lang . '.php';
if (!file_exists($productsFile)) {
    echo json_encode(['status' => 'error', 'message' => 'Plik językowy nie istnieje.']);
    logError('Plik językowy do porównania danych nie istnieje podczas dodawania dodatkowych produktów do Koszyka', '404');
    exit;
}

$products = include($productsFile);

// Sprawdź, czy dane produktu są poprawne
if (isset($products['products'][$itemKey])) {
    $verifiedItem = $products['products'][$itemKey];

    if ($verifiedItem['name'] === $itemName && 
        $verifiedItem['price'] === $itemPrice && 
        $verifiedItem['shipping']['price'] === $itemShipping) {
        
        // Sprawdź, czy obrazek pasuje do produktu lub któregoś z kolorów
        if ($verifiedItem['image'] === $itemImage) {
            // Obrazek pasuje do produktu
            $verifiedItem['key'] = $itemKey;
            echo json_encode(['status' => 'success', 'item' => $verifiedItem]);
        } elseif (isset($verifiedItem['colors']) && !empty($verifiedItem['colors']['values'])) {
            // Sprawdź, czy obrazek pasuje do któregoś z kolorów
            $colorsImages = array_column($verifiedItem['colors']['values'], 'image');
            if (in_array($itemImage, $colorsImages)) {
                // Obrazek pasuje do któregoś z kolorów
                $verifiedItem['image'] = $itemImage; // Zmień obrazek w $verifiedItem
                $verifiedItem['key'] = $itemKey;
                echo json_encode(['status' => 'success', 'item' => $verifiedItem]);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Obrazek nie pasuje do produktu.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Obrazek nie pasuje do produktu.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Niepoprawne dane produktu.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Produkt nie istnieje.']);
}

?>
