// Zabezpiczenie inputów => CrossSiteInjection
function encodeHTML(str) {
    return str.replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
}


// Pokaż Errors
function showError(message) {
    // Wyszukaj element <footer>
    let footer = document.querySelector('footer');
    
    // Sprawdzenie, czy sekcja <footer> istnieje
    if (!footer) {
        return;
    }

    // Tworzenie dynamicznego div dla błędu
    let errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.textContent = message;

    // Dodanie błędu przed <footer>
    footer.parentNode.insertBefore(errorDiv, footer);

    // Wyświetlenie błędu (animacja fade-in)
    setTimeout(() => {
        errorDiv.style.opacity = '1';
    }, 100);

    // Ukrycie błędu po 2 sekundach (animacja fade-out) i usunięcie z DOM
    setTimeout(() => {
        errorDiv.style.opacity = '0';
        setTimeout(() => {
            errorDiv.remove(); // Usunięcie błędu z DOM po animacji
        }, 500);
    }, 4000);
}


// =======================================
// ==== Generator BROKATU ================
// =======================================
function getRandomGlitterColor() {
    const colors = ["#FFFFFF", "#FFFF99", "#FFD700", "#FFFFFF", "#FFED00", "#FFFF00", "#FFFFFF"]; // Biały, jasnożółty, złoty, pomarańczowy
    return colors[Math.floor(Math.random() * colors.length)];
}

// Brokat
function createGlitter(targetElement, numSparkles, blink = 1) {
    const fragment = document.createDocumentFragment();

    for (let i = 0; i < numSparkles; i++) {
        const x = Math.random() * 300;
        const y = Math.random() * 300;
        const fillColor = getRandomGlitterColor();
        const opacity = Math.random() * 0.25 + 0.25;

        const shapeType = Math.random() < 0.33 ? 'star' : 'ellipse';

        if (shapeType === 'star') {
            const star = document.createElementNS("http://www.w3.org/2000/svg", "polygon");
            star.setAttribute("points", "2,0 4,4 8,4 5,7 6,11 2,9 0,11 1,7 -2,4 2,4");
            star.setAttribute("fill", fillColor);
            star.setAttribute("opacity", opacity);

            const scale = Math.random() * 0.015 + 0.01;
            star.setAttribute("transform", `translate(${x},${y}) scale(${scale})`);

            if (blink && Math.random() < 0.1) {
                star.classList.add("sparkle");
            }
            fragment.appendChild(star);
        } else {
            const ellipse = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
            ellipse.setAttribute("cx", x);
            ellipse.setAttribute("cy", y);
            ellipse.setAttribute("rx", Math.random() * 0.15 + 0.025);
            ellipse.setAttribute("ry", Math.random() * 0.25 + 0.03);
            ellipse.setAttribute("fill", fillColor);
            ellipse.setAttribute("opacity", opacity);

            if (blink && Math.random() < 0.1) {
                ellipse.classList.add("sparkle");
            }

            fragment.appendChild(ellipse);
        }
    }

    targetElement.appendChild(fragment);
}

// Usuń brokat
function removeGlitter(targetElement) {
    while (targetElement.firstChild) {
        targetElement.removeChild(targetElement.firstChild);
    }
}


// =======================================
// ==== Generator PDF/JPG ================
// =======================================

// Pobranie zawartości SVG z DIV
function getSVGContent(div_ID, element = 'svg') {
    const svgElement = document.querySelector(`#${div_ID} ${element}`);  // Poprawny selektor
    const svgContent = svgElement ? svgElement.outerHTML : null;  // Sprawdzamy, czy znaleziono element
    return svgContent;
}

function generateFile(type) {
    // Pobranie tokena z meta
    const token = document.querySelector('meta[name="token"]').getAttribute('content');

    // Pobranie zawartości SVG z #paka
    const svgData = getSVGContent('paka'); 

    // =========================
    // Zmienna przechowująca wybrane czcionki dla <text> SVG
    let fonts = {};

    // Pobieramy wszystkie elementy <text> z id zaczynającym się od 'previewText_'
    let textElements = document.querySelectorAll('text[id^="previewText_"]');

    textElements.forEach(function(element) {
        // Pobieramy id elementów, np. 'previewText_grawer'
        let textId = element.id;
        
        // Pobieramy czcionkę przypisaną do elementu (z atrybutu font-family)
        let font = element.getAttribute('font-family');  // Pobierz font-family bezpośrednio z elementu
        
        // Przypisujemy czcionkę do obiektu fonts
        fonts[textId] = font;
        
    });    
    // console.log(fonts);
    // =========================

    if (!svgData) {
        showError('Błąd: Nie znaleziono elementu SVG!');
        return;
    }

        // Wysłanie danych do PHP
        fetch('include/generator.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
                token: token,
                svg: svgData,
                fonts: fonts,
                generate: type
            })
        })
        .then(response => response.json()) // Pobieramy odpowiedź JSON
        .then(jsonData => {
            if (jsonData.status === 'success') {
                // window.location.href = jsonData.file_url; // Otwórz w oknie
                const downloadLink = document.createElement('a');
                downloadLink.href = jsonData.file_url;
                downloadLink.download = jsonData.file_url.split('/').pop(); // Pobiera nazwę pliku z URL
                document.body.appendChild(downloadLink);
                downloadLink.click();
                document.body.removeChild(downloadLink);
            } else {
                // console.error("Błąd generowania:", jsonData.message);
                showError(jsonData.message);
            }
        })
        .catch(error => {
            console.error("Błąd pobierania pliku:", error);
            showError("Błąd pobierania pliku.")
        });
    
}
