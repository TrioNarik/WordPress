document.addEventListener("DOMContentLoaded", function () {
    // === Zmienna przechowująca wszystkie elementy canvas z czcionkami
    const fontFamilyLists = document.querySelectorAll('ul.scrollable-list[id^="fontFamily_"]');

    fontFamilyLists.forEach(list => {
        const fontButtons = list.querySelectorAll('li canvas');

        fontButtons.forEach(button => {
            button.addEventListener("click", function () {
                // Pobranie wybranego fontu
                const selectedFontFamily = this.getAttribute("data-font-family");

                // Przypisanie do odpowiedniego panelu
                const section = this.closest('.accordion-item'); 
                if (!section) return;

                const inputField = section.querySelector('.form-control[id^="text_"]');
                if (!inputField) return;

                // Zmiana czcionki w tekście w danym panelu
                const targetId = inputField.id.replace("text_", "previewText_");
                const svgText = document.getElementById(targetId);

                if (svgText) {
                    svgText.setAttribute("font-family", selectedFontFamily); // Zmiana kroju czcionki w SVG
                }

                // Przypisanie klasy aktywnej do klikniętego fontu
                fontButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });

    // Funkcja do aktualizacji canvasa
    function updateCanvas(canvasEl, font, text, name, rating, badge, colorText = false, backgroundColor = false) {
        const canvas = canvasEl; 
        const container = canvas.parentNode;
        const ctx = canvas.getContext("2d");

        // Ustaw szerokość i wysokość canvasu na 100% szerokości kontenera
        canvas.width = container.clientWidth;
        canvas.height = 45;

        const width = canvas.width;
        const height = canvas.height;

        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = backgroundColor ? backgroundColor : "#F0F0F0";
        ctx.fillRect(0, 0, width, height);

        // Rysowanie kółek rankingowych
        for (let i = 0; i < 5; i++) {
            ctx.beginPath();
            ctx.arc(width - (6 * (i + 1)), 10, 2, 0, 2 * Math.PI);
            ctx.strokeStyle = "#000000"; // Kolor obrysu
            ctx.stroke();
        }

        // Wypełnianie kółek na podstawie oceny
        for (let i = 0; i < rating; i++) {
            ctx.beginPath();
            ctx.arc(width - (6 * (i + 1)), 10, 2, 0, 2 * Math.PI);
            ctx.fillStyle = "#000000"; // Kolor wypełnienia
            ctx.fill();
        }

        // Rysowanie nazwy
        ctx.font = "10px Montserrat, sans-serif";
        ctx.fillStyle = "#000000";
        ctx.textAlign = "left";
        ctx.fillText(name, 5, 10);

        // Rysowanie odznaki
        ctx.font = "9px Montserrat, sans-serif";
        ctx.fillStyle = "#000000";
        ctx.fontVariantCaps = "small-caps";
        ctx.letterSpacing = "5px";
        ctx.textAlign = "left";
        ctx.fillText(badge, 5, height / 2);

        ctx.font = font;
        ctx.fillStyle = colorText ? colorText : "#000000";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const displayText = text.trim() ? text : `${name}`;
        ctx.fillText(displayText, width / 2, height / 2);
    }

    // Funkcja do zaktualizowania wszystkich canvasów w danym panelu
    function updateAllCanvases() {
        const panels = document.querySelectorAll('.accordion-item.show'); // Wyszukaj aktywne panele

        panels.forEach(panel => {
            const inputField = panel.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const inputText = encodeHTML(inputField.value); // Pobranie tekstu z inputa
            const textColor = panel.querySelector('.color-txt.selected')?.getAttribute('data-color') || '#000000'; // Pobranie koloru tekstu

            panel.querySelectorAll('canvas').forEach(canvasEl => {
                const font = canvasEl.getAttribute('data-font');
                const name = canvasEl.getAttribute('data-name');
                const family = canvasEl.getAttribute('data-family');
                const rating = parseInt(canvasEl.getAttribute('data-rating'), 10); // Rating jest liczbą
                const badge = canvasEl.getAttribute('data-badge');
                updateCanvas(canvasEl, font, inputText, name, rating, badge, textColor);

                // Dodaj obsługę zdarzenia click na canvas
                canvasEl.addEventListener('click', () => {
                    panel.querySelectorAll('canvas').forEach(c => c.classList.remove('selected')); // Usuń klasę 'selected' z innych
                    canvasEl.classList.add('selected'); // Dodaj do klikniętego canvasu

                    const previewText = panel.querySelector(`#${inputField.id.replace("text_", "previewText_")}`);
                    if (previewText) {
                        previewText.setAttribute("font-family", family); // Zaktualizuj czcionkę w SVG
                    }
                });

                // Ustawienie koloru tekstu w SVG
                const previewText = panel.querySelector(`#${inputField.id.replace("text_", "previewText_")}`);
                if (previewText) {
                    previewText.setAttribute("fill", textColor);
                }
            });
        });
    }

    // Obsługa zmiany tekstu w inputach
    document.querySelectorAll('.form-control[id^="text_"]').forEach(inputField => {
        inputField.addEventListener("input", updateAllCanvases);
    });

    // Obsługa kliknięć na opcje koloru
    document.querySelectorAll('.color-txt').forEach(colorOption => {
        colorOption.addEventListener('click', event => {
            event.preventDefault();
            const panel = colorOption.closest('.accordion-item'); // Zmienione na akordeon
            if (!panel) return;

            panel.querySelectorAll('.color-txt').forEach(c => c.classList.remove('selected')); // Usuń zaznaczenie z innych opcji
            colorOption.classList.add('selected'); // Zaznacz kliknięty kolor
            updateAllCanvases();
        });
    });

    // Funkcja przełączania pomiędzy blokami akordeonu
    const navTabLinks = document.querySelectorAll('.nav-tab');
    navTabLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const sectionId = this.getAttribute('data-target');

            // Zmieniamy aktywność paneli
            document.querySelectorAll('.accordion-item').forEach(section => {
                section.classList.remove('show'); // Ukrywamy inne panele
            });
            navTabLinks.forEach(link => {
                link.classList.remove('active');
            });

            // Zmieniamy aktywność panelu i linku
            document.getElementById(sectionId).classList.add('show');
            this.classList.add('active');

            // Aktualizacja canvasa po przełączeniu panelu
            updateAllCanvases();
        });
    });

    // Wywołanie funkcji przy pierwszym załadowaniu
    updateAllCanvases(); 
});
