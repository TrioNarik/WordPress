<?php
// errors, warning, info => LOGS
function logError($message, $logFile = 'errors') {
    $logDir = __DIR__ . '/../logs';
    $logFile = $logDir .'/'. $logFile .'.log';
    $htaccessFile = $logDir . '/.htaccess'; // Ścieżka do pliku .htaccess

        // Jeśli folder nie istnieje, utwórz go
        if (!is_dir($logDir)) {
            mkdir($logDir, 0777, true);
    
            // Jeśli plik .htaccess nie istnieje, utwórz go
            if (!file_exists($htaccessFile)) {
                $htaccessContent = <<<HTACCESS
                    # Apache 2.2
                    <Files "*.log">
                        Order deny,allow
                        Deny from all
                    </Files>
                    
                    # Apache 2.4
                    <Files "*.log">
                        Require all denied
                    </Files>
                    HTACCESS;
                file_put_contents($htaccessFile, $htaccessContent);
            }
        }

    // Format loga: [Data] [IP] Treść błędu
    $logMessage = "[" . date("Y-m-d H:i:s") . "] [" . $_SESSION['ip'] . "] [" . $_SESSION['country'] . "] [" . $_SESSION['city'] . "] " . $message . PHP_EOL;
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

// Załadowany plik
function safeInclude($filePath) {
    if (file_exists($filePath)) {
        return include $filePath;
    } else {
        logError("Plik nie istnieje: $filePath", '404');
        return null;
    }
}


// =========================================
// Funkcja do wczytywania i dekodowania JSON
// =========================================
function loadJsonFile($file, $default = [], $path = 'json/') {
    $full_path_json = $path . $file;
    if (file_exists($full_path_json)) {
        $json_data = file_get_contents($full_path_json);
        return json_decode($json_data, true);
    } else {
        return $default;
    }
}

// ======================================
// Funkcja do aktualizacji plików CSS/JPG
// ======================================
function version($file) {
    if (file_exists($file)) {
        return $file . '?v=4.' . filemtime($file);
    } else {
        logError("Plik nie istnieje: $file", '404');
        return null;
    }
}

// ==============================
// Funkcja do pobrania SVG
// ==============================
function svg_code($svg_file, $path = 'svg/') {
    $full_path = $path . $svg_file;
    if (file_exists($full_path)) {
        echo file_get_contents($full_path);
    }
  }

// =============================
// Funkcja do formatowania ceny
// =============================
function formatPrice($price) {
    return number_format($price, 2, ',', ' '); // Formatowanie ceny z dwoma miejscami po przecinku i spacją jako separator tysięcy
}
function formatPriceWithSup($price) {
    $parts = explode('.', number_format($price, 2, '.', ''));
    if (count($parts) === 2) {
        return $parts[0] . ',<sup>' . $parts[1] . '</sup>';
    }
    return $parts[0] . ',<sup>00</sup>';
}

?>