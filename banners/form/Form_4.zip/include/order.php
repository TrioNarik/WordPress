<?php
// Załaduj konfigurację mailingów i klucza szyfrującego
$email_config = require '../config_mailer.php';
$admin_config = require '../config_admin.php';

// Logi
$logFile = '../errors.log';
// Plik zamówień
$file = '../orders.txt';

// Załaduj PHPMailer
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

// Funkcja szyfrowania
function encryptData($data, $key) {
    $iv = random_bytes(openssl_cipher_iv_length('AES-128-CBC')); // Generowanie losowego IV
    $encrypted = openssl_encrypt($data, 'AES-128-CBC', $key, 0, $iv); // Szyfrowanie danych
    return base64_encode($iv . $encrypted); // Dodanie IV do zaszyfrowanych danych
}


// Definiowanie mapy walut (symbol, kod waluty)
$currencyMap = [
    'PL' => ['symbol' => 'PLN', 'rate' => 1],       // Polska
    'US' => ['symbol' => 'USD', 'rate' => 0.24],    // USA
    'EU' => ['symbol' => 'EUR', 'rate' => 0.22],    // Euro
];

// Domyślna waluta
$defaultCurrency = 'PL';
$currency = $currencyMap[$defaultCurrency];


// Obsługa formularza
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name               = htmlspecialchars($_POST['name']);
    $company            = htmlspecialchars($_POST['company']);
    $email              = htmlspecialchars($_POST['email']);
    $phone              = htmlspecialchars($_POST['phone']);
    $street             = htmlspecialchars($_POST['street']);
    $postCode           = htmlspecialchars($_POST['post']);
    $city               = htmlspecialchars($_POST['city']);
    $country            = htmlspecialchars($_POST['country']);

    $differentShippingAddress = isset($_POST['differentShippingAddress']) ? 1 : 0;
    $shippingStreet   = $differentShippingAddress ? htmlspecialchars($_POST['shippingStreet'] ?? '') : '';
    $shippingPostCode = $differentShippingAddress ? htmlspecialchars($_POST['shippingPost'] ?? '') : '';
    $shippingCity     = $differentShippingAddress ? htmlspecialchars($_POST['shippingCity'] ?? '') : '';
    $shippingCountry  = $differentShippingAddress ? htmlspecialchars($_POST['shippingCountry'] ?? '') : '';


    $products           = $_POST['product'] ?? []; // Nazwy produktów
    $productPrices      = $_POST['price'] ?? []; // Ceny produktów

    $customization      = htmlspecialchars($_POST['customization']) ; // Customizacja produktu/uwagi

    $prepayment         = isset($_POST['prepayment']) ? 1 : 0;
    $prepaymentMode     = $prepayment ? htmlspecialchars($_POST['prepaymentMode'] ?? '') : '';
    $prepaymentCount    = $prepayment ? htmlspecialchars($_POST['prepaymentCount'] ?? '') : '---';


    // Przygotowanie danych zamówienia
    $orderData = [
        'name' => $name,
        'company' => $company,
        'email' => $email,
        'phone' => $phone,
        'street' => $street,
        'postCode' => $postCode,
        'city' => $city,
        'country' => $country,

        'shippingStreet' => $shippingStreet, // Adres wysyłki
        'shippingPostCode' => $shippingPostCode,
        'shippingCity' => $shippingCity,
        'shippingCountry' => $shippingCountry,

        'products' => [], // Przechowujemy produkty jako asocjacyjną tablicę

        'customization' => $customization, // Customizacja produktu/uwagi

        'prepaymentMode' => $prepaymentMode, // Sposób przedpłaty
        'prepaymentCount' => $prepaymentCount, // Kwota przedpłaty

        'total' => array_sum($productPrices),

        'date' => date('Y-m-d'), // Timer zamówienia ~ 14 dni
        'timestamp' => date('Y-m-d H:i:s') // Czas zamówienia ~ do statystyk
    ];

    // Dodajemy produkty i ich ceny do tablicy zamówienia
    foreach ($products as $product) {
        if (isset($productPrices[$product])) {
            $orderData['products'][$product] = $productPrices[$product];
        }
    }

    // ===============================
    // Określenie STATUSU przedpłaty i terminu płatności
    $prepaymentStatus       = '';
    $prepaymentClass        = '';
    $paymentDeadline        = '';
    $paymentDeadlineText    = '';

    if ($prepayment) { // Sprawdzamy, czy przedpłata była wybrana
        if ($prepaymentMode === 'Gotówka/Płatność kartą') {
            
            $prepaymentStatus = 'otrzymane'; // Status dla gotówki
            $prepaymentClass = 'done';

        } elseif ($prepaymentMode === 'Przelew') {
            
            $deadlineDays = $admin_config['admin']['prepayment_period'] ?? 14; // Pobieranie terminu z konfiguracji

            $prepaymentStatus = 'oczekuje na zaksięgowanie'; // Status dla przelewu
            $prepaymentClass = 'wait';
            $paymentDeadline = date('d-m-Y', strtotime("+$deadlineDays days")); // Wyliczenie daty terminu płatności
            $paymentDeadlineText = 'Termin płatności: '; // Info

        }
    } else {

        $prepaymentStatus = '---'; // Bez przedpłaty
        $prepaymentClass = '';        
    }

    // Dodanie statusu do danych zamówienia w szblonie mailingu
    $orderData['prepaymentStatus']      = $prepaymentStatus;
    $orderData['prepaymentClass']       = $prepaymentClass;
    $orderData['paymentDeadline']       = $paymentDeadline;
    $orderData['paymentDeadlineText']   = $paymentDeadlineText;

    // $template = str_replace('{{_prepaymentStatus_}}', htmlspecialchars($prepaymentStatus), $template);
    // $template = str_replace('{{_paymentDeadline_}}', htmlspecialchars($paymentDeadline), $template);

    // ===============================

    
    // Wczytaj SZABLON
    $template = file_get_contents('../mail/order.html');

    // Zamiana STAŁYCH admina w szablonie ([[...]])
    $constants = [
        '[[path_url]]'                  => $admin_config['admin']['path_url'], // ścieżka do serwera i obrazków w szablonie.
        '[[admin_company_name]]'        => $admin_config['admin']['company_name'],
        '[[admin_company_address]]'     => $admin_config['admin']['company_address'],
        '[[admin_bank_name]]'           => $admin_config['admin']['bank_name'],
        '[[admin_bank_account]]'        => $admin_config['admin']['bank_account'],
        '[[admin_prepayment_period]]'   => $admin_config['admin']['prepayment_period'],
        '[[admin_office_phone]]'        => $admin_config['admin']['office_phone'],
        '[[admin_office_email]]'        => $admin_config['admin']['office_email']
    ];

    // Zamiana stałych w szablonie
    foreach ($constants as $key => $value) {
        $template = str_replace($key, $value, $template);
    }

    // Zamiana wartości z formularza w szablonie {{_..._}} ceną i walutą
    foreach ($orderData as $key => $value) {
        if ($key === 'products') {
            // Generowanie listy produktów z cenami
            $productHtml = '';
            foreach ($value as $product => $price) {
                // $convertedPrice = $price * $currency['rate']; // Przelicznik waluty
                $formattedPrice = number_format($price, 2) . ' ' . $currency['symbol']; // Formatowanie ceny
                $productHtml .= "<li>" . htmlspecialchars($product) . " - $formattedPrice</li>"; // Escapowanie nazwy produktu
            }
    
            // Zamiana znacznika na gotową listę produktów
            $template = str_replace('{{_products_}}', "<ul>$productHtml</ul>", $template);
        } else {
            // Zamiana innych zmiennych w szablonie
            $template = str_replace('{{_' . $key . '_}}', htmlspecialchars($value), $template);
        }
    }
    
    

    // Serializacja i szyfrowanie
    $orderJson = json_encode($orderData, JSON_PRETTY_PRINT);
    $encryptedOrder = encryptData($orderJson, $admin_config['admin']['secret_key']);

    // Zapis do pliku zamówień
    if (file_put_contents($file, $encryptedOrder . "\n", FILE_APPEND) === false) {
        error_log("Nie udało się zapisać zamówienia do pliku: $file\n", 3, $logFile);
        exit;
    }

    // Przygotowanie wiadomości e-mail
    $subjectAdmin   = "Nowe zamówienie - Hussaria Electra";
    $subjectClient  = 'Potwierdzenie zamówienia - Hussaria Electra';

    // $messageAdmin = "Zamówienie od klienta:\n\nImię i nazwisko: $name\nAdres: $address\n\nProdukty:\n";

    // foreach ($products as $product) {
    //     if (isset($productPrices[$product])) {
    //         $messageAdmin .= "$product - " . $productPrices[$product] . " PLN\n";
    //     }
    // }

    // $messageAdmin .= "\nŁączna kwota: $orderData['total'] $currency['symbol']";

    
    // Sprawdź czy opcja wysyłania maili jest włączona w konfiguracji formularza
    if  ($admin_config['admin']['active'] === 1) {
    // Wysyłanie e-maili (PHPMailer)
        $mail = new PHPMailer(true);
        try {
            // Konfiguracja SMTP
            $mail->isSMTP();
            $mail->Host = $email_config['smtp']['host'];
            $mail->SMTPAuth = true;
            $mail->Username = $email_config['smtp']['username'];
            $mail->Password = $email_config['smtp']['password'];
            $mail->SMTPSecure = $email_config['smtp']['encryption'];
            $mail->Port = $email_config['smtp']['port'];

            // Mail do admina
            $mail->setFrom($email_config['smtp']['from_email'], $email_config['smtp']['from_name']);
            $mail->addAddress($admin_config['admin']['mail']);
            $mail->Subject = $subjectAdmin;
            $mail->CharSet = 'UTF-8';
            $mail->Encoding="base64";
            $mail->isHTML(true); // Tryb HTML
            $mail->Body = $template; // Załadowany i uzupełniony szablon ~ może być inny
            $mail->send();

            // Mail do klienta
            $mail->clearAddresses();
            $mail->addAddress($email);
            $mail->Subject = $subjectClient;
            $mail->CharSet = 'UTF-8';
            $mail->Encoding="base64";
            $mail->AddEmbeddedImage('../img/he_logo_mail_white.png', 'logowhite');
            $mail->AddEmbeddedImage('../img/he_patented.png', 'patented');
            $mail->AddEmbeddedImage('../img/tt.png', 'tiktok');
            $mail->AddEmbeddedImage('../img/fb.png', 'facebook');
            $mail->AddEmbeddedImage('../img/ins.png', 'instagram');
            $mail->isHTML(true); // Tryb HTML
            $mail->Body = $template; // Załadowany i uzupełniony szablon
            $mail->send();

            echo "Zamówienie przyjęte! Wartość: " . number_format($total, 2) . " PLN";
        } catch (Exception $e) {
            // Zapisz błąd w pliku logów
            error_log(date('[Y-m-d H:i:s]') . " Błąd przy wysyłaniu e-maili: " . $e->getMessage() . "\n", 3, $logFile);
            echo "Nie udało się wysłać wiadomości e-mail. Błąd: {$mail->ErrorInfo}";
        }
    } else {
        echo "Wysyłania wiadomości przez formularz jest wyłączone !";
    }
} else {
    http_response_code(405);
    // Zapisz błąd w pliku logów
    error_log("Nieprawidłowa metoda żądania - " . $_SERVER['REQUEST_METHOD'] . "\n", 3, $logFile);
    echo "Nieprawidłowa metoda żądania.";
}
