<?php
return [
    'smtp' => [
        'host' => 's179.cyber-folks.pl',
        'username' => 'order@hussaria.pl',
        'password' => 'fAgAmbTtwAM8zh.9V3*YQmW2-',
        'port' => 587, // tls
        'encryption' => 'tls', // 'tls' || 'ssl'
        'from_email' => 'order@hussaria.pl',
        'from_name' => 'Hussaria Electra'
    ]
];
