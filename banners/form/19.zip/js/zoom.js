// document.addEventListener("DOMContentLoaded", function () {
//     const svgElement = document.getElementById('svg_paka'); // ID twojego SVG
//     const originalViewBox = svgElement?.getAttribute('viewBox') || "0 0 79.5 137.5"; 
//     const maxZoomChars = 15; 
//     let isZoomed = false; 

//     function zoomOnText(inputField) {
//         const textElement = document.getElementById(`previewText_${inputField.id.split('_')[1]}`); 
        
//         if (!svgElement || !textElement) {
//             console.warn("Element SVG lub tekstowy nie istnieje. Powiększanie niemożliwe.");
//             return;
//         }

//         const textLength = Math.min(inputField.value.length || 0, maxZoomChars);
//         const zoomFactor = 2;
//         const extraWidth = (maxZoomChars - textLength) * 2; 

//         if (textLength === 0) {
//             return;
//         }

//         const bbox = textElement.getBBox();
//         const newViewBox = `${bbox.x - 5} ${bbox.y - 5} ${(bbox.width + extraWidth) * zoomFactor} ${bbox.height * zoomFactor}`;

//         svgElement.setAttribute('viewBox', newViewBox);
//         if (!isZoomed) {
//             isZoomed = true;
//             showResetButton();
//         }
//     }

//     function resetZoom() {
//         svgElement.setAttribute('viewBox', originalViewBox);
//         isZoomed = false;
//         removeResetButton();
//     }

//     document.querySelectorAll("input[id^='text_']").forEach(input => {
//         input.addEventListener('input', () => {
//             zoomOnText(input);
//         });
//     });

//     // Dodajemy nasłuchiwanie kliknięcia na przyciski wyrównania
//     document.querySelectorAll("button[id^='buttonText_']").forEach(button => {
//         button.addEventListener('click', () => {
//             const targetId = button.id.split('_')[1]; // Pobieramy np. "toppanel"
//             const inputField = document.getElementById(`text_${targetId}`);
//             if (inputField) {
//                 zoomOnText(inputField); // Wywołujemy zoomOnText tak, jakby użytkownik edytował input
//             }
//         });
//     });

//     function showResetButton() {
//         let resetButton = document.getElementById('resetZoomIcon');
//         if (!resetButton) {
//             resetButton = document.createElement('button');
//             resetButton.setAttribute('id', 'resetZoomIcon');
//             resetButton.innerHTML = '↻';
//             resetButton.style.position = 'absolute';
//             resetButton.style.top = svgElement.getBoundingClientRect().top + window.scrollY + 'px';
//             resetButton.style.left = svgElement.getBoundingClientRect().right - 50 + 'px';
//             resetButton.style.width = '30px';
//             resetButton.style.height = '30px';
//             resetButton.style.background = 'red';
//             resetButton.style.color = 'white';
//             resetButton.style.border = 'none';
//             resetButton.style.borderRadius = '50%';
//             resetButton.style.cursor = 'pointer';
//             resetButton.style.fontSize = '18px';
//             resetButton.style.display = 'flex';
//             resetButton.style.justifyContent = 'center';
//             resetButton.style.alignItems = 'center';
//             resetButton.style.zIndex = '1000';

//             resetButton.addEventListener('click', resetZoom);
//             document.body.appendChild(resetButton);

//             window.addEventListener('resize', positionResetButton);
//         }
//     }

//     function positionResetButton() {
//         const resetButton = document.getElementById('resetZoomIcon');
//         if (resetButton) {
//             resetButton.style.top = svgElement.getBoundingClientRect().top + window.scrollY + 'px';
//             resetButton.style.left = svgElement.getBoundingClientRect().right - 30 + 'px';
//         }
//     }

//     function removeResetButton() {
//         const resetButton = document.getElementById('resetZoomIcon');
//         if (resetButton) {
//             resetButton.remove();
//             window.removeEventListener('resize', positionResetButton);
//         }
//     }
// });


document.addEventListener("DOMContentLoaded", function () {
    const svgElement = document.getElementById('svg_paka'); // ID twojego SVG
    const originalViewBox = svgElement?.getAttribute('viewBox') || "0 0 79.5 137.5"; 
    const maxZoomChars = 15; 
    let isZoomed = false; 

    // Obiekt do przechowywania stanu przeciągania
    let dragState = {
        isDragging: false,
        startX: 0,
        startY: 0,
        currentViewBox: ''
    };

    // Współczynnik tłumienia (spowolnienia) przeciągania
    const dampingFactor = 0.2; // Im mniejsza wartość, tym wolniej będzie przeciąganie

    function zoomOnText(inputField) {
        const textElement = document.getElementById(`previewText_${inputField.id.split('_')[1]}`); 
        
        if (!svgElement || !textElement) {
            console.warn("Element SVG lub tekstowy nie istnieje. Powiększanie niemożliwe.");
            return;
        }

        const textLength = Math.min(inputField.value.length || 0, maxZoomChars);
        const zoomFactor = 2;
        const extraWidth = (maxZoomChars - textLength) * 2; 

        if (textLength === 0) {
            return;
        }

        const bbox = textElement.getBBox();
        const newViewBox = `${bbox.x - 5} ${bbox.y - 5} ${(bbox.width + extraWidth) * zoomFactor} ${bbox.height * zoomFactor}`;

        svgElement.setAttribute('viewBox', newViewBox);
        if (!isZoomed) {
            isZoomed = true;
            enableDragging(); // Włączamy przeciąganie po zoomie
            showResetButton();
        }
    }

    function resetZoom() {
        svgElement.setAttribute('viewBox', originalViewBox);
        isZoomed = false;
        removeResetButton();
        disableDragging(); // Wyłączamy przeciąganie po resecie
    }

    document.querySelectorAll("input[id^='text_']").forEach(input => {
        input.addEventListener('input', () => {
            zoomOnText(input);
        });
    });

    // Dodajemy nasłuchiwanie kliknięcia na przyciski wyrównania
    document.querySelectorAll("button[id^='buttonText_']").forEach(button => {
        button.addEventListener('click', () => {
            const targetId = button.id.split('_')[1]; // Pobieramy np. "toppanel"
            const inputField = document.getElementById(`text_${targetId}`);
            if (inputField) {
                zoomOnText(inputField); // Wywołujemy zoomOnText tak, jakby użytkownik edytował input
            }
        });
    });

    function showResetButton() {
        let resetButton = document.getElementById('resetZoomIcon');
        if (!resetButton) {
            resetButton = document.createElement('button');
            resetButton.setAttribute('id', 'resetZoomIcon');
            resetButton.innerHTML = '↻';
            resetButton.style.position = 'absolute';
            resetButton.style.top = svgElement.getBoundingClientRect().top + window.scrollY + 20 + 'px';
            resetButton.style.left = svgElement.getBoundingClientRect().right - 50 + 'px';
            resetButton.style.width = '30px';
            resetButton.style.height = '30px';
            resetButton.style.background = 'red';
            resetButton.style.color = 'white';
            resetButton.style.border = 'none';
            resetButton.style.borderRadius = '50%';
            resetButton.style.cursor = 'pointer';
            resetButton.style.fontSize = '18px';
            resetButton.style.display = 'flex';
            resetButton.style.justifyContent = 'center';
            resetButton.style.alignItems = 'center';
            resetButton.style.zIndex = '1000';

            resetButton.addEventListener('click', resetZoom);
            document.body.appendChild(resetButton);

            window.addEventListener('resize', positionResetButton);
        }
    }

    function positionResetButton() {
        const resetButton = document.getElementById('resetZoomIcon');
        if (resetButton) {
            resetButton.style.top = svgElement.getBoundingClientRect().top + window.scrollY + 20 + 'px';
            resetButton.style.left = svgElement.getBoundingClientRect().right - 30 + 'px';
        }
    }

    function removeResetButton() {
        const resetButton = document.getElementById('resetZoomIcon');
        if (resetButton) {
            resetButton.remove();
            window.removeEventListener('resize', positionResetButton);
        }
    }

    // Funkcje przeciągania SVG
    function startDrag(event) {
        dragState.isDragging = true;
        dragState.startX = event.clientX;
        dragState.startY = event.clientY;
        dragState.currentViewBox = svgElement.getAttribute('viewBox');

        // Zmiana kursora na "łapkę" podczas przeciągania
        svgElement.style.cursor = 'grabbing';
    }

    function dragSVG(event) {
        if (dragState.isDragging) {
            const deltaX = (event.clientX - dragState.startX) * dampingFactor; // Zastosowanie tłumienia
            const deltaY = (event.clientY - dragState.startY) * dampingFactor; // Zastosowanie tłumienia

            if (Math.abs(deltaX) > 1 || Math.abs(deltaY) > 1) {
                const newViewBox = calculateNewViewBox(deltaX, deltaY);
                svgElement.setAttribute('viewBox', newViewBox);
                dragState.currentViewBox = newViewBox;

                // Aktualizujemy punkt początkowy dla kolejnego ruchu myszy
                dragState.startX = event.clientX;
                dragState.startY = event.clientY;
            }
        }
    }

    function calculateNewViewBox(deltaX, deltaY) {
        const viewBoxValues = dragState.currentViewBox.split(' ');
        const newX = parseFloat(viewBoxValues[0]) - deltaX;
        const newY = parseFloat(viewBoxValues[1]) - deltaY;

        return `${newX} ${newY} ${viewBoxValues[2]} ${viewBoxValues[3]}`;
    }

    function endDrag() {
        dragState.isDragging = false;
        
        // Przywracamy kursor do domyślnego po zakończeniu przeciągania
        svgElement.style.cursor = 'grab';
    }

    // Funkcja do wyłączenia przeciągania
    function disableDragging() {
        svgElement.removeEventListener('mousedown', startDrag);
        document.removeEventListener('mousemove', dragSVG);
        document.removeEventListener('mouseup', endDrag);
        svgElement.style.cursor = 'default'; // Przywracamy domyślny kursor
    }

    // Funkcja do włączenia przeciągania (po zoomie)
    function enableDragging() {
        svgElement.addEventListener('mousedown', startDrag);
        document.addEventListener('mousemove', dragSVG);
        document.addEventListener('mouseup', endDrag);
        svgElement.style.cursor = 'grab'; // Kursor "grab" po włączeniu przeciągania
    }

    // Nasłuchiwanie zdarzeń
    // Usuwamy nasłuchiwanie zdarzeń przeciągania na początku, bo nie chcemy, aby było aktywne od razu
    // svgElement.addEventListener('mousedown', startDrag);
    // document.addEventListener('mousemove', dragSVG);
    // document.addEventListener('mouseup', endDrag);
});


