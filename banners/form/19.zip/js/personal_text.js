// Aktywacja TABS Text personalizacji:
document.addEventListener("DOMContentLoaded", function () {

    const navTabLink = document.querySelectorAll('.nav-tab');
    const sections = document.querySelectorAll('.positions-tabs');

    navTabLink.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const sectionId = this.getAttribute('data-target');

            // Usuń klasę active z wszystkich sekcji i linków
            sections.forEach(section => {
                section.classList.remove('active');
            });
            navTabLink.forEach(link => {
                link.classList.remove('active');
            });

            // Dodaj klasę active do klikniętej sekcji i linku
            document.getElementById(sectionId).classList.add('active');
            this.classList.add('active');
            
        });
    });


    // === Dodaj Brokat
    // const brokatCheckbox = document.getElementById('glitter');
    // const glitterLayer = document.getElementById('glitter-layer');
    // brokatCheckbox.addEventListener('change', function () {
    //     if (brokatCheckbox.checked) {
    //         createGlitter(glitterLayer, 25000, 1); // Dodaj n elementów brokatu (1/3 gwiazdki), migotanie = on
    //     } else {
    //         removeGlitter(glitterLayer); // Usuń brokat
    //     }
    // });


    // === Pola tekstowe (inputy)
    const textInputs = document.querySelectorAll('.form-control[id^="text_"]');

    textInputs.forEach(input => {
        input.addEventListener("input", function () {
            const targetId = this.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.textContent = encodeHTML(this.value.trim()); // Zabezpieczamy przed XSS
            }
        });

    });
    

    // =======================
    // === Pokaż/Ukryj Grawer Zonę i Flagę => TEXT TopPanel [left] => przesunięcie X
    // =======================
    // Pobranie elementów
    const inputFieldGrawer = document.getElementById('text_grawerTopPanel');
    const grawerZone = document.getElementById('preview_grawerTopPanel');
    const flagZoneGrawer = document.getElementById('preview_flagTopPanel_grawer');
    const flagZoneWithoutGrawer = document.getElementById('preview_flagTopPanel_left');
    const flagCheckbox = document.getElementById('flag'); // checkbox form

    const textTopPanel = document.getElementById('previewText_toppanel');
    const buttonTextTopPanel = document.getElementById('buttonText_toppanel_left');

    // Pobranie wartości początkowych (jeśli elementy istnieją)
    const initialTextTopPanelX = textTopPanel ? parseFloat(textTopPanel.getAttribute('x')) || 0 : 0;
    const initialButtonX = buttonTextTopPanel ? parseFloat(buttonTextTopPanel.getAttribute('data-x')) || 0 : 0;

    // Funkcja aktualizująca widoczność elementów i pozycję tekstu + buttona
    function updateVisibility() {
        if (!textTopPanel) return; // Jeśli `textTopPanel` nie istnieje, zakończ

        const flagChecked = flagCheckbox?.checked || false;
        let shift = flagChecked ? 4.5 : 0; // Domyślne przesunięcie o width Flagi, jeśli flaga jest zaznaczona
        const currentAnchor = textTopPanel.getAttribute('text-anchor') || 'start'; // 🔥 Pobieramy AKTUALNY `text-anchor` (przesuwamy tylko Lewy <text> z anchor=start)

        // Jeśli tabliczka z grawerem NIE istnieje – ustaw domyślne zachowanie
        if (!inputFieldGrawer) {
            if (currentAnchor === 'start') {
                textTopPanel.setAttribute('x', initialTextTopPanelX + shift);
            }

            if (buttonTextTopPanel) {
                buttonTextTopPanel.setAttribute('data-x', initialButtonX + shift);
            }

            if (flagZoneGrawer) flagZoneGrawer.style.visibility = 'hidden';
            if (flagZoneWithoutGrawer) flagZoneWithoutGrawer.style.visibility = flagChecked ? 'visible' : 'hidden';
            return;
        }

        // Jeśli tabliczka z grawerem istnieje – wykonaj aktualizację zgodnie z jej stanem
        const hasText = inputFieldGrawer.value.trim() !== '';

        // Pokaż lub ukryj grawer
        if (grawerZone) grawerZone.style.visibility = hasText ? 'visible' : 'hidden';

        // Dodatkowe przesunięcie, jeśli grawer jest włączony
        if (hasText) shift += 20;

        // 🔥 Przesunięcie x TYLKO jeśli `text-anchor="start"`
        if (currentAnchor === 'start') {
            textTopPanel.setAttribute('x', initialTextTopPanelX + shift);
        }

        // Zmień `data-x` przycisku względem wartości początkowej
        if (buttonTextTopPanel) {
            buttonTextTopPanel.setAttribute('data-x', initialButtonX + shift);
        }

        // Pokaż odpowiednią flagę (tylko jeśli istnieją)
        if (flagZoneGrawer) flagZoneGrawer.style.visibility = hasText && flagChecked ? 'visible' : 'hidden';
        if (flagZoneWithoutGrawer) flagZoneWithoutGrawer.style.visibility = !hasText && flagChecked ? 'visible' : 'hidden';
    }

    // Nasłuchiwanie zmian, ale tylko jeśli elementy istnieją
    if (inputFieldGrawer) inputFieldGrawer.addEventListener('input', updateVisibility);
    if (flagCheckbox) flagCheckbox.addEventListener('change', updateVisibility);

    



    // =======================
    // === Kolor tekstu w SVG
    // =======================
    const colorPickers = document.querySelectorAll('.colors .color-txt');

    colorPickers.forEach(colorPicker => {
        colorPicker.addEventListener("click", function (event) {
            event.preventDefault();

            const selectedColor = this.getAttribute("data-color");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            // Znajdź odpowiadający input tekstowy w tej sekcji
            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            // Znajdź odpowiadający element <text> w SVG
            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.setAttribute("fill", selectedColor); // Ustawienie koloru tekstu w SVG
            }

            // Zaktualizuj kolor w przycisku podglądu
            const colorPreview = section.querySelector(`#selectedColorText_${inputField.id.replace("text_", "")}`);
            if (colorPreview) {
                colorPreview.style.backgroundColor = selectedColor;
            }
        });
    });


    // === Wyrównanie tekstu w SVG
    const alignButtons = document.querySelectorAll('.tools[id^="textAlignt_"] button');

    alignButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedX = this.getAttribute("data-x");
            const selectedY = this.getAttribute("data-y");
            const selectedAnchor = this.getAttribute("data-anchor");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.setAttribute("x", selectedX);
                svgText.setAttribute("y", selectedY);
                svgText.setAttribute("text-anchor", selectedAnchor);
            }

            // 🔥 Zarządzanie klasą active dla przycisków wyrównania
            const alignGroup = section.querySelectorAll('.tools[id^="textAlignt_"] button');
            alignGroup.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // === Rozmiar tekstu w SVG
    const sizeButtons = document.querySelectorAll('.tools[id^="textSize_"] button');

    sizeButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedSize = this.getAttribute("data-size");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.setAttribute("font-size", selectedSize); // Zmiana rozmiaru tekstu w SVG
            }

            // 🔥 Zarządzanie klasą active dla przycisków
            const sizeGroup = section.querySelectorAll('.tools[id^="textSize_"] button');
            sizeGroup.forEach(btn => btn.classList.remove('active')); // Usunięcie active z innych
            this.classList.add('active'); // Dodanie active do klikniętego
        });
    });


    // === Formatowanie tekstu w SVG
    const styleButtons = document.querySelectorAll('.tools[id^="textStyle_"] button');

    styleButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedStyle = this.getAttribute("data-style");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                // Sprawdzenie, czy przycisk jest aktywny (czy ma klasę 'active')
                const isActive = this.classList.contains('active');

                // Dodanie lub usunięcie odpowiedniego stylu
                if (selectedStyle === "bold") {
                    if (isActive) {
                        svgText.removeAttribute("font-weight");
                    } else {
                        svgText.setAttribute("font-weight", "bold");
                    }
                } else if (selectedStyle === "italic") {
                    if (isActive) {
                        svgText.removeAttribute("font-style");
                    } else {
                        svgText.setAttribute("font-style", "italic");
                    }
                } else if (selectedStyle === "underline") {
                    if (isActive) {
                        svgText.removeAttribute("text-decoration");
                    } else {
                        svgText.setAttribute("text-decoration", "underline");
                    }
                }
            }

            // Zarządzanie klasą 'active' dla przycisków
            this.classList.toggle('active');
        });
    });


    // === Krój czcionki w SVG
    const fontFamilyLists = document.querySelectorAll('ul.scrollable-list[id^="fontFamily_"]');

    fontFamilyLists.forEach(list => {
        const fontButtons = list.querySelectorAll('li canvas');

        fontButtons.forEach(button => {
            button.addEventListener("click", function () {
                const selectedFontFamily = this.getAttribute("data-family");
                const section = this.closest('.positions-tabs');
                if (!section) return;

                const inputField = section.querySelector('.form-control[id^="text_"]');
                if (!inputField) return;

                const targetId = inputField.id.replace("text_", "previewText_");
                const svgText = document.getElementById(targetId);

                if (svgText) {
                    svgText.setAttribute("font-family", selectedFontFamily); // Zmiana kroju czcionki w SVG
                }

                // Zarządzanie klasą active dla przycisków
                fontButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });
    

});

