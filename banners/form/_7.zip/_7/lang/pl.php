<?php
return [
    'settings' => [
        'theme' => 'Zmień motyw',
        'currency' => 'zł',
        'discount' => [
            'name' => 'Rabat',
            'value' => 0,
        ],
        'fees' => [
            'name' => 'Opłaty' ,
            'value' => 0,
        ]
    ],

    'title' => 'Konfigurator ⚡ Elektryczna Paka 🔋 Hussaria Electra 🚀',
    'header' => 'Formularz zamówienia',
    'helper' => 'Skonfiguruj swoją pakę i wyślij formularz, a my skontaktujemy się z Tobą i poprowadzimy Cię przez dalszy etap zamówienia 😊',
    'form' => [
        'colors' => [
            'title' => 'Kolor paki',
            'fields' => [
                'label' => 'Kolor paki',
                'help' => 'Wybierz kolor',
                'info' => 'Dostępna paleta kolorów do zmiany koloru paki',
            ],
        ],
        'glitter' => [
            'title' => 'Brokat',
            'fields' => [
                'label' => 'Brokat',
                'help' => '',
                'info' => '',
            ],
            'price' => [
                'show' => 0,
                'value' => 0,
                'promo' => '',
            ]
        ],
        'marker' => [
            'title' => 'Personalizacja',
            'fields' => [
                'label' => 'Personalizacja',
                'help' => 'Wybierz opcje',
                'info' => 'Dostępne opcje personalizacji paki',
                'holder' => 'Tekst'
            ],
            'options' => [
                'grawer' => [
                    'title' =>'Grawerowanie',
                    'price' => [
                        'show' => 0,
                        'value' => 0,
                        'promo' => '',
                    ],
                ],
                'texts' => [
                    'title' =>'Tekst',
                    'price' => [
                        'show' => 0,
                        'value' => 45,
                        'promo' => 15,
                    ],
                ],
            ],
            'tools' => [
                'font-color' => 'Kolor',
                'font-align' => 'Wyrównanie',
                'font-style' => 'Formatowanie',
                'font-size' => 'Rozmiar',
                'font-family' => 'Czcionka',
                
            ],
            'flag' => [
                'title' => 'Flaga',
                'fields' => [
                    'label' => 'Flaga',
                    'holder' => 'Kraj',
                    'info' => '',
                    'warning' => 'Wpisz nazwę kraju (lub kod: USA, PL, FR, UK, itd.), aby dodać flagę'
                ],
                'price' => [
                        'show' => 0,
                        'value' => 300,
                        'promo' => 5
                    ],
            ]
        ],
        'info' => [
            'send-pdf' => 'Dodatkowe pliki graficzne w formacie PDF wyślij na adres',
            'send-mail' => 'biuro@hussaria.pl'
        ],
        'buttons' => [
            'save' => 'Zapisz konfigurację',
            'cart' => 'Koszyk',
            'add' => 'Dodaj do koszyka',
            'view' => 'Zobacz koszyk',
            'submit' => 'Zamawiam',
            'delete' => 'Usuń'
        ],
        'cart' => [
            'product-image' => 'Zdjęcie',
            'product-name' => 'Nazwa',
            'product-quantity' => 'Ilość',
            'product-total' => 'Suma',
        ],
        'errors' => [
            'add-product' => 'Błąd: Nie można dodać produktu do koszyka!',
            'del-product' => 'Błąd: Nie można usunąć produktu z koszyka!',
        ],
        
        // ========================

        'person' => [
            'title' => 'Dane personalne',
            'fields' => [
                'first_name' => 'Imię / Nazwa firmy',
                'last_name' => 'Nazwisko / Numer NIP',
                'email' => 'E-mail',
                'phone' => 'Telefon',
            ],
        ],

        'prepayment' => [
            'active' => 1,
            'title' => 'Płatność',
            'fields' => [
                'checkbox' => 'Płatność',
                'amount' => 'Kwota przedpłaty'
                ],
        ],
        'order' => [
            'title' => 'Zamówienie',
            'accept' => [
                'title' => 'Wyrażam zgodę na przetwarzanie danych osobowych wpisanych w formularzu w celu udzielenia odpowiedzi na przesłane zapytanie zgodnie z',
                'name' => 'Polityką Prywatności',
                'link' => 'https://electra.hussaria.pl/content/17-polityka-prywatnosci',
            ],
            'agree' => [
                'title' => 'Akceptuję',
                'name' => 'regulamin',
                'link' => 'https://electra.hussaria.pl/pl/content/16-regulamin',
                'shop' => 'sklepu internetowego'
            ]
        ],
        'order_summary' => [
            'value' => 'Wartość zamówienia',
            'cost' => 'Koszt dostawy',
            'amount' => 'Razem',
            'back' => 'Powrót',
            'notification' => 'Produkt został dodany!',
            'confirm' => 'Dziękujemy za zamówienie!',
        ]
    ],
    
    //===============
    'package' => [
        'active' => 1,
        'name' => 'Elektryczna paka',
        'desc' => 'Elektryczna paka - zamów ⚙️🛒 doskonałe rozwiązanie do przechowywania siodeł i sprzętu jeździeckiego dla wymagających zawodników i pasjonatów jeździectwa. Paka wyposażona jest w duże koła i napęd elektryczny eliminuje wysiłek fizyczny i zapewnia łatwość w manewrowaniu.',
        'keywords' => 'hussaria electra, elektryczna paka, paka z napędem elektrycznym',
        'thumb' => 'he_thumb_elektryczna_paka.png',
        'status' => 'W magazynie',
        'deadline' => 'Gdy towaru nie ma na magazynie, termin realizacji wydłuża się do 3-4 tygodni',
        
        'show_price' => 1,
        'price' => 35547,
        'promo' => '',
        'shipping' => [
            'active' => 1,
            'free' => 1,
            'price' => 700,
            'promo' => 40,
            'class' => 'dark',
            'content' => 'Darmowa dostawa',
            'info' => 'na terenie całej Polski',
            'source' => 'Tylko na electra.hussaria.pl',
        ],
        'include' => [
            'intro_products' => 'W zestawie',
            'products' => [
                'battery' => [
                    'active' => 1,
                    'name' => 'Akumulator',
                    'desc' => 'Pojemność: 4 Ah',
                    'image' => 'battery.png',
                ],
                'charger' => [
                    'active' => 1,
                    'name' => 'Ładowarka',
                    'desc' => 'Do akumulatora',
                    'image' => 'charger.png',
                ],
                'pomp' => [
                    'active' => 1,
                    'name' => 'Pompka elektryczna',
                    'desc' => 'z funkcją Powerbanku',
                    'image' => 'pomp.png',
                ],
                'pharmacy' => [
                    'active' => 1,
                    'name' => 'Apteczka',
                    'desc' => 'Przybornik medyczny',
                    'image' => 'pharmacy.png',
                ],
                'lock' => [
                    'active' => 1,
                    'name' => 'Kłódka na szyfr',
                    'desc' => 'Ochronne zapięcie',
                    'image' => 'lock.png',
                ],
                'powerbank' => [
                    'active' => 1,
                    'name' => 'PowerBank',
                    'desc' => 'Z funkcją szybkiego ładowania',
                    'image' => 'powerbank.png',
                ],
                'cables' => [
                    'active' => 1,
                    'name' => 'Zestaw kabli',
                    'desc' => 'Zestaw kabli do ładowania telefonu 3w1',
                    'image' => 'cables.png',
                ],
                'gadgets' => [
                    'active' => 1,
                    'name' => 'Zestaw gadżetów',
                    'desc' => 'Materiałowa torba zakupowa, stylowa czapka z daszkiem, nożyczki taktyczne z zestawem śrubokrętów, kubek termiczny, magnetyczna tablica suchościeralna z kompletem akcesoriów',
                    'image' => 'gadgets.png',
                ],
            ],
            

        ]
    ],
    // ==============
    'extra' => 'Dodatkowo w ofercie',
    'products' => [
        'promo_battery' => [
            'active' => 1,
            'name' => 'Akumulator',
            'desc' => '',
            'parameters' => [
                'name' => 'Pojemność',
                'value' => '4 Ah',
            ],
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'battery_4ah.png',
            'show_price' => 1,
            'price' => 950,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 50,
                'class' => '',
                'content' => 'Dodstawa od',
            ],
        ],
        'promo_charger' => [
            'active' => 1,
            'name' => 'Ładowarka do akumulatora',
            'desc' => '',
            'parameters' => [
                'name' => '',
                'value' => '',
            ],
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'charger_4_5ah.png',
            'show_price' => 1,
            'price' => 550,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Dodstawa od',
            ],
        ],
        'promo_ramp' => [
            'active' => 1,
            'name' => 'Składany trap załadunkowy',
            'desc' => 'Wygodny w użyciu i łatwy do przechowywania, idealny do szybkiego załadunku i rozładunku. Po złożeniu zajmuje bardzo mało miejsca.',
            'parameters' => [
                'name' => 'Maks. obciążenie',
                'value' => '270 kg',
            ],
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'ramp_270kg.png',
            'show_price' => 1,
            'price' => 1490,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Dodstawa od',
            ],
        ],
        'promo_battery5' => [
            'active' => 1,
            'name' => 'Akumulator',
            'desc' => '',
            'parameters' => [
                'name' => 'Pojemność',
                'value' => '5 Ah',
            ],
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'battery_4ah.png',
            'show_price' => 1,
            'price' => 1050,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Dodstawa od',
            ],
        ],
        'promo_cover' => [
            'active' => 1,
            'name' => 'Pokrowiec na pakę',
            'desc' => '',
            'parameters' => [
                'name' => 'Kolor',
                'value' => 'czarny',
            ],
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'tack_cover.png',
            'show_price' => 1,
            'price' => 1990,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Dodstawa od',
            ],
        ],
        'promo_cover_trap' => [
            'active' => 1,
            'name' => 'Pokrowiec na trap',
            'desc' => '',
            'parameters' => [
                'name' => 'Kolor',
                'value' => 'czarny',
            ],
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'ramp_cover.png',
            'show_price' => 1,
            'price' => 480,
            'shipping' => [
                'active' => 0,
                'free' => 1,
                'price' => 0,
                'class' => '',
                'content' => 'Dodstawa od',
            ],
        ],
        
    ],
];