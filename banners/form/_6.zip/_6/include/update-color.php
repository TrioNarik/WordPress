<?php
session_start();

// Sprawdzenie tokena CSRF
if (!isset($_SERVER['HTTP_X_CSRF_TOKEN']) || $_SERVER['HTTP_X_CSRF_TOKEN'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Nieautoryzowany dostęp.']);
    logError('Nieautoryzowany dostęp podczas zmiany Koloru Paki. Błędny token !', 'error');
    exit;
}

// =======================================
// Kolor Paki
// =======================================
// Odczytanie danych JSON z JS [cart.js]
$dataColor = json_decode(file_get_contents("php://input"), true);

if (isset($dataColor['colorName']) && isset($dataColor['colorPrice'])) {
    $_SESSION['cart']['products']['paka']['color'] = [
        'name' => $dataColor['colorName'],
        'price' => $dataColor['colorPrice'],
        'ral' => $dataColor['colorRal'],
        'hex' => $dataColor['colorCode']
    ];
    echo json_encode(['status' => 'success']);
} else {
    logError('Nieprawidłowe dane podczas zmiany Koloru Paki', 'error');
    echo json_encode(['status' => 'error', 'message' => 'Nieprawidłowe dane.']);
}


?>
