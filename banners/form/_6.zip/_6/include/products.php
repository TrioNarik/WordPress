<?php
// ==========================================
// Funkcja do wyświetlania Produktów w zestawie
// ==========================================
function displayIncludePack($items) {
    if ($items) {
        echo '<ul id="gadgets-list" class="gadgets row row-cols-3 row-cols-sm-4 list-unstyled my-1 my-md-3">';
        foreach ($items as $itemKey => $item) {
            if ($item['active']) {
                echo '<li class="col-6 col-md-3 mb-4" data-id="'. $itemKey .'" data-name="'. $item['name'] .'">';
                
                  echo '<div class="gadget__image py-2 mb-2 text-center rounded">';
                    if (!empty($item['image'])) {
                        $imagePath = 'img/' . $item['image'];
                        $versionedImagePath = version($imagePath);
                        echo '<div class="thumbnail">';
                            echo '<img loading="lazy" decoding="async" fetchPriority="low" class="img-fluid" src="'. htmlspecialchars($versionedImagePath) .'" alt="' . $item['name'] .'">';
                        echo '</div>';
                    }
                  echo '</div>';

                  echo '<div class="gadget__name d-flex align-items-center justify-content-center gap-1">';
                    echo '<span>';
                        echo svg_code('checked.svg');
                    echo '</span>';
                    echo $item['name'];
                  echo '</div>';

                echo '</li>';
            }
        }
        echo '</ul>';
    }
}

// ==========================================
// Funkcja do wyświetlania Dodatkowych Produktów
// ==========================================
function displayProductCheckbox($items, $currency, $button) {
    echo '<div class="row">';
    foreach ($items as $itemKey => $item) {
        if ($item) {

            echo '<div class="col-12 col-md-4">';

                echo '<div class="featured m-2 p-2 p-md-4">';
                
                if (!empty($item['image'])) {

                    $imagePath = 'img/' . $item['image'];
                    $versionedImagePath = version($imagePath);

                    echo '<div class="image d-flex justify-content-center align-items-center text-center my-md-3">';

                    echo '<img loading="lazy" decoding="async" fetchPriority="low" class="img-fluid" src="' . htmlspecialchars($versionedImagePath) . '" alt="' . htmlspecialchars($item['name']) . '">';
                    echo '</div>';
                }

                    echo '<h6 class="text-center">'. $item['name'].'</h6>';
                    echo '<div class="parameters d-flex justify-content-between align-items-center gap-3 py-2 my-4">';
                        echo '<span class="text-center">'. htmlspecialchars($item['parameters']['name']).'</span>';
                        echo '<span class="text-center">'. htmlspecialchars($item['parameters']['value']).'</span>';
                    echo '</div>';

                    echo '<div class="d-flex justify-content-between align-items-center">';
                        if ($item['show_price']) {
                            
                                echo '<div id="'. $itemKey .'" class="col-4 col-md-5 product-price">';
                                    echo '<div class="block-price text-center p-2">';
                                        echo '<span>'. formatPriceWithSup($item['price']) .'</span> ';
                                        echo '<span>'. htmlspecialchars($currency) .'</span>';
                                    echo '</div>';
                                echo '</div>';

                                if ($item['shipping']['active']) {
                                echo '<div id="'. $itemKey .'" class="col-8 col-md-7">';
                                    echo '<div class="block-shipping text-end p-2">';
                                        echo '<span>'. htmlspecialchars($item['shipping']['content']) .' '. formatPriceWithSup($item['shipping']['price']) .'</span>';
                                    echo '</div>';
                                echo '</div>';
                                }
                            
                        }

                        echo '<div class="d-flex justify-content-start align-items-center gap-4">';
                        if ($item['active']) {
                            echo '<button type="button" class="btn btn-warning addToCart" data-button-action="add-to-cart" data-key="' . htmlspecialchars($itemKey) . '" data-img="'. htmlspecialchars($item['image']) .'" data-name="'. htmlspecialchars($item['name']) .'" data-price="'. $item['price'] .'" data-shipping="'. $item['shipping']['price'] .'">';
                            echo svg_code('cart.svg');
                            echo '</button>';
                        } else {
                            echo '<button type="button" class="btn btn-outline-light disabled cart">';
                            echo svg_code('cart.svg');
                            echo '</button>';
                        }
                        echo '</div>';
                
                    echo '</div>';

            echo '</div>';
            echo '</div>';

        }
    }
    echo '</div>';
}
?>