<?php
session_start();

// Sprawdzenie tokena CSRF
if (!isset($_SERVER['HTTP_X_CSRF_TOKEN']) || $_SERVER['HTTP_X_CSRF_TOKEN'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Nieautoryzowany dostęp.']);
    logError('Nieautoryzowany dostęp podczas zmiany Koloru Paki. Błędny token !', 'error');
    exit;
}

// =======================================
// Personalizacja
// =======================================
// Odczytanie danych JSON z JS [cart.js]
$dataCustomization = json_decode(file_get_contents("php://input"), true);

if (isset($dataCustomization['Title']) && isset($dataCustomization['Text'])) {
    // Sprawdź, czy personalizacja już istnieje w sesji
    if (!isset($_SESSION['cart']['products']['paka']['customization'])) {
        $_SESSION['cart']['products']['paka']['customization'] = [];
    }

    // Dodaj personalizację do sesji
    $_SESSION['cart']['products']['paka']['customization'][$dataCustomization['Title']] = [
        'title' => $dataCustomization['Title'],
        'text' => $dataCustomization['Text'],
        'color' => $dataCustomization['Color'] ?? null,
        'size' => $dataCustomization['Size'] ?? null,
        'font' => $dataCustomization['Font'] ?? null,
        'price' => $dataCustomization['Price'] ?? null,
        'promo' => $dataCustomization['Promo'] ?? null,
    ];

    // Pobierz wartość personalizacji z sesji
    $customizationValue = $_SESSION['cart']['products']['paka']['customization'][$dataCustomization['Title']] ?? '';

    // Wyślij odpowiedź w formacie JSON
    echo json_encode(['status' => 'success', 'message' => $customizationValue]);
    
} else {
    logError('Nieprawidłowe dane podczas zmiany Koloru Paki', 'error');
    echo json_encode(['status' => 'error', 'message' => 'Nieprawidłowe dane.']);
}



?>
