document.addEventListener('DOMContentLoaded', function() {

    // Button 'Zapisz konfigurację' + Waluta
    const saveConfigButton = document.getElementById('save-config');
    const currency = saveConfigButton.dataset.currency;


    // =======================================
    // 1. Aktualizacja w Koszyku i SESSION koloru Paki
    // =======================================
    const colorMarkerElement = document.getElementById('mainProductColorMarker');
    const colorNameElement = document.getElementById('mainProductColorName');
    const colorPriceElement = document.getElementById('mainProductColorPrice');

    function updateCartWithColor(colorName, colorPrice, colorCode, colorRal) {
        colorNameElement.textContent = `${encodeHTML(colorName)}`;
        colorNameElement.setAttribute('data-price', parseFloat(colorPrice));
        colorNameElement.setAttribute('data-color', encodeHTML(colorCode));
        colorNameElement.setAttribute('data-color-ral', encodeHTML(colorRal));
        colorPriceElement.textContent = colorPrice ? `${formatNumberWithSpaces(colorPrice)}` : `${formatNumberWithSpaces(0)}`;
        colorMarkerElement.style.backgroundColor = encodeHTML(colorCode);
    }

    const defaultColorOption = document.querySelector('#packColor a[data-default="1"]');
    if (defaultColorOption) {
        const colorName = defaultColorOption.getAttribute('title');
        const colorPrice = parseFloat(defaultColorOption.getAttribute('data-price'));
        const colorCode = defaultColorOption.getAttribute('data-color');
        const colorRal = defaultColorOption.getAttribute('data-color-ral');

        updateCartWithColor(colorName, colorPrice, colorCode, colorRal);
    }

    const colorOptions = document.querySelectorAll('#packColor a');
    colorOptions.forEach(option => {
        option.addEventListener('click', function(e) {
            e.preventDefault();

            const colorName = this.getAttribute('title');
            const colorPrice = parseFloat(this.getAttribute('data-price'));
            const colorCode = this.getAttribute('data-color');
            const colorRal = this.getAttribute('data-color-ral');

            console.log('Wysyłane :', { colorName, colorPrice, colorCode, colorRal });

            const colorCategory = this.getAttribute('data-category');
            const glitterLayer = document.getElementById('glitter-layer');
            if (colorCategory === 'brocate') {
                createGlitter(glitterLayer, 10000, 0); // Dodaj brokat => 0 - no blinking
            } else {
                removeGlitter(glitterLayer); // Usuń brokat
            }

            updateCartWithColor(colorName, colorPrice, colorCode, colorRal);

            // Wysłanie żądania AJAX do aktualizacji koloru w SESSION
            fetch('include/update-color.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="token"]').getAttribute('content')
                },
                body: JSON.stringify({
                    colorName: colorName,
                    colorPrice: colorPrice,
                    colorCode: colorCode,
                    colorRal: colorRal
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    console.log('Kolor został zaktualizowany w sesji.');
                    
                } else {
                    console.error('Błąd podczas aktualizacji koloru w sesji:', data.message);
                }
            })
            .catch(error => {
                console.error('Błąd sieciowy:', error);
            });
        });
    });



    // =======================================
    // 2. Personalizacja do Koszyka => save-config
    // =======================================
    function updateCartItem(data, blockId) {
    
        const cartBox   = document.getElementById('cartBox');
        let cartItem    = document.getElementById(blockId);
    
        // Dane w localStorage
        const storedData = JSON.parse(localStorage.getItem('HEisCustomization')) || {};


        // Jeśli 'Text' jest pusty, usuwamy blok i aktualizujemy sumę
        if (!data.Text) {
            if (cartItem) {
                cartBox.removeChild(cartItem);

                // Usuń dane z localStorage dla danego Bloku
                if (storedData && storedData[data.Title]) {
                    delete storedData[data.Title];
                    localStorage.setItem('HEisCustomization', JSON.stringify(storedData));
                    console.log('Dane usunięte z localStorage');
                }
            }
            updateCartTotal();
            return;
        }
    
        // Jeśli blok istnieje, aktualizujemy go
        if (cartItem) {
            // Aktualizujemy każdą właściwość (Text, Color, Price, Promo itp.)
            if (data.Title) {
                const titleElement = cartItem.querySelector('.Title');
                if (titleElement) {
                    titleElement.textContent = encodeHTML(data.Title);
                }
            }
    
            if (data.Text) {
                const textElement = cartItem.querySelector('.Text');
                if (textElement) {
                    textElement.textContent = encodeHTML(data.Text);
                }
            }
    
            if (data.Color) {
                const colorElement = cartItem.querySelector('.Color');
                if (colorElement) {
                    colorElement.style.backgroundColor = encodeHTML(data.Color);
                }
            } else {  // przy Grawerowaniu nie ma koloru
                const colorElement = cartItem.querySelector('.Color');
                if (colorElement) {
                    colorElement.remove();
                }
            }
    
            if (data.Price) {
                const priceElement = cartItem.querySelector('.Price');
                if (priceElement) {
                    priceElement.textContent = `${formatNumberWithSpaces(data.Price)} ${encodeHTML(currency)}`;
                }
            }
    
            if (data.Promo) {
                const promoElement = cartItem.querySelector('.Promo');
                if (promoElement) {
                    promoElement.textContent = `${formatNumberWithSpaces(data.Promo)} ${encodeHTML(currency)}`;
                    promoElement.style.color = 'green';
                }
            }
    
            if (data.Size) {
                const sizeElement = cartItem.querySelector('.Size');
                if (sizeElement) {
                    sizeElement.textContent = encodeHTML(data.Size);
                }
            }
    
            if (data.Format) {
                const formatElement = cartItem.querySelector('.Format');
                if (formatElement) {
                    formatElement.textContent = encodeHTML(data.Format);
                }
            } else {    // po odznaczeniu wszystkich formatów
                const formatElement = cartItem.querySelector('.Format');
                if (formatElement) {
                    formatElement.remove();
                }
            }
    
            if (data.Font) {
                const fontElement = cartItem.querySelector('.Font');
                if (fontElement) {
                    fontElement.textContent = encodeHTML(data.Font);
                }
            }
    
            if (data.Align) {
                const alignElement = cartItem.querySelector('.Align');
                if (alignElement) {
                    alignElement.textContent = encodeHTML(data.Align);
                }
            }
        } else {
            // Jeśli blok nie istnieje, tworzymy nowy
            cartItem = document.createElement('div');
            cartItem.id = blockId;
            cartItem.classList.add('cart-item', 'customization', 'my-3');
    
            // Budujemy HTML nowego elementu, każdy atrybut w osobnym <span>
            let innerHTML = `
                <div class="Title">${data.Title}</div>
                
                        
                <span class="Align">${encodeHTML(data.Align || '')}</span>
                

                <div class="d-flex align-items-center justify-content-between gap-2">
                    <div class="info d-flex align-items-center justify-content-start gap-2 my-2">
                        ${data.Color
                            ? `<span class="Color" ${data.Color ? `style="background-color: ${data.Color};"` : ''}></span>`
                            : ''
                        }
                        <span class="Text">${encodeHTML(data.Text)}</span>
                    </div>
                    <div class="price">
                        <span class="Price">
                            ${data.Promo
                                ? `<del>${formatNumberWithSpaces(data.Price)} ${currency}</del> ${formatNumberWithSpaces(data.Promo)} <span class="currency">${currency}</span>`
                                : (data.Price
                                    ? `${formatNumberWithSpaces(data.Price)} <span class="currency">${currency}</span>`
                                    : `${formatNumberWithSpaces(0)} <span class="currency">${currency}</span>`)
                            }
                        </span>
                    </div>
                </div>

                <div class="detail d-flex align-items-start justify-content-start gap-2">
                    <div class="d-flex align-items-start justify-content-start gap-2">
                        <span class="Font">${encodeHTML(data.Font || '')}</span>
                    </div>
                    <div class="d-flex align-items-start justify-content-start gap-2">
                        <span class="Size">${encodeHTML(data.Size || '')}</span>
                        <span class="Format">${encodeHTML(data.Format || '')}</span>
                    </div>
                </div>
            `;
            cartItem.innerHTML = innerHTML;
    
            cartBox.appendChild(cartItem);
        }

        const newData = {
            "Text": encodeHTML(data.Text || ''),
            "Color": data.Color || '',
            "Align": encodeHTML(data.Align || ''),
            "Font": encodeHTML(data.Font || ''),
            "Size": encodeHTML(data.Size || ''),
            "Format": encodeHTML(data.Format || '')
        };

        if (JSON.stringify(storedData[data.Title]) !== JSON.stringify(newData)) {
            storedData[data.Title] = newData;
            localStorage.setItem('HEisCustomization', JSON.stringify(storedData));
        }

        // Zauktualizuj dane w SESSION
        fetch('include/update-customization.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="token"]').getAttribute('content')
            },
            body: JSON.stringify({
                Title: data.Title,
                Text: data.Text,
                Color: data.Color,
                Align: data.Align,
                Size: data.Size,
                Font: data.Font,
                Price: data.Price,
                Promo: data.Promo
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                console.log('Personalizacja została zaktualizowana w sesji:', data.message);
            } else {
                console.error('Błąd podczas aktualizacji personalizacji w sesji:', data.message);
            }
        })
        .catch(error => {
            console.error('Błąd sieciowy:', error);
        });
        
        // Aktualizujemy sumę cen w koszyku
        updateCartTotal();
    }
    
    function getTextData(sectionPrefix) {
        const title     = document.getElementById(`text_${sectionPrefix}`).dataset.name || false;
        const text      = document.getElementById(`text_${sectionPrefix}`).value.trim();
        const color     = document.getElementById(`selectedColorText_${sectionPrefix}`)?.style.backgroundColor || false;
        const align     = document.querySelector(`#textAlign_${sectionPrefix} .tools.active`)?.dataset.alignName || false;
        const size      = document.querySelector(`#textSize_${sectionPrefix} .tools.active`)?.dataset.sizeName || false;
        const formats   = Array.from(document.querySelectorAll(`#textStyle_${sectionPrefix} .tools.active`))
            .map(tool => tool.dataset.styleName)
            .join(', ') || false;
        const font      = document.querySelector(`#fontFamily_${sectionPrefix} canvas.active`)?.dataset.fontName || false;
        const price     = parseFloat(document.getElementById(`text_${sectionPrefix}`).dataset.price) || 0;
        const promo     = document.getElementById(`text_${sectionPrefix}`).dataset.promo || false;
    
        return {
            Title: title,
            Text: text,
            Color: color,
            Align: align,
            Size: size,
            Format: formats,
            Font: font,
            Price: price,
            Promo: promo
        };
    }
    
    function handleSaveConfig() {
        
        // const sections = ['grawerTopPanel', 'toppanel', 'door', 'side'];
    
        // ✅ Elastyczne i skalowalne => dodasz/usuniesz sekcję, kod się dostosuje.
        const sections = Array.from(document.querySelectorAll('input[id^="text_"]'))
            .map(el => el.id.replace('text_', '')); // Usuwa 'text_' z ID, zostawiając same nazwy sekcji
    
    
        sections.forEach(sectionId => {
            const sectionData = getTextData(sectionId);
            if (sectionData) {
                updateCartItem(sectionData, `${sectionId}-item`);
            } else {
                showError(`Brak danych dla sekcji: ${sectionId}`);
                console.warn(`Brak danych dla sekcji: ${sectionId}`);
            }
        });
    }
    
    
    saveConfigButton.addEventListener('click', handleSaveConfig);   // zapisz Personalizację
    

    // ================================
    // 3. Flaga
    // ================================

    // saveConfigButton.addEventListener('click', getFlagOptions);     // zapisz Flagę


    // ================================
    // 4. Dodawanie pozostałych produktów do Koszyka => add-to-cart
    // ===============================
    const cartButtons = document.querySelectorAll('.addToCart');
    const cartItemsElement = document.getElementById('button_cart_total');
    const cartContainer = document.getElementById('cartBoxPromo');

    // Pobranie istniejących elementów total, delivery, value
    const cartTotalElement = document.getElementById('cartTotal');   // Razem
    const cartDeliveryElement = document.getElementById('cartDelivery'); // Koszt dostawy
    const cartValueElement = document.getElementById('cartValue'); // Wartość zamówienia

    const transInfo = document.getElementById('featured_info_toCart');
    const buttonDeleteText = transInfo.getAttribute('data-delete-button');
    const errorAddToCart = transInfo.getAttribute('data-error-add-message');

    // Obiekt koszyka
    const Cart = {
        items: [],

        async addItem(itemKey, image, name, price, shipping) {
            try {
                const response = await fetch('include/verify-add-to-cart.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key: itemKey, image, name, price, shipping })
                });

                if (!response.ok) throw new Error(errorAddToCart);
                const result = await response.json();
                if (result.status !== 'success') throw new Error(errorAddToCart);

                const verifiedItem = result.item;
                const existingItem = this.items.find(item => item.key === verifiedItem.key);

                if (existingItem) {
                    existingItem.quantity += 1;
                } else {
                    this.items.push({ ...verifiedItem, quantity: 1 });
                }

                this.updateView();
            } catch (error) {
                showError(error.message);
            }
        },

        removeItem(itemKey) {
            this.items = this.items.filter(item => item.key !== itemKey);
            this.updateView();
        },

        updateView() {
            cartContainer.innerHTML = '';

            let totalPrice = 0;
            let totalShipping = 0;

            this.items.forEach(item => {
                const itemTotal = item.price * item.quantity;
                totalPrice += itemTotal;

                const shippingCost = typeof item.shipping === 'number' ? item.shipping : parseFloat(item.shipping.price || 0);
                totalShipping += shippingCost * item.quantity;

                const itemElement = document.createElement('div');
                itemElement.classList.add('cart-items');
                itemElement.innerHTML = `
                    <div class="row d-flex align-items-center p-2">
                        <div class="col-2">
                            <img class="img-fluid" src="img/${item.image}" alt="${item.name}">
                        </div>
                        <div class="col-4">
                            <span class="name">${item.name}</span>
                            <span class="shipping">${shippingCost.toFixed(2)}</span>
                        </div>
                        <div class="col-2">
                            <span class="price">${itemTotal.toFixed(2)}</span>
                        </div>
                        <div class="col-2">
                            <span class="quantity">${item.quantity}</span>
                        </div>
                        <div class="col-2">
                            <button type="button" class="btn btn-danger removeFromCart" data-key="${item.key}">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
                                    <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
                                    <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
                                </svg>
                            </button>
                        </div>
                    </div>
                `;
                cartContainer.appendChild(itemElement);
            });

            // Aktualizacja wartości w HTML-u
            cartValueElement.textContent = totalPrice.toFixed(2); // Wartość zamówienia
            cartDeliveryElement.textContent = totalShipping.toFixed(2); // Koszt dostawy
            cartTotalElement.textContent = (totalPrice + totalShipping).toFixed(2); // Razem

            cartItemsElement.textContent = this.items.reduce((total, item) => total + item.quantity, 0);

            document.querySelectorAll('.removeFromCart').forEach(button => {
                button.addEventListener('click', function() {
                    Cart.removeItem(this.getAttribute('data-key'));
                });
            });
        }
    };

    // Obsługa przycisków dodawania do koszyka
    cartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const itemKey = this.getAttribute('data-key');
            const image = this.getAttribute('data-img');
            const name = this.getAttribute('data-name');
            const price = parseFloat(this.getAttribute('data-price'));
            const shipping = parseFloat(this.getAttribute('data-shipping'));
            
            Cart.addItem(itemKey, image, name, price, shipping);
        });
    });

});
