<?php


session_start();

// Szablon mailingu
$templatePath = '../mail/order.html';

// Załaduj funkcje
require_once 'functions.php';


// Sprawdzenie tokena CSRF
if (!isset($_SERVER['HTTP_X_CSRF_TOKEN']) || $_SERVER['HTTP_X_CSRF_TOKEN'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Nieautoryzowany dostęp.']);
    logError('Nieautoryzowany dostęp podczas próby wysłania Formularza. Błędny token !', 'error');
    exit;
}



// Załaduj PHPMailer
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;


// Załaduj konfiguracje mailingów i klucz szyfrujący
$email_config = require '../config/mailer.php'; // ustawienia SMTP
$admin_config = require '../config/admin.php'; // ustawienia admina i secret_key



// Sprawdź SESSION Settings
if ($_SESSION['cart']['settings']) {
    $lang = $_SESSION['cart']['settings']['lang'];
    $currency = $_SESSION['cart']['settings']['currency'];

    // Pobranie pliku tłumaczeń
    $lang_file = "../mail/lang/$lang.php";

    // Sprawdź, czy plik tłumaczeń istnieje
    if (file_exists($lang_file)) {
        $translate = safeInclude($lang_file);
    } else {
        logError("Brak pliku tłumaczeń w mail: $lang_file . Zatrzymana akcja wysyłki formularza!", '404');
        exit;
    }
} else {
    // Jeśli lang lub currency nie są ustawione w sesji, zatrzymaj dalsze działanie
    logError('Brak _SESSION[Cart] => Lang i Currency, aby wysyłać e-mail [lub ponowna próba wysłania tego samego maila, gdy _SESSION[Cart] został już zresetowany]. Zatrzymana akcja wysyłki formularza!');
    exit;
}

// Pobierz dane z inputów Formularza i wyświetl translate errors przy walidacji oraz timer blokady ponownego wysłania
$formData = processFormUserData($translate['notifications'], $admin_config['admin']['timer']);

// PHPMailer
$mail = new PHPMailer(true);

if ($formData) {
    
    // Pobierz dane z SESSION o Koszyku
    $productsCartData = prepareCartSessionData($currency);

    if ($productsCartData) {
    
        // Prepare SCALONE dane (Form & Session)
        $orderData = [
            'name'      => $formData['name'],
            'lastname'  => $formData['lastname'],
            'email'     => $formData['email'],
            'phone'     => $formData['phone'],

            'main_product'      => $productsCartData['mainProduct'],
            'extra_products'    => $productsCartData['extraProducts'],
            'total'             => $productsCartData['total'],
            'delivery'          => $productsCartData['delivery_total'],
            
            'date'      => date('Y-m-d'),
            'timestamp' => date('Y-m-d H:i:s'),
        ];
        

        // Proceed with order processing and email sending
        if ($admin_config['admin']['active'] == 1) {
            
            // Zamień w Szablonie Dane i Tłumaczenia
            $replacedMailTemplate = changeEmailTemplateToReciveData($templatePath, $orderData, $translate, $currency, $admin_config);

            if ($replacedMailTemplate) {            

                // Send emails
                $sendToAdmin    = sendEmail($mail, $email_config, $translate['subject']['admin'], $replacedMailTemplate, $admin_config['admin']['mail']);
                $sendToClient   = sendEmail($mail, $email_config, $translate['subject']['client'], $replacedMailTemplate, $formData['email']);
            
                // Determine the response based on the email sending results
                if ($sendToAdmin && $sendToClient) {
                    
                    // Usuń dane z SESSION
                    unset($_SESSION['cart']);

                    $response = ['status' => 'success', 'message' => $translate['notifications']['success']['send']];

                } else {

                    if (!$sendToClient) {
                        logError('Nie udało się wysłać KOPII maila do Kienta', 'form_send');
                    }
                    if (!$sendToAdmin) {
                        logError('Nie udało się wysłać KOPII maila do Admina', 'form_send');
                    }
                    $response = ['status' => 'error', 'message' => $translate['notifications']['errors']['send']];
                }
            }
            
        } else {
            // Email sending wyłaczone
            logError('Wysyłanie zamówienia drogą mailową jest wyłączone w ustawieniach [admin_config]!', 'mailing_config');
            $response = ['status' => 'error', 'message' => $translate['notifications']['errors']['disabled']];
        }

        // Serializacja i szyfrowanie Danych przez zapisem do pliku
        $orderJson = json_encode($orderData, JSON_PRETTY_PRINT);
        $encryptedOrder = encryptData($orderJson, $admin_config['admin']['secret_key']);

        // Zapis do pliku zamówień
        if (file_put_contents($admin_config['admin']['save_to_file'], $encryptedOrder . "\n", FILE_APPEND) === false) {
            logError('Nie udało się zapisać zamówienia do pliku:' . $admin_config['admin']['save_to_file'], 'write_order');
        }

    // Brak zapisanych produktów w Koszyku/Konfiguracji
    } else {
        $response = ['status' => 'error', 'message' => $translate['notifications']['errors']['empty']];
    }
    
} else {
    // Brak wymaganych danych o Kliencie w formularzu
    logError('Nieprawidłowe lub puste dane z inputów formularza. Brak formUserData !', 'form_dane');
    $response = ['status' => 'error', 'message' => $translate['notifications']['errors']['validate']];
}

// Return JSON response
echo json_encode($response);


// =============================================
// FUNKCJE pomocnicze ==========================
// =============================================

// Walidacja pól formularza + timer czasowy
function processFormUserData($translate, $timer) {

    // Dane wejściowe z formularza
    $name       = htmlspecialchars($_POST['name']);
    $lastname   = htmlspecialchars($_POST['lastname']);
    $email      = htmlspecialchars($_POST['email']);
    $phone      = htmlspecialchars($_POST['phone']);

    $agree      = isset($_POST['agree']) ? htmlspecialchars($_POST['agree']) : '';
    $accept     = isset($_POST['accept']) ? htmlspecialchars($_POST['accept']) : '';
    // 
    $bot        = htmlspecialchars($_POST['human']);

    // Pobranie danych isUser i isForm
    $isUser     = isset($_POST['isUser']) ? filter_var($_POST['isUser'], FILTER_VALIDATE_BOOLEAN) : false;
    $isForm     = isset($_POST['isForm']) ? htmlspecialchars($_POST['isForm']) : '';

    // Bot checking
    if (trim($bot) != '') {
        logError('BOT detected. Wysłanie formularza zignorowano.', 'bot_detected');
        echo json_encode(['status' => 'error', 'message' => 'Bot detected']);
        exit;
    }

    // Walidacja inputów
    $errors = [];

    if (empty($name)) {
        $errors['name'] = $translate['errors']['fields']['empty']['name'];
        logError('Pusty [name]. Wysłanie formularza wstrzymano', 'name_incorrect');
    }

    if (empty($lastname)) {
        $errors['lastname'] = $translate['errors']['fields']['empty']['lastname'];
        logError('Pusty [lastname]. Wysłanie formularza wstrzymano', 'lastname_incorrect');
    }

    if (empty($email)) {
        $errors['email'] = $translate['errors']['fields']['empty']['email'];
        logError('Pusty [email]. Wysłanie formularza wstrzymano', 'email_incorrect');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = $translate['errors']['fields']['incorect']['email'];
        logError('Niepoprawny format [e-mail]. Wysłanie formularza wstrzymano', 'email_incorrect');
    }

    if (empty($phone)) {
        $errors['phone'] = $translate['errors']['fields']['empty']['phone'];
        logError('Pusty [phone]. Wysłanie formularza wstrzymano', 'phone_incorrect');
    } elseif (!preg_match('/^\+?[0-9\s\-()]{9,15}$/', $phone)) {
        $errors['phone'] = $translate['errors']['fields']['incorect']['phone'];
        logError('Niepoprawny format [phone]. Wysłanie formularza wstrzymano', 'phone_incorrect');
    }

    if (empty($agree)) {
        $errors['agree'] = $translate['errors']['fields']['empty']['agree'];
        logError('Pusty [agree]. Wysłanie formularza wstrzymano', 'agree_incorrect');
    }

    if (empty($accept)) {
        $errors['accept'] = $translate['errors']['fields']['empty']['accept'];
        logError('Pusty [accept]. Wysłanie formularza wstrzymano', 'accept_incorrect');
    }

    // Walidacja isUser Browser => LocalStorage
    if (!$isUser || $isUser != 1) {
        $errors['browser'] = $translate['errors']['fields']['incorect']['browser'];
        logError('Brak przeglądarki użytkownika. Nieautoryzowane wejście [BOT]. Wysłanie formularza wstrzymano.', 'user_not_browser');
    }

    // Walidacja isForm send TIMER => LocalStorage < timer
    if (!$isForm || $isForm != 0) {
        $lastFormSentTime = new DateTime($isForm, new DateTimeZone('UTC'));
        $currentDateTime = new DateTime('now', new DateTimeZone('UTC'));

        $intervalInSeconds = $currentDateTime->getTimestamp() - $lastFormSentTime->getTimestamp();

        if ($intervalInSeconds < $timer) { // Zmieniono na minuty
            $errors['timer'] = $translate['errors']['fields']['incorect']['timer'];
            logError("Zbyt szybkie ponowne wysłanie formularza. Nie czekał {$timer} sekund.", 'user_re_submit');
        }
    }


    // ==================================
    // Jeśli są błędy, zwróć je
    if (!empty($errors)) {
        logError($translate['errors']['validate'], 'form_incorrect');
        echo json_encode(['status' => 'error', 'message' => $translate['errors']['validate'], 'errors' => $errors]);
        exit;
    }

    // Wszystko jest OK, zwróć dane
    return [
        'name'      => $name,
        'lastname'  => $lastname,
        'email'     => $email,
        'phone'     => $phone,
    ];
}

// Pobieranie zapisanych w SESSION danych
function prepareCartSessionData($currency) {
    // Initialize zmiennych
    $mainProduct = [];
    $extraProducts = [];
    $total = 0;
    $delivery_total = 0;

    // Sprawdź SESSION Cart => Products
    if (isset($_SESSION['cart']['products']) && !empty($_SESSION['cart']['products'])) {
        // Iterate over products in the session
        foreach ($_SESSION['cart']['products'] as $key => $product) {
            // Add product name and price to the list
            $productDetails = $product['name'] . ', ' . $product['price'] . ' ' . $currency;

            // Add quantity and final price, if it exists
            if (isset($product['quantity'])) {
                $productDetails .= ' x ' . $product['quantity'] . ' = ' . ($product['price'] * $product['quantity']) . ' ' . $currency;
            }

            // Add color and price, if it exists
            if (isset($product['color']['name']) && isset($product['color']['price'])) {
                $productDetails .= "\n[color: " . $product['color']['name'] . ' [' . $product['color']['hex'] . ', ' . $product['color']['ral'] . '], ' . $product['color']['price'] . ' ' . $currency . ']';
                // Add color price to total
                $total += $product['color']['price'];
            }

            // Add customization and price, if it exists
            if (!empty($product['customization'])) {
                foreach ($product['customization'] as $customization) {
                    $productDetails .= "\nPersonalizacja: " .
                        ($customization['title'] ?? '-') . ', ' .
                        ($customization['text'] ?? '-') . ', ' .
                        ($customization['align'] ?? '-') . ', ' .
                        ($customization['font'] ?? '-') . ', ' .
                        ($customization['color'] ?? '-') . ', ' .
                        ($customization['size'] ?? '-') . ', ' .
                        ($customization['format'] ?? '-') . ', ' .
                        ($customization['price'] ?? '0') . ' ' . $currency;
                }
            }

            // Add flag and price, if it exists
            if (!empty($product['flag'])) {
                $productDetails .= "\nFlaga: " . ($product['flag']['country'] ?? '-') . ', ' .
                    ($product['flag']['price'] ?? '0') . ' ' . $currency;
            }

            // Categorize products
            if ($key === 'paka') {
                $mainProduct[] = $productDetails;
            } else {
                $extraProducts[] = $productDetails;
            }

            // Add product price to total
            $total += isset($product['quantity']) ? $product['price'] * $product['quantity'] : $product['price'];

            // Add delivery cost to total
            if (isset($product['shipping']['price'])) {
                $delivery_total += $product['shipping']['price'];
            }
        }
    } else {
        // If there are no default products in the Cart, stop further action
        logError('Brak domyślnych produktów w Koszyku w _SESSION Cart Products do wysyłki e-mail. Zatrzymana akcja wysyłki formularza!');
        exit;
    }

    // Return the prepared data
    return [
        'mainProduct' => $mainProduct,
        'extraProducts' => $extraProducts,
        'total' => $total,
        'delivery_total' => $delivery_total,
    ];
}

// Zamień w szablonie mailingu Dane z formularza i session
function changeEmailTemplateToReciveData($templatePath, $orderData, $translate, $currency, $adminConfig) {
    // Sprawdzenie, czy plik szablonu istnieje
    if (!file_exists($templatePath)) {
        logError('Nie znaleziono szablonu email w ' . $templatePath, '404');
        return false;
    }
    
    // Wczytanie zawartości szablonu
    $template = file_get_contents($templatePath);
    
    // Mapa placeholderów do tłumaczeń
    $placeholders = [
        '[lang:content_title]'                          => $translate['content']['title'],
        '[lang:content_header_hello]'                   => $translate['content']['header']['hello'],
        '[lang:content_header_intro]'                   => $translate['content']['header']['intro'],
        '[lang:content_summary_table_header_title]'     => $translate['content']['summary']['table']['header']['title'],
        '[lang:content_summary_table_header_date]'      => $translate['content']['summary']['table']['header']['date'],
        '[lang:content_summary_table_rows_total]'       => $translate['content']['summary']['table']['rows']['total'],
        '[lang:content_summary_table_rows_name]'        => $translate['content']['summary']['table']['rows']['name'],
        '[lang:content_summary_table_rows_lastname]'    => $translate['content']['summary']['table']['rows']['lastname'],
        '[lang:content_summary_table_rows_email]'       => $translate['content']['summary']['table']['rows']['email'],
        '[lang:content_summary_table_rows_phone]'       => $translate['content']['summary']['table']['rows']['phone'],
        '[lang:content_summary_table_rows_order]'      => $translate['content']['summary']['table']['rows']['order'],
        '[lang:content_summary_table_rows_exta]'        => $translate['content']['summary']['table']['rows']['extra'],
        '[lang:content_helper_head]'                    => $translate['content']['helper']['head'],
        '[lang:content_helper_content]'                 => $translate['content']['helper']['content'],
        '[lang:content_helper_info]'                    => $translate['content']['helper']['info'],
        '[lang:footer_link]'                            => $translate['footer']['link'],
        '[lang:footer_copyright]'                       => $translate['footer']['copyright'],
        '[lang:currency]'                               => $currency,
        '[lang:content_header_shop]'                    => $translate['content']['header']['shop'],
        // ===== CONFIG OPTIONS ====
        '[[admin_office_phone]]'                        => $adminConfig['admin']['office_phone'],
        '[[admin_office_email]]'                        => $adminConfig['admin']['office_email']
    ];
    
    // Zamiana zmiennych zamówienia w szablonie
    foreach ($orderData as $key => $value) {
        if ($key === 'main_product' || $key === 'extra_products') {
            // Generowanie listy produktów z cenami
            $productHtml = '';
            foreach ($value as $productDetails) {
                $productHtml .= "<li>" . htmlspecialchars($productDetails) . "</li>";
            }
            // Zamiana znacznika na gotową listę produktów
            $template = str_replace('{{_' . $key . '_}}', "<ul>$productHtml</ul>", $template);
        } else {
            // Zamiana innych zmiennych w szablonie
            $template = str_replace('{{_' . $key . '_}}', htmlspecialchars($value), $template);
        }
    }
    
    // Zamiana placeholderów na tłumaczenia
    $replacedTemplate = strtr($template, $placeholders);
    
    return $replacedTemplate;
}

// Wysyłanie maila SMPT
function sendEmail($mail, $smtpConfig, $subject, $template, $recipientEmail) {
    try {
        // SMTP Configuration
        if (!$mail->isSMTP()) {
            $mail->isSMTP();
            $mail->Host = $smtpConfig['smtp']['host'];
            $mail->SMTPAuth = true;
            $mail->Username = $smtpConfig['smtp']['username'];
            $mail->Password = $smtpConfig['smtp']['password'];
            $mail->SMTPSecure = $smtpConfig['smtp']['encryption'];
            $mail->Port = $smtpConfig['smtp']['port'];
        }

        // Send email
        $mail->setFrom($smtpConfig['smtp']['from_email'], $smtpConfig['smtp']['from_name']);
        $mail->addAddress($recipientEmail);
        $mail->Subject = $subject;
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = "base64";
        $mail->isHTML(true);
        $mail->Body = $template;
        $mail->send();
        return true;
    } catch (Exception $e) {
        logError('Błąd przy wysyłaniu e-maili: ' . $e->getMessage(), 'error');
        logError('Nie udało się wysłać wiadomości e-mail. Błąd: ' . $mail->ErrorInfo, 'error_send');
        return false;
    }
}

// Funkcja szyfrowania
function encryptData($data, $key) {
    $iv = random_bytes(openssl_cipher_iv_length('AES-128-CBC')); // Generowanie losowego IV
    $encrypted = openssl_encrypt($data, 'AES-128-CBC', $key, 0, $iv); // Szyfrowanie danych
    return base64_encode($iv . $encrypted); // Dodanie IV do zaszyfrowanych danych
}


