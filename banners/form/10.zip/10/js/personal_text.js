// Aktywacja TABS Text personalizacji:
document.addEventListener("DOMContentLoaded", function () {

    const navTabLink = document.querySelectorAll('.nav-tab');
    const sections = document.querySelectorAll('.positions-tabs');

    navTabLink.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const sectionId = this.getAttribute('data-target');

            // Usuń klasę active z wszystkich sekcji i linków
            sections.forEach(section => {
                section.classList.remove('active');
            });
            navTabLink.forEach(link => {
                link.classList.remove('active');
            });

            // Dodaj klasę active do klikniętej sekcji i linku
            document.getElementById(sectionId).classList.add('active');
            this.classList.add('active');
            
        });
    });


    // === Pola tekstowe (inputy)
    const textInputs = document.querySelectorAll('.form-control[id^="text_"]');

    textInputs.forEach(input => {
        input.addEventListener("input", function () {
            const targetId = this.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.textContent = encodeHTML(this.value.trim()); // Zabezpieczamy przed XSS
            }
        });

    });


    // === Kolor tekstu w SVG
    const colorPickers = document.querySelectorAll('.colors .color-txt');

    colorPickers.forEach(colorPicker => {
        colorPicker.addEventListener("click", function (event) {
            event.preventDefault();

            const selectedColor = this.getAttribute("data-color");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            // Znajdź odpowiadający input tekstowy w tej sekcji
            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            // Znajdź odpowiadający element <text> w SVG
            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.setAttribute("fill", selectedColor); // Ustawienie koloru tekstu w SVG
            }

            // Zaktualizuj kolor w przycisku podglądu
            const colorPreview = section.querySelector(`#selectedColorText_${inputField.id.replace("text_", "")}`);
            if (colorPreview) {
                colorPreview.style.backgroundColor = selectedColor;
            }
        });
    });


    // === Wyrównanie tekstu w SVG
    const alignButtons = document.querySelectorAll('.tools[id^="textAlignt_"] button');

    alignButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedX = this.getAttribute("data-x");
            const selectedY = this.getAttribute("data-y");
            const selectedAnchor = this.getAttribute("data-anchor");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.setAttribute("x", selectedX);
                svgText.setAttribute("y", selectedY);
                svgText.setAttribute("text-anchor", selectedAnchor);
            }

            // 🔥 Zarządzanie klasą active dla przycisków wyrównania
            const alignGroup = section.querySelectorAll('.tools[id^="textAlignt_"] button');
            alignGroup.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
        });
    });

    // === Rozmiar tekstu w SVG
    const sizeButtons = document.querySelectorAll('.tools[id^="textSize_"] button');

    sizeButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedSize = this.getAttribute("data-size");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                svgText.setAttribute("font-size", selectedSize); // Zmiana rozmiaru tekstu w SVG
            }

            // 🔥 Zarządzanie klasą active dla przycisków
            const sizeGroup = section.querySelectorAll('.tools[id^="textSize_"] button');
            sizeGroup.forEach(btn => btn.classList.remove('active')); // Usunięcie active z innych
            this.classList.add('active'); // Dodanie active do klikniętego
        });
    });


    // === Formatowanie tekstu w SVG
    const styleButtons = document.querySelectorAll('.tools[id^="textStyle_"] button');

    styleButtons.forEach(button => {
        button.addEventListener("click", function () {
            const selectedStyle = this.getAttribute("data-style");
            const section = this.closest('.positions-tabs');
            if (!section) return;

            const inputField = section.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const targetId = inputField.id.replace("text_", "previewText_");
            const svgText = document.getElementById(targetId);

            if (svgText) {
                // Sprawdzenie, czy przycisk jest aktywny (czy ma klasę 'active')
                const isActive = this.classList.contains('active');

                // Dodanie lub usunięcie odpowiedniego stylu
                if (selectedStyle === "bold") {
                    if (isActive) {
                        svgText.removeAttribute("font-weight");
                    } else {
                        svgText.setAttribute("font-weight", "bold");
                    }
                } else if (selectedStyle === "italic") {
                    if (isActive) {
                        svgText.removeAttribute("font-style");
                    } else {
                        svgText.setAttribute("font-style", "italic");
                    }
                } else if (selectedStyle === "underline") {
                    if (isActive) {
                        svgText.removeAttribute("text-decoration");
                    } else {
                        svgText.setAttribute("text-decoration", "underline");
                    }
                }
            }

            // Zarządzanie klasą 'active' dla przycisków
            this.classList.toggle('active');
        });
    });


    // === Krój czcionki w SVG
    const fontFamilyLists = document.querySelectorAll('ul.scrollable-list[id^="fontFamily_"]');

    fontFamilyLists.forEach(list => {
        const fontButtons = list.querySelectorAll('li canvas');

        fontButtons.forEach(button => {
            button.addEventListener("click", function () {
                const selectedFontFamily = this.getAttribute("data-family");
                const section = this.closest('.positions-tabs');
                if (!section) return;

                const inputField = section.querySelector('.form-control[id^="text_"]');
                if (!inputField) return;

                const targetId = inputField.id.replace("text_", "previewText_");
                const svgText = document.getElementById(targetId);

                if (svgText) {
                    svgText.setAttribute("font-family", selectedFontFamily); // Zmiana kroju czcionki w SVG
                }

                // Zarządzanie klasą active dla przycisków
                fontButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });
    
    



});

