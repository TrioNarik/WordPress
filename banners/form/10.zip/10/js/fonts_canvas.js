document.addEventListener("DOMContentLoaded", function () {
    // === Krój czcionki w SVG
    const fontFamilyLists = document.querySelectorAll('ul.scrollable-list[id^="fontFamily_"]');

    fontFamilyLists.forEach(list => {
        const fontButtons = list.querySelectorAll('li canvas');

        fontButtons.forEach(button => {
            button.addEventListener("click", function () {
                const selectedFontFamily = this.getAttribute("data-family");
                const section = this.closest('.positions-tabs');
                if (!section) return;

                const inputField = section.querySelector('.form-control[id^="text_"]');
                if (!inputField) return;

                const targetId = inputField.id.replace("text_", "previewText_");
                const svgText = document.getElementById(targetId);

                if (svgText) {
                    svgText.setAttribute("font-family", selectedFontFamily); // Zmiana kroju czcionki w SVG
                }

                // Zarządzanie klasą active dla przycisków
                fontButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });

    function updateCanvas(canvasEl, font, text, name, rating, badge, colorText = false, backgroundColor = false) {
        const canvas = canvasEl; // Użyj przekazanego elementu canvas zamiast pobierania go ponownie
        const container = canvas.parentNode;
        const ctx = canvas.getContext("2d");

        // Ustaw szerokość i wysokość canvas na 100% szerokości kontenera
        canvas.width = container.clientWidth;
        canvas.height = 45;

        const width = canvas.width;
        const height = canvas.height;

        ctx.clearRect(0, 0, width, height);
        ctx.fillStyle = backgroundColor ? backgroundColor : "#F0F0F0";
        ctx.fillRect(0, 0, width, height);

        // Rysowanie kółek rankingowych
        for (let i = 0; i < 5; i++) {
            ctx.beginPath();
            ctx.arc(width - (6 * (i + 1)), 10, 2, 0, 2 * Math.PI);
            ctx.strokeStyle = "#000000"; // Kolor obrysu
            ctx.stroke();
        }

        // Wypełnianie kółek na podstawie oceny
        for (let i = 0; i < rating; i++) {
            ctx.beginPath();
            ctx.arc(width - (6 * (i + 1)), 10, 2, 0, 2 * Math.PI);
            ctx.fillStyle = "#000000"; // Kolor wypełnienia
            ctx.fill();
        }

        // Rysowanie nazwy
        ctx.font = "10px Montserrat, sans-serif";
        ctx.fillStyle = "#000000";
        ctx.textAlign = "left";
        ctx.fillText(name, 5, 10);

        // Rysowanie odznaki
        ctx.font = "9px Montserrat, sans-serif";
        ctx.fillStyle = "#000000";
        ctx.fontVariantCaps = "small-caps";
        ctx.letterSpacing = "5px";
        ctx.textAlign = "left";
        ctx.fillText(badge, 5, height / 2);

        ctx.font = font;
        ctx.fillStyle = colorText ? colorText : "#000000";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const displayText = text.trim() ? text : `${name}`;
        ctx.fillText(displayText, width / 2, height / 2);
    }

    function updateAllCanvases() {
        const panels = document.querySelectorAll('.positions-tabs');

        panels.forEach(panel => {
            const inputField = panel.querySelector('.form-control[id^="text_"]');
            if (!inputField) return;

            const inputText = encodeHTML(inputField.value);
            const textColor = panel.querySelector('.color-txt.selected')?.getAttribute('data-color') || '#000000';

            panel.querySelectorAll('canvas').forEach(canvasEl => {
                const font = canvasEl.getAttribute('data-font');
                const name = canvasEl.getAttribute('data-name');
                const family = canvasEl.getAttribute('data-family');
                const rating = parseInt(canvasEl.getAttribute('data-rating'), 10); // Rating jest liczbą
                const badge = canvasEl.getAttribute('data-badge');
                updateCanvas(canvasEl, font, inputText, name, rating, badge, textColor);

                // Dodaj obsługę zdarzenia click
                canvasEl.addEventListener('click', () => {
                    // Usuń klasę .selected z wszystkich canvasów w panelu
                    panel.querySelectorAll('canvas').forEach(c => c.classList.remove('selected'));
                    // Dodaj klasę .selected do klikniętego canvasu
                    canvasEl.classList.add('selected');

                    // Ustaw font na SVG, jeśli element istnieje
                    const previewText = panel.querySelector(`#${inputField.id.replace("text_", "previewText_")}`);
                    if (previewText) {
                        previewText.setAttribute("font-family", family);
                    }
                });

                // Ustaw kolor font na SVG, jeśli element istnieje
                const previewText = panel.querySelector(`#${inputField.id.replace("text_", "previewText_")}`);
                if (previewText) {
                    previewText.setAttribute("fill", textColor);
                }
            });
        });
    }

    document.querySelectorAll('.form-control[id^="text_"]').forEach(inputField => {
        inputField.addEventListener("input", updateAllCanvases);
    });

    document.querySelectorAll('.color-txt').forEach(colorOption => {
        colorOption.addEventListener('click', event => {
            event.preventDefault();
            const panel = colorOption.closest('.positions-tabs');
            if (!panel) return;

            panel.querySelectorAll('.color-txt').forEach(c => c.classList.remove('selected'));
            colorOption.classList.add('selected');
            updateAllCanvases();
        });
    });

    // Obsługa przełączania między blokami
    const navTabLinks = document.querySelectorAll('.nav-tab');
    navTabLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const sectionId = this.getAttribute('data-target');

            // Usuń klasę active z wszystkich sekcji i linków
            document.querySelectorAll('.positions-tabs').forEach(section => {
                section.classList.remove('active');
            });
            navTabLinks.forEach(link => {
                link.classList.remove('active');
            });

            // Dodaj klasę active do klikniętej sekcji i linku
            document.getElementById(sectionId).classList.add('active');
            this.classList.add('active');

            // Aktualizuj wszystkie canvasy po przełączeniu bloku
            updateAllCanvases();
        });
    });

    updateAllCanvases(); // Initial update
});
