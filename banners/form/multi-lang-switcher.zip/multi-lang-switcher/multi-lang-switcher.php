<?php
/*
Plugin Name: Multi-lang Domain Switcher
Description: Przełącznik wersji językowych aktualnie przeglądanej strony dla multi-domen na podstawie zdefiniowanych slugów. Konfiguracja w JSON
Version: 1.4
Author: Roman K. ✅ CERKAMED 2025
Text Domain: lang-switcher
*/

if (!defined('ABSPATH')) {
    exit;
}

class MLS_Language_Switcher {
    private $option_name = 'mls_settings';
    private $settings_page_slug = 'mls-settings';
    private $lang_json_file;
    private $default_json_file;

    public function __construct() {
        $this->lang_json_file = plugin_dir_path(__FILE__) . 'languages.json';
        $this->default_json_file = plugin_dir_path(__FILE__) . 'default.json';

        add_action('admin_menu', [$this, 'add_settings_page']);
        add_action('admin_init', [$this, 'register_settings']);
        add_shortcode('multi_lang_switcher', [$this, 'render_language_switcher']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
    }

    public function enqueue_styles() {
        wp_enqueue_style('mls_styles', plugin_dir_url(__FILE__) . 'css/multi-lang-switcher.css', [], '1.0.0');
    }

    public function add_settings_page() {
        add_options_page(__('Language Switcher Settings', 'lang-switcher'), __('Multi-Lang Domain', 'lang-switcher'), 'manage_options', $this->settings_page_slug, [$this, 'settings_page_html']);
    }

    public function register_settings() {
        register_setting($this->option_name, $this->option_name, [$this, 'sanitize_settings']);
        add_settings_section('mls_main_section', __('Ustawienia podstawowe:', 'lang-switcher'), null, $this->settings_page_slug);
        add_settings_field('domains', __('Konfiguracja [JSON]', 'lang-switcher'), [$this, 'domains_field_html'], $this->settings_page_slug, 'mls_main_section');
    }

    public function sanitize_settings($input) {
        if (!empty($input['domains'])) {
            $decoded = json_decode($input['domains'], true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                add_settings_error($this->option_name, 'json_error', __('Niepoprawny format JSON.', 'lang-switcher'), 'error');
                return get_option($this->option_name) ?: [];
            }
            $this->save_languages_config($decoded);
        }
        return $input;
    }

    public function settings_page_html() {
        ?>
        <div class="wrap">
            <h1><?php esc_html_e('Ustawienia Multi-lang switcher', 'lang-switcher'); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields($this->option_name);
                do_settings_sections($this->settings_page_slug);
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    public function domains_field_html() {
        $data = $this->load_languages_config();
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        ?>
        <textarea name="<?php echo esc_attr($this->option_name); ?>[domains]" rows="20" style="width:100%; font-family: monospace;"><?php echo esc_textarea($json); ?></textarea>
        <p class="description">1. <?php esc_html_e('Wprowadź konfigurację językową w formacie JSON => 🎯 Ukośniki / na początku i na końcu /', 'lang-switcher'); ?></p>
        <p class="description">2. <?php esc_html_e('Wgraj odpowiednie pliki flag do folderzu [WP] => Media', 'lang-switcher'); ?></p>
        <p class="description">3. <?php esc_html_e('Przykład użycia:', 'lang-switcher'); ?></p>
        <div style="margin-top:1em; background:#f8f8f8; border:1px solid #ddd; padding:10px;">
            <pre style="margin:0; background:#f7f7f7; padding:.5em;">
                1. [header.php] => shortcode => [multi_lang_switcher]
                ====================================================
                ...
                if (function_exists('do_shortcode')) {
                    echo do_shortcode('[multi_lang_switcher]');
                }
                ...

                2. [header.php] => render_language_switcher()
                =====================================================
                ...
                if (class_exists('MLS_Language_Switcher')) {
                    $mls = new MLS_Language_Switcher();
                    echo $mls->render_language_switcher();
                }
                ...
            </pre>
        </div>
        <?php
    }

    private function load_languages_config() {
        $json = file_exists($this->lang_json_file) ? file_get_contents($this->lang_json_file) : (file_exists($this->default_json_file) ? file_get_contents($this->default_json_file) : '{}');
        $data = json_decode($json, true);
        return json_last_error() === JSON_ERROR_NONE ? $data : [];
    }

    private function save_languages_config($data) {
        $json_data = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
        if (is_writable(dirname($this->lang_json_file)) || (file_exists($this->lang_json_file) && is_writable($this->lang_json_file))) {
            file_put_contents($this->lang_json_file, $json_data);
        } else {
            add_settings_error($this->option_name, 'file_write_error', __('Nie można zapisać pliku JSON. Sprawdź uprawnienia katalogu.', 'lang-switcher'), 'error');
        }
    }

    private function get_current_lang_config() {
        $config = $this->load_languages_config();
        $host = $_SERVER['HTTP_HOST'] ?? '';
        foreach ($config as $lang_code => $lang_data) {
            if (!empty($lang_data['domain']) && strpos($host, $lang_data['domain']) !== false) {
                return [$lang_code, $lang_data];
            }
        }
        return [null, null];
    }

    // Generuj URL przełącznika języka
    public function get_lang_switch_url($target_lang) {
        list($current_lang, $current_config) = $this->get_current_lang_config();
        $slug_map = $this->load_languages_config();
    
        if (!$current_config || empty($slug_map[$target_lang])) return '#';
        $target_config = $slug_map[$target_lang];
    
        $current_url = $_SERVER['REQUEST_URI'] ?? '/';
        $parsed_url = parse_url($current_url);
        $current_path = $parsed_url['path'] ?? '/';
        $current_path = rtrim($current_path, '/') . '/'; // Upewnij się, że kończy się na /
    
        // Znajdź odpowiadający klucz
        $current_slug_key = array_search($current_path, $slug_map[$current_lang]['slug']);
        if ($current_slug_key && isset($slug_map[$target_lang]['slug'][$current_slug_key])) {
            $target_slug = $slug_map[$target_lang]['slug'][$current_slug_key];
            return 'https://' . $target_config['domain'] . $target_slug;
        }
    
        // Jeśli nie znaleziono odpowiadającego slugu, kieruj na stronę główną języka
        return 'https://' . $target_config['domain'] . '/';
    }
    

    public function render_language_switcher() {
        $config = $this->load_languages_config();
        list($current_lang, $current_config) = $this->get_current_lang_config();
        if (!$current_config) return '';
    
        $uploads = wp_upload_dir(); // Biblioteka Media

        $output = '<div class="multi-lang-switcher">';
        foreach ($config as $lang_code => $lang_data) {
    
            // Pomiń flagę dla bieżącego języka/domeny
            if ($lang_code === $current_lang) continue;
    
            $url = $this->get_lang_switch_url($lang_code);
            $flag_url = esc_url(trailingslashit($uploads['baseurl']) . $lang_data['flag']);
            $alt = esc_attr($lang_data['name']);
            $output .= sprintf(
                '<a href="%s"><img src="%s" width="20" height="12" alt="%s" /></a> ',
                esc_url($url),
                $flag_url,
                $alt
            );
        }
        $output .= '</div>';
        return $output;
    }
    
}

new MLS_Language_Switcher();
