<?php
session_start();
require_once 'functions.php';

if (!isset($_POST['token']) || $_POST['token'] !== $_SESSION['csrf_token']) {
    echo json_encode(['status' => 'error', 'message' => 'Błędny token!']);
    logError('Błędny token', 'error_token');
    exit;
}

// Pobranie danych SVG z DIV
$svgContent = isset($_POST['svg']) ? $_POST['svg'] : null;
if (!$svgContent) {
    echo json_encode(['status' => 'error', 'message' => 'Brak danych SVG!']);
    logError('Brak danych SVG! w getSVGContent() JS', 'error_svg_content');
    exit;
}


if (!isset($_POST['generate'])) {
    logError('Brak parametru generate=... w URL', 'error_generate');
    echo json_encode(['status' => 'error', 'message' => 'Brak parametru generate!']);
    exit;
}

$generateType = trim(htmlspecialchars($_POST['generate']));

switch ($generateType) {
    case 'pdf':
        generatePDF($svgContent, $generateType);
        break;

    case 'jpeg':
        generateImage($svgContent, $generateType);
        break;

    default:
        logError("Nierozpoznany typ generowania pliku: $generateType", 'error_generate_type');
        echo json_encode(['status' => 'error', 'message' => 'Nierozpoznany typ generowania pliku!']);
        exit;
}



// Funkcja generująca PDF
function generatePDF($svgContent, $generateType) {
    require_once('tcpdf/tcpdf.php'); // Załaduj bibliotekę TCPDF

    // Ścieżki do folderów
    $uploadsDir = __DIR__ . '/../uploads';
    $pdfDir = $uploadsDir . '/' . $generateType;

    // Tworzenie katalogów, jeśli nie istnieją
    if (!is_dir($uploadsDir)) {
        if (!mkdir($uploadsDir, 0777, true)) {
            logError('Nie można utworzyć katalogu: ' . $uploadsDir, 'error_folder');
            die(json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $uploadsDir]));
        }
    }

    if (!is_dir($pdfDir)) {
        if (!mkdir($pdfDir, 0777, true)) {
            logError('Nie można utworzyć katalogu: ' . $pdfDir, 'error_folder');
            die(json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $pdfDir]));
        }
    }

    // Tworzenie nowego PDF
    $pdf = new TCPDF();
    $pdf->AddPage();

    // Dodanie nagłówka z logo
    $pdf->setImageScale(300 / 72); // TCPDF domyślnie używa 72 DPI
    $logoPath = '../img/hussaria_electra_logo_black.png'; // Ścieżka do pliku z logo
    if (file_exists($logoPath)) {
        // Usuwamy szerokość i wysokość, aby użyć oryginalnych rozmiarów obrazu
        $pdf->Image($logoPath, 10, 5, 0, 0); // x=15, y=5, szerokość=0, wysokość=0 (aby nie zmieniać oryginalnych wymiarów)
    }

    // Dodanie daty generowania w nagłówku (na końcu wiersza)
    $currentDate = date('Y-m-d H:i:s'); // Data i godzina generowania PDF
    $pdf->SetXY(150, 0); // Ustawienie współrzędnych X i Y dla daty (na końcu wiersza)
    $pdf->SetFont('helvetica', 'I', 7); // Czcionka kursywa, rozmiar 8
    $pdf->Cell(0, 10, $currentDate, 0, 0, 'R'); // Tekst w nagłówku (na końcu wiersza)

    $protocol = isset($_SERVER['HTTPS']) && 
    $_SERVER['HTTPS'] === 'on' ? 'https://' : 'http://';
    $base_url = $protocol . $_SERVER['HTTP_HOST'] . '/';


    // Dodanie linku do strony
    $pdf->SetXY(150, 3); // Ustawienie współrzędnych X i Y dla linku
    $pdf->SetFont('helvetica', 'B', 8); // Czcionka zwykła, rozmiar 8
    $pdf->Cell(0, 10, $base_url, 0, 0, 'R'); // Link do strony (na końcu wiersza)

    // Ścieżka zapisu tymczasowego pliku SVG
    $svgFilePath = $pdfDir . '/temp_' . uniqid() . '.svg';

    // Zapisujemy SVG do pliku tymczasowego
    if (file_put_contents($svgFilePath, $svgContent) === false) {
        logError('Nie udało się zapisać pliku SVG: ' . $svgFilePath, 'error_svg');
        die(json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać pliku SVG.']));
    }

    // Dodajemy obrazek SVG do PDF
    $pageWidth = $pdf->getPageWidth(); // Pobierz szerokość strony
    $w = 150; // Szerokość obrazka
    $h = 220; // Wysokość obrazka
    $x = ($pageWidth - $w) / 2; // Wyśrodkowanie obrazka

    $pdf->ImageSVG($file=$svgFilePath, $x, 25, $w, $h, '', '', true, false);


    // Ścieżka zapisu PDF
    $fileName = 'hussaria_electra_' . uniqid() . '.pdf';
    $filePath = $pdfDir . '/' . $fileName;

    // Zapisujemy PDF na serwerze
    $pdf->Output($filePath, 'F'); 

    // Wymuszenie pobrania PDF przez użytkownika
    // $pdf->Output('hussaria_electra.pdf', 'D');
    

    // Usuwanie tymczasowego pliku SVG
    unlink($svgFilePath);

    // Sprawdzenie, czy plik został zapisany
    if (!file_exists($filePath)) {
        logError('Nie udało się zapisać PDF! Sprawdź uprawnienia folderu.', 'error_pdf');
        die(json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać PDF!']));
    }

    // Wyślij JSON z linkiem do pobrania
    header('Content-Type: application/json');
    echo json_encode(['status' => 'success', 'file_url' => 'http://localhost/Form_4/uploads/pdf/' . $fileName]);
    exit;
}





// Funkcja generująca obraz
function generateImage($svgContent, $generateType, $width = 300, $format = 'jpeg') {
    // Sprawdzenie, czy Imagick jest dostępny
    if (!class_exists('Imagick')) {
        logError('Biblioteka Imagick nie jest dostępna!', 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Biblioteka Imagick nie jest dostępna!']);
        exit;
    }

    // Ścieżki do folderów
    $uploadsDir = '../downloads';
    $imgDir = $uploadsDir . '/' . $generateType;

    // Tworzenie katalogów, jeśli nie istnieją
    if (!file_exists($uploadsDir) && !mkdir($uploadsDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $uploadsDir, 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $uploadsDir]);
        exit;
    }

    if (!file_exists($imgDir) && !mkdir($imgDir, 0777, true)) {
        logError('Nie można utworzyć katalogu: ' . $imgDir, 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Nie można utworzyć katalogu: ' . $imgDir]);
        exit;
    }

    // Ścieżka do pliku wynikowego
    $fileName = 'hussaria_electra_' . time() . '.' . $format;
    $filePath = $imgDir . '/' . $fileName;

    // Tworzenie obrazu za pomocą Imagick
    try {
        $image = new Imagick();
        $image->readImageBlob($svgContent); // Odczytanie treści SVG

        // Ustawienie rozmiaru obrazka w pikselach, jeśli podano
        if ($width !== null) {
            $image->resizeImage($width, null, Imagick::FILTER_LANCZOS, 1);
        }

        // Ustawienie jakości kompresji dla formatu JPEG
        $image->setImageCompressionQuality(90);

        // Zastosowanie maski rozmycia, aby poprawić ostrość
        $image->unsharpMaskImage(0, 0.5, 1, 0.05);

        $image->setImageFormat($format); // Ustawienie formatu
        $image->writeImage($filePath); // Zapisanie pliku
        $image->clear();
        $image->destroy();
    } catch (Exception $e) {
        logError('Błąd przy generowaniu obrazu: ' . $e->getMessage(), 'error_generate_image');
        echo json_encode(['status' => 'error', 'message' => 'Błąd generowania obrazu: ' . $e->getMessage()]);
        exit;
    }

    // Sprawdzenie, czy plik został zapisany
    if (!file_exists($filePath)) {
        logError('Nie udało się zapisać obrazu! ' . $e->getMessage(), 'error_generate_save');
        echo json_encode(['status' => 'error', 'message' => 'Nie udało się zapisać obrazu!']);
        exit;
    }

    // Generowanie URL do pliku
    $baseUrl = '/order_v4/downloads/' . $generateType . '/';
    $fileUrl = $baseUrl . $fileName;

    // Zwrócenie poprawnej odpowiedzi JSON
    echo json_encode(['status' => 'success', 'file_url' => $fileUrl]);
    exit;
}


?>
