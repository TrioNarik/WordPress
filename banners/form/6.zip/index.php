<?php

require_once 'include/init.php';
require_once 'include/functions.php';

// Ustawienie języka na podstawie GET lub sesji
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

$lang = $_SESSION['lang'] ?? 'pl';

// Pobranie pliku tłumaczeń
$lang_file = "lang/$lang.php";
$translate = safeInclude($lang_file);

// Pobranie konfiguracji języków
$config_lang_file = 'config/languages.php';
$config_lang = safeInclude($config_lang_file);
$languages = $config_lang['languages'] ?? [];

// Pobranie konfiguracji administratora
$config_file = 'config/admin.php';
$config = safeInclude($config_file);


// Wesje plików do Download
$downloads = loadJsonFile('downloads.json', [
    ['name' => ['en' => 'Download HTML file'], 'version' => 'HTML', 'svg' => 'downloads.svg']
]);
// Kolory PAKI
$PACKcolors = loadJsonFile('colors.json', [
    ['name' => ['en' => 'Black'], 'color' => '#131516', 'ral' => 'RAL 9005']
]);
// Kolory tekstu
$font_colors = loadJsonFile('font-colors.json', [
    ['name' => ['en' => 'Black'], 'color' => '#131516', 'ral' => 'RAL 9005']
]);
// Położenie i Wyrównanie tekstu
$text_positions = loadJsonFile('text-positions.json', [
    ['name' => ['en' => 'Align left'], 'alignment' => 'left', 'panel' => 'top']
]);
// Rozmiar tekstu
$sizes = loadJsonFile('font-sizes.json', [
    ['name' => ['en' => 'Normal'], 'size' => '5', 'panel' => 'top']
]);
// Formatowanie tekstu
$styles = loadJsonFile('font-styles.json', [
    ['name' => ['en' => 'Bold'], 'style' => 'bold']
]);
// Czcionki
$fonts = loadJsonFile('fonts.json', [
    ['name' => 'Arial', 'rating' => 4, 'badge' => 'top', 'fontFamily' => 'Arial']
]);





// ==========================================
// Funkcja do wyświetlania elementów Pakietu
// ==========================================
function displayIncludePack($items) {
    foreach ($items as $itemKey => $item) {
        if ($item['active']) {
            echo '<div class="d-flex justify-content-evenly align-items-center gap-2 my-1 my-md-3">';
            echo '<input type="checkbox" id="' . $itemKey .'" name="' . $itemKey .' " checked="checked" disable>';
            echo '<label for="' . $itemKey .'">';
            echo $item['name'];
            echo '</label>';
            if (!empty($item['image'])) {
                $imagePath = 'img/' . $item['image'];
                $versionedImagePath = version($imagePath);
                echo '<div class="include">';
                echo '<img class="img-fluid" src="'. htmlspecialchars($versionedImagePath) .'" alt="' . $item['name'] .'" />';
                echo '</div>';
            }

            echo '</div>';
        }
    }
}


function displayProductCheckbox($items, $currency, $button) {
    echo '<div class="row">';
    foreach ($items as $itemKey => $item) {
        if ($item) {

            echo '<div class="col-12 col-md-4">';

                echo '<div class="featured m-2 p-2 p-md-4">';
                
                if (!empty($item['image'])) {

                    $imagePath = 'img/' . $item['image'];
                    $versionedImagePath = version($imagePath);

                    echo '<div class="image d-flex justify-content-center align-items-center text-center my-md-3">';

                    echo '<img class="img-fluid" src="' . htmlspecialchars($versionedImagePath) . '" alt="' . htmlspecialchars($item['name']) . '">';
                    echo '</div>';
                }

                    echo '<h6 class="text-center">'. $item['name'].'</h6>';
                    echo '<div class="parameters d-flex justify-content-between align-items-center gap-3 py-2 my-2 my-md-4">';
                        echo '<span class="text-center">'. $item['parameters']['name'].'</span>';
                        echo '<span class="text-center">'. $item['parameters']['value'].'</span>';
                    echo '</div>';

                    echo '<div class="d-flex justify-content-between align-items-center">';
                        if ($item['show_price']) {
                            
                                echo '<div id="item_'. $itemKey .'" class="col-6 col-md-5 product-price">';
                                    echo '<div class="block-price text-center p-2">';
                                        echo '<span>'. formatPriceWithSup($item['price']) .'</span> ';
                                        echo '<span>'. $currency .'</span>';
                                    echo '</div>';
                                echo '</div>';

                                if ($item['shipping']['active']) {
                                echo '<div id="'. $itemKey .'" class="col-6 col-md-7">';
                                    echo '<div class="block-shipping text-end p-2">';
                                        echo '<span>'. $item['shipping']['content'] .' '. formatPriceWithSup($item['shipping']['price']) .'</span>';
                                    echo '</div>';
                                echo '</div>';
                                }
                            
                        }

                        echo '<div class="d-flex justify-content-start align-items-center gap-4">';
                        if ($item['active']) {
                            echo '<button type="button" id="' . htmlspecialchars($itemKey) . '" class="btn btn-warning cart" data-button-action="add-to-cart" data-name="'. htmlspecialchars($item['name']) .'" data-price="'. $item['price'] .'" data-shipping="'. $item['shipping']['price'] .'">';
                            echo svg_code('cart.svg');
                            echo '</button>';
                        } else {
                            echo '<button type="button" class="btn btn-outline-light disabled cart">';
                            echo svg_code('cart.svg');
                            echo '</button>';
                        }
                        echo '</div>';
                
                    echo '</div>';

            echo '</div>';
            echo '</div>';

        }
    }
    echo '</div>';
}

?>
<!DOCTYPE html>
<html lang="pl" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $translate['title'] ?></title>
    <link rel="icon" href="img/hussaria-electra-100x100.png" sizes="32x32">
    
    <meta name="description" content="✔ Hussaria Electra">
    <meta name="keywords" content="hussaria electra, elektryczna paka, ">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">

    <meta property="og:title" content="<?php echo $translate['title'] ?>">
    <meta property="og:description" content="...">
    <meta property="og:image" content="https://electra.hussaria.pl/order_v2/img/elektryczna_paka.jpg">
    <meta property="og:image:type" content="image/jpeg">
    <meta property="og:image:width" content="500">
    <meta property="og:image:height" content="500">
    <meta property="og:image:alt" content="><?php echo $translate['title'] ?>">
    <meta property="og:url" content="https://electra.hussaria.pl/order/">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Fonts USED -->
    <link rel="stylesheet" href="https://use.typekit.net/vfx4swx.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo version('css/style.css') ?>">
</head>
<body>
    <header class="container-fluid fixed-top py-1">
        <div class="row">
            <!-- LOGO -->
            <div class="col-12 order-sm-1 col-md-3 order-md-1 d-flex align-items-center justify-content-between justify-content-md-start gap-3">
                <div class="logo-wrapper">
                    <a href="./"><img id="logo" class="logo" src="<?php echo version('img/hussaria_electra_logo_white.png') ?>" alt="<?php echo $translate['title'] ?>"></a>
                </div>
                <div class="info px-2">
                    <div class="contact d-flex align-items-center justify-content-start gap-1">
                        <?php 
                            echo svg_code('phone.svg');
                            echo "<span>" . $config['admin']['office_phone'] ."</span>";
                        ?>
                    </div>
                    <!-- Hide/OFF -->
                    <div class="hot d-none align-items-center justify-content-start gap-1">
                        <span>Gotowe do wysyłki: <a href="?controler=get&utm_source=he&utm_medium=link&utm_campaign=topbar&utm_term=hot&&lang=<?php echo $lang ?>&cid=<?php echo $cid ?>">Konfiguracja #05</a></span>
                    </div>
                </div>
            </div>
            <!-- end -->

            <!-- Delivery -->
            <div class="col-12 order-sm-3 col-md-6 order-md-2 d-flex align-items-center justify-content-between delivery position-relative my-1 py-3">
                <div class="d-flex align-items-center justify-content-start gap-3">
                    <div class="delivery__content align-items-center justify-content-between gap-2">
                        <div class="delivery__content__headline"><?php echo $translate['package']['shipping']['content'] ?></div>
                        <div class="delivery__content__subheadline text-center px-2"><?php echo $translate['package']['shipping']['info'] ?></div>
                    </div>
                    <div class="delivery__logo position-absolute bottom-0 end-0 p-2">
                        <img id="he_icon" src="img/he_icon_white.png" alt="<?php echo $translate['title'] ?>">
                    </div>
                </div>
            </div>
            <!-- end -->

            <!-- Navigation -->
            <div class="col-12 order-sm-2 col-md-3 order-md-3 d-flex align-items-center justify-content-around justify-content-md-end gap-3">
                <!-- Download -->
                <div class="download mx-1">
                    <ul class="d-flex align-items-center justify-content-start gap-1">
                        <?php
                        foreach ($downloads as $download) {
                            echo '<li data-bs-toggle="tooltip" data-bs-placement="bottom" title="'. $download['name'][$lang] .'">';
                            echo '<a class="d-flex justify-content-between align-items-center gap-2" data-version="'. $download['version'] .'" href="?controler=downloads&create=' .$download['link'] .'&token='. $_SESSION['csrf_token'] .'">';
                            echo '<span class="icon">';
                            echo svg_code($download['svg']);
                            echo '</span>';
                            echo '<span>' . $download['version'] . '</span>';
                            echo '</a></li>';
                        } ?>
                    </ul>
                </div>
                <!-- end -->

                <!-- Cart -->
                <div class="cart">
                    <button type="button" id="cart" class="btn btn-warning position-relative" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight" title="<?php echo $translate['form']['buttons']['view'] ?>">
                        <span>
                            <?php echo svg_code('cart.svg')?>
                            <sup id="cart_items" class="position-absolute top-0 start-100 translate-middle badge border border-light rounded-circle bg-danger"></sup>
                        </span>
                    </button>
                </div>
                <!-- end -->

                <!-- Languages -->
                 <nav>
                    <ul class="d-flex justify-content-end align-items-center gap-1 m-x-1">
                        <?php foreach ($languages as $code => $langData): ?>
                            <li class="nav-item<?= ($lang == $code) ? ' active' : '' ?>">
                                <?php if ($lang != $code): ?>
                                    <a class="nav-link" href="?lang=<?= $code ?>">
                                <?php endif; ?>
                                    <img src="img/<?= $langData['img'] ?>" alt="<?= $langData['name'] ?>"  data-bs-toggle="tooltip" data-bs-placement="bottom" title="<?= $langData['name'] ?>">
                                <?php if ($lang != $code): ?>
                                    </a>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; ?>
                        <li class="mx-3" data-bs-toggle="tooltip" data-bs-placement="bottom" title="" data-bs-original-title="Zmień motyw">
                                
                            </li>
                    </ul>
                 </nav>
                
                <button id="toggleTheme" type="button" class="btn p-0 border-0 bg-transparent" data-bs-toggle="tooltip" data-bs-placement="left" data-bs-original-title="<?php echo $translate['settings']['theme'] ?>">
                    <img src="<?php echo version('img/brightness.png') ?>" alt="<?php echo $translate['settings']['theme'] ?>">
                </button>


                <!-- end -->
            </div>
            <!-- end -->            
        </div>
    </header>

    <main class="container-fluid">
        <div class="row configurator position-relative">
            <!-- MODEL -->
            <div class="col-12 configurator__model">
                <div id="paka" class="configurator__model__view text-center">
                    <?php updateSVGcodeWithTEXTitems(__DIR__ . '/svg/paka.svg', __DIR__ . '/json/text-positions.json'); ?>
                </div>
            </div>

            <!-- OPTIONS -->
            <div class="col-12 col-md-3 configurator__panel position-absolute z-1">
                <div class="configurator__panel__options p-1 p-md-3 my-1 my-md-3">
                    <!-- COLORS PACK -->
                        <section class="pack-colors d-flex align-items-center justify-content-between">
                            <div class="options_label">
                                <div class="d-flex align-items-center justify-content-start gap-3">
                                    <div class="icons">
                                        <?php echo svg_code('palette.svg') ?>
                                    </div>
                                    <div class="option">
                                        <h4 class="fs-6"><?php echo $translate['form']['colors']['fields']['label'] ?>:</h4>
                                        <span class="help"><?php echo $translate['form']['colors']['fields']['help'] ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="dropdown">
                                <button class="btn btn-colors d-flex align-items-center dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <span id="selectedColorPack" class="color-box me-1"></span>
                                </button>
                            
                                <ul class="dropdown-menu px-2" id="packColor">
                                    <?php
                                    foreach ($PACKcolors as $color) {
                                        echo '<li>';
                                        echo '<a  style="background-color: ' . $color['color'] . ';" data-color="'. $color['color'] .'" data-ral="'. $color['ral'] .'" href="#" data-toggle="tooltip" data-placement="top" title="'. $color['name'][$lang] .' - '. $color['ral'] .'"></a></li>';
                                    } ?>
                                </ul>
                            </div>
                        </section>
                    <!-- end -->
                </div>

                <div class="configurator__panel__options p-1 p-md-3 my-1 my-md-3">
                    <!-- BROKAT PACK -->
                    <section class="pack-colors d-flex align-items-center justify-content-between">
                            <div class="options_label">
                                <div class="d-flex align-items-center justify-content-start gap-3">
                                    <div class="icons">
                                        <?php echo svg_code('glitter.svg') ?>
                                    </div>
                                    <div class="option">
                                        <h4 class="fs-6"><?php echo $translate['form']['glitter']['fields']['label'] ?>:</h4>
                                    </div>
                                </div>                                
                            </div>

                            <div class="glitter">
                                <input type="checkbox" id="glitter" class="d-none">
                                <label for="glitter" class="switch"><span></span></label>   
                            </div>
                        </section>
                    <!-- end -->
                </div>

                <div class="configurator__panel__options p-1 p-md-3 my-1 my-md-3">
                    <!-- TEXT CUSTOMIZATION -->
                        <section class="customization">
                            <div class="options_label">
                                <div class="d-flex align-items-start justify-content-between gap-3">
                                    <div class="d-flex align-items-center justify-content-start gap-3">
                                        <div class="icons">
                                            <?php echo svg_code('person.svg') ?>
                                        </div>
                                        <div class="option">
                                            <h4 class="fs-6"><?php echo $translate['form']['marker']['fields']['label'] ?>:</h4>
                                            <span class="help"><?php echo $translate['form']['marker']['fields']['help'] ?>:</span>
                                        </div>
                                    </div>
                                    <div class="text-positions">
                                        <ul class="d-flex align-items-center justify-content-end gap-1">
                                            <?php
                                                foreach ($text_positions as $key => $value) {
                                                    foreach ($value as $item) {
                                                        echo '<li><a href="#'. $key .'" class="nav-tab" data-target="'. $key .'">' . $item['title'][$lang] . "</a></li>";
                                                    }
                                                }
                                            ?>
                                        </ul>
                                    </div>
                                </div>       
                            </div>

                            <!-- Personalization -->
                            <?php 
                                foreach ($text_positions as $key => $value) {
                                    echo '<div id="'. $key .'" class="positions-tabs">';
                                        // Text Input
                                        echo '<div class="form-group my-2 settings">';
                                            echo '<div class="input-group">';
                                                echo '<span class="input-group-text">';
                                                foreach ($value as $item) {
                                                    echo svg_code($item['icon']);
                                                }
                                                echo '</span>';
                                                echo '<input type="text" class="form-control" id="text_'. $key .'" placeholder="'. $translate['form']['marker']['fields']['holder'] .'..." maxlength="25">';
                                            echo '</div>';
                                        echo '</div>';
                                        
                                        // Text Color
                                        echo '<div class="d-flex align-items-center justify-content-between settings py-1">';
                                        echo '<div class="fs-6">';
                                        echo ''. $translate['form']['marker']['tools']['font-color'] .':';
                                        echo '</div>';

                                        echo '<div class="dropdown">';
                                            echo '<button class="btn btn-colors d-flex align-items-center dropdown-toggle" type="button" data-bs-toggle="dropdown">';
                                                echo '<span id="selectedColorText_'. $key .'" class="color-box me-2"></span>';
                                            echo '</button>';

                                            echo '<ul class="colors dropdown-menu p-0" id="textColor_'. $key .'">';
                                                    foreach ($font_colors as $color) {
                                                        echo '<li style="background-color: ' . $color['color'] . ';">';
                                                        echo '<a class="dropdown-item d-flex align-items-center justify-content-between p-3 color-txt" data-color="'. $color['color'] .'" data-ral="'. $color['ral'] .'" href="#">';
                                                        echo '<span>' . $color['name'][$lang] . '</span>';
                                                        echo '<span class="ral">' . $color['ral'] . '</span>';
                                                        echo '</a></li>';
                                                    }
                                            echo '</ul>';
                                        echo '</div>';
                                        echo '</div>';

                                        // Text Align
                                        echo '<div class="d-flex align-items-center justify-content-between settings py-1">';
                                            echo '<div class="fs-6">';
                                                echo ''. $translate['form']['marker']['tools']['font-align'] .':';
                                            echo '</div>';
                                    
                                            echo '<ul class="d-flex tools justify-content-start align-items-center gap-3" id="textAlignt_'. $key .'">';

                                                foreach ($value as $item) {
                                                    foreach ($item['align'] as $alignName => $alignData) {
                                                        echo '<li><button type="button" class="tools" data-x="'. $alignData['x'] .'" data-y="'. $alignData['y'] .'" data-anchor="'. $alignData['anchor'] .'" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'. $alignData['name'][$lang] .'">';
                                                        echo svg_code($alignData['svg']);
                                                        echo '</button>';
                                                    }
                                                }
                                            echo '</ul>';
                                        echo '</div>';


                                        // Text Size
                                        echo '<div class="d-flex align-items-center justify-content-between settings py-1">';
                                            echo '<div class="fs-6">';
                                                echo ''. $translate['form']['marker']['tools']['font-size'] .':';
                                            echo '</div>';
                                            echo '<ul class="d-flex tools justify-content-start align-items-center gap-3" id="textSize_'. $key .'">';
                                                foreach ($sizes as $size) {
                                                    echo '<li><button type="button" data-size="'. $size['size'] .'" class="tools" data-bs-toggle="tooltip" data-bs-placement="bottom" title="'. $size['name'][$lang] .'">';
                                                    echo svg_code($size['svg']);
                                                    echo '</button>';
                                                }
                                            echo '</ul>';
                                        echo '</div>';

                                        // Text Style
                                        echo '<div class="d-flex align-items-center justify-content-between settings py-1">';
                                            echo '<div class="fs-6">';
                                                echo ''. $translate['form']['marker']['tools']['font-style'] .':';
                                            echo '</div>';
                                            echo '<ul class="d-flex tools justify-content-start align-items-center gap-3" id="textStyle_'. $key .'">';
                                                foreach ($styles as $style) {
                                                    echo '<li><button type="button" data-style="'. $style['style'] .'" class="tools" data-bs-toggle="tooltip" data-bs-placement="top" title="'. $style['name'][$lang] .'">';
                                                    echo svg_code($style['svg']);
                                                    echo '</button>';
                                                }
                                            echo '</ul>';
                                        echo '</div>';

                                        // Text Fonts
                                        echo '<div class="d-flex align-items-start justify-content-start flex-column settings p-1">';
                                            echo '<div class="fs-6">';
                                                echo ''. $translate['form']['marker']['tools']['font-family'] .':';
                                            echo '</div>';
                                            echo '<ul class="scrollable-list rounded" id="fontFamily_'. $key .'">';
                                                    foreach ($fonts as $index => $font) {
                                                        echo '<li><canvas id="canvasfont_'.$index.'_'. $key .'" 
                                                        data-font="1.25em ' . htmlspecialchars($font['fontFamily']) . ', sans-serif"
                                                        data-family="' . htmlspecialchars($font['fontFamily']) . '"
                                                        data-name="' . htmlspecialchars($font["name"]) . '"
                                                        data-rating="' . htmlspecialchars($font["rating"]) . '"
                                                        data-badge="' . htmlspecialchars($font["badge"]) . '">
                                                        </canvas></li>';
                                                    }
                                            echo '</ul>';
                                        echo '</div>';

                                    echo '</div>';
                                    
                                }
                            ?>   
                            <!-- end  -->                            
                        </section>
                    <!-- end -->
                </div>

                <div class="configurator__panel__options p-1 p-md-3 my-1 my-md-3">
                    <!-- FLAGS -->
                    <section class="flags d-flex align-items-center justify-content-between">
                            <div class="options_label">
                                <div class="d-flex align-items-center justify-content-start gap-3">
                                    <div class="icons">
                                        <?php echo svg_code('flag.svg') ?>
                                    </div>
                                    <div class="option">
                                        <h4 class="fs-6"> <?php echo $translate['form']['marker']['flag']['fields']['label'] ?>:</h4>
                                    </div>
                                </div>                                
                            </div>

                            <div class="input-group w-50 d-none" id="flagInputGroup">
                                <span class="input-group-text">
                                    <?php echo '<img src="'.$_SESSION['flagUrl'].'" alt="'. $_SESSION['country'] .'">' ?>
                                </span>
                                <input type="text" class="form-control" id="country" placeholder="<?php echo $translate['form']['marker']['flag']['fields']['holder'] ?>..." value="<?php echo $_SESSION['country'] ?>" maxlength="10">
                            </div>

                            <div class="checkbox">
                                <input type="checkbox" id="flag" class="d-none">
                                <label for="flag" class="switch"><span></span></label>   
                            </div>
                        </section>
                    <!-- end -->
                </div>

                
                <!-- SAVE BUTTON -->
                <div class="my-2">
                    <button class="btn btn-warning" id="save-config" type="button" data-pack-name="<?php echo $translate['package']['name'] ?>" data-pack-price="<?php echo $translate['package']['price'] ?>" data-pack-promo="<?php echo $translate['package']['promo'] ?>" data-pack-delivery="<?php echo $translate['package']['shipping']['price'] ?>" data-pack-delivery-promo="<?php echo $translate['package']['shipping']['promo'] ?>" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><?php echo $translate['form']['buttons']['save'] ?></button>
                </div>
                <!-- end -->
            </div>
        </div>

    </main>

    <footer>
        <section class="container-fluid py-3 py-md-5">
            <div class="container">
            <h4><?php echo $translate['extra'] ?>:</h4>
            <div class="d-flex justify-content-center align-items-center gap-3">
                <?php displayProductCheckbox($translate['products'], $translate['settings']['currency'], $translate['form']['buttons']['add']) ;?>
            </div>
            </div>
        </section>
        <div class="copyright text-center py-3">
            © Copyright 2025
        </div>
    </footer>

    
    <section class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
        <div class="offcanvas-header">
            <h5 id="offcanvasRightLabel"><?php echo $translate['header'] ?></h5>
            <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
            <!-- BODY -->
            <div class="cart">
                <h4 class="fs-6"><?php echo $translate['form']['buttons']['cart'] ?></h4>
                <div class="d-flex align-items-center justify-content-between gap-3">
                    <div class="img">
                        <img src="img/paka_cart.png" alt="HE">
                    </div>
                    <div class="name">
                        <?php echo $translate['package']['name'] ?>
                    </div>
                    <div class="price">
                        <?php echo $translate['package']['price'] ?>
                        <span><?php echo $translate['settings']['currency'] ?></span>
                    </div>
                </div>

            </div>
            <div class="cart_promo p-2" id="cart_promo_items"></div>
            
            <div class="cart_form my-1 p-2">
                <h4 class="fs-6"><?php echo $translate['form']['person']['title'] ?></h4>
            
                <div class="form-group">
                    <label for="name"><?php echo $translate['form']['person']['fields']['first_name'] ?>:</label>
                    <input type="text" id="name" class="form-control" name="name" autocomplete="off" required>
                </div> 
                <div class="form-group">
                    <label for="company"><?php echo $translate['form']['person']['fields']['last_name'] ?>:</label>
                    <input type="text" id="company" class="form-control" name="company" autocomplete="off" required>
                </div>
                <div class="form-group">
                    <label for="email"><?php echo $translate['form']['person']['fields']['email'] ?>:</label>
                    <input type="text" id="email" class="form-control" name="email" autocomplete="off" minlength="3" maxlength="64" required>
                </div>
                <div class="form-group">
                    <label for="phone"><?php echo $translate['form']['person']['fields']['phone'] ?>:</label>
                    <input type="text" id="phone" class="form-control" name="phone" autocomplete="off">
                </div>

                <div class="d-flex gap-3 align-items-center">
                            
                    <label for="accept">
                        <input type="checkbox" id="accept" name="accept">       
                    </label>
                    <span class="d-block"><sup>*</sup><?php echo $translate['form']['order']['accept']['title'] ?> <a href="<?php echo $translate['form']['order']['accept']['link'] ?>"><?php echo $translate['form']['order']['accept']['name'] ?></a>.</span>
                    
                </div>

                <div class="d-flex gap-3 align-items-center">
                    
                    <label for="agree">
                        <input type="checkbox" id="agree" name="agree">       
                    </label>
                    <span class="d-block"><sup>*</sup><?php echo $translate['form']['order']['agree']['title'] ?> <a href="<?php echo $translate['form']['order']['agree']['link'] ?>"><?php echo $translate['form']['order']['agree']['name'] ?></a> <?php echo $translate['form']['order']['agree']['shop'] ?>.</span>
                    
                </div>

            </div>                            
            <div class="submit py-1 text-center">
                <!-- Inputs -->
                <input type="hidden" id="lang" name="lang" value="<?php echo $_SESSION['lang'] ?>"> 
                <input type="hidden" id="human" name="human" value="">
                <!-- end -->

                <button class="btn send" id="send" type="submit"><?php echo $translate['form']['buttons']['submit'] ?></button>
            </div>
        </div>
    </section>
        
    
        
    <!-- Theme Settings -->
    <script src="<?php echo version('js/theme.js'); ?>"></script>
    <!-- Helper -->
    <script src="<?php echo version('js/functions.js'); ?>"></script>
    <!-- Corol Pack -->
    <script src="<?php echo version('js/color_pack.js'); ?>"></script>
    <!-- Text Format -->
    <script src="<?php echo version('js/personal_text.js'); ?>"></script>
    <!-- Text Font -->
    <script src="<?php echo version('js/fonts_canvas.js'); ?>"></script>
    <!-- Flags -->
    <script src="<?php echo version('js/flags.js'); ?>"></script>


    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

    
<script>
    document.addEventListener("DOMContentLoaded", function () {
    const deliveryElement = document.querySelector('.delivery');
    const deliveryContentElement = deliveryElement.querySelector('.delivery__content');
    
    function updateStylesOnScroll() {
        if (window.scrollY > 50) {
            deliveryElement.classList.remove('py-3');
            deliveryContentElement.classList.add('d-flex');

        } else {
            deliveryElement.classList.add('py-3');
            deliveryContentElement.classList.remove('d-flex');
        }
    }

    window.addEventListener('scroll', updateStylesOnScroll);
});
</script>


    <script>
        // Agree checkbox
        document.addEventListener('DOMContentLoaded', function() {
            const acceptCheckbox = document.getElementById('accept');
            const agreeCheckbox = document.getElementById('agree');
            const sendButton = document.getElementById('send');

            function toggleSendButton() {
                if (acceptCheckbox.checked && agreeCheckbox.checked) {
                    sendButton.disabled = false;
                } else {
                    sendButton.disabled = true;
                }
            }

            acceptCheckbox.addEventListener('change', toggleSendButton);
            agreeCheckbox.addEventListener('change', toggleSendButton);

            // Initial check
            toggleSendButton();
        });
        





function formatPricePL(number) {
    return number.toFixed(2) // Dwa miejsca po przecinku
            .replace('.', ',') // Zamiana kropki na przecinek
            .replace(/\B(?=(\d{3})+(?!\d))/g, ' '); // Spacja jako separator tysięcy
}

  </script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    const cartButtons = document.querySelectorAll('.cart');
    const saveConfigButton = document.getElementById('save-config');
    const cart = [];
    const cartItemsElement = document.getElementById('cart_items');

    cartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const itemKey = this.id;
            const name = this.getAttribute('data-name');
            const price = parseFloat(this.getAttribute('data-price'));
            const shipping = parseFloat(this.getAttribute('data-shipping'));

            // Sprawdź, czy produkt jest już w koszyku
            const existingItem = cart.find(item => item.key === itemKey);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({ key: itemKey, name: name, price: price, shipping: shipping, quantity: 1 });
            }

            // Aktualizuj widok koszyka (np. liczbę produktów, cenę itp.)
            updateCartView();
            updateCartItemsCount();
        });
    });

    saveConfigButton.addEventListener('click', function() {
        // Dodaj produkt do koszyka po wciśnięciu przycisku "Zapisz konfigurację"
        const itemKey = 'config-product'; // Unikalny identyfikator produktu
        const price = 10.00; // Cena produktu
        const shipping = 2.00; // Koszt dostawy produktu

        // Sprawdź, czy produkt jest już w koszyku
        const existingItem = cart.find(item => item.key === itemKey);
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ key: itemKey, price: price, shipping: shipping, quantity: 1 });
        }

        // Aktualizuj widok koszyka (np. liczbę produktów, cenę itp.)
        updateCartView();
        updateCartItemsCount();
    });

    function updateCartView() {
        const cartContainer = document.getElementById('cart_promo_items');
        cartContainer.innerHTML = ''; // Wyczyść aktualny widok koszyka

        let totalPrice = 0;
        let totalShipping = 0;

        cart.forEach(item => {
            const itemTotal = item.price * item.quantity;
            totalPrice += itemTotal;
            totalShipping += item.shipping * item.quantity;

            const itemElement = document.createElement('div');
            itemElement.classList.add('cart-item');
            itemElement.innerHTML = `
                
                <span>${item.name}</span>
                <span>Cena: ${itemTotal.toFixed(2)}</span>
                <span>Dostawa: ${item.shipping.toFixed(2)}</span>
                <span>Ilość: ${item.quantity}</span>
            `;
            cartContainer.appendChild(itemElement);
        });

        const totalElement = document.createElement('div');
        totalElement.classList.add('cart-total');
        totalElement.innerHTML = `
            <span>Suma: ${(totalPrice + totalShipping).toFixed(2)}</span>
        `;
        cartContainer.appendChild(totalElement);
    }

    function updateCartItemsCount() {
        const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
        cartItemsElement.textContent = totalItems;
    }
});

</script>

  




</body>
</html>
