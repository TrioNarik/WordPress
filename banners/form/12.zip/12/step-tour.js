document.addEventListener('DOMContentLoaded', () => {
    // Flagi do kontrolowania, czy używamy localStorage i sessionStorage
    let useSessionStorage = true;
    let useLocalStorage = false;

    // Sprawdzamy, czy przewodnik był już wyświetlony w sessionStorage lub localStorage
    const hasTourBeenShown = useLocalStorage ? localStorage.getItem('HEstepTourShown') : (useSessionStorage ? sessionStorage.getItem('HEstepTourShown') : false);

    // Jeśli przewodnik już był wyświetlony, przerywamy wykonanie skryptu
    if (hasTourBeenShown) {
        return;
    }

    // Pobierz język z atrybutu 'data-lang' w tagu <script>
    const scriptElement = document.querySelector('script[src^="js/step-tour.js"]');
    const language = scriptElement ? scriptElement.getAttribute('data-lang') : 'pl'; // Domyślnie 'pl', jeśli brak

    // Funkcja do wczytania danych z pliku JSON
    function loadStepTours() {
        fetch('json/step-tours.json')
            .then(response => response.json())
            .then(stepTours => {
                console.log('Załadowane dane:', stepTours, 'Używany język:', language);
                renderSteps(stepTours, language);
            })
            .catch(error => console.error('Błąd wczytywania JSON:', error));
    }

    // Funkcja do renderowania kroków w zależności od języka
    function renderSteps(stepTours, language) {
        const headerElement = document.querySelector('header'); // Pobieramy element <header>

        // Iteruj po krokach i twórz elementy HTML dla każdego aktywnego kroku
        Object.keys(stepTours).forEach(stepKey => {
            const step = stepTours[stepKey];

            if (parseInt(step.active) === 1) { // Sprawdzamy, czy step aktywny

                // Tworzymy dynamicznie HTML dla każdego kroku
                const stepElement = document.createElement('div');
                stepElement.classList.add('tour-step');
                stepElement.setAttribute('data-step', stepKey);
                stepElement.setAttribute('data-step-board', step.board);

                // Header w odpowiednim języku
                const header = document.createElement('h2');
                header.innerHTML = step.header[language];
                stepElement.appendChild(header);

                // Text w odpowiednim języku
                const text = document.createElement('p');
                text.innerText = step.text[language];
                stepElement.appendChild(text);

                // Button w odpowiednim języku
                const button = document.createElement('button');
                button.classList.add('btn', 'btn-secondary');
                button.innerText = step.button[language];
                button.onclick = () => (stepKey === Object.keys(stepTours).length) ? endTour() : nextStep();
                stepElement.appendChild(button);

                // Wstawiamy krok bezpośrednio po headerze
                headerElement.parentNode.insertBefore(stepElement, headerElement.nextSibling);
            }
        });

        // Aktywuj pierwszy krok
        const steps = document.querySelectorAll('.tour-step');
        totalSteps = steps.length;  // Ustawiamy liczbę kroków
        showStep(1);
    }

    // Funkcje do obsługi nawigacji (np. nextStep, endTour)
    let currentStep = 1;

    function showStep(step) {
        console.log(`Pokazuję krok: ${step}`);
        
        const steps = document.querySelectorAll('.tour-step');
        steps.forEach(el => el.style.display = 'none');
        
        const stepElement = document.querySelector(`.tour-step[data-step="${step}"]`);
        if (stepElement) stepElement.style.display = 'block';
    }

    function nextStep() {
        if (currentStep < totalSteps) {
            currentStep++;
            updateStep();
        }
    }

    function endTour() {
        document.querySelectorAll('.tour-step').forEach(el => el.style.display = 'none');
        
        if (useLocalStorage) {
            localStorage.setItem('HEstepTourShown', 'true');
        } else if (useSessionStorage) {
            sessionStorage.setItem('HEstepTourShown', 'true');
        }
    }

    function updateStep() {
        showStep(currentStep);
    }

    // Startowanie przewodnika
    loadStepTours();
});
