// Dodaj element HTML nad <svg> na podstawie rozmiarĂłw getSvgPathCoordsAndSize()
function addObjectOverPathSVGforDrag_n_Drop(svg_ID, svgPath_ID, block = 'section', blockClass = 'dropzone', CSSPosition = 'absolute', CSSzIndex = 20) {
    
    const svgSizer = getScreenSizeRatioSVG(svg_ID); // Pobieramy aktualny Rozmiar i Ratio SVG

    if (svgSizer) {
        const { svgWidth, svgHeight, viewBoxWidth, viewBoxHeight, scaleX, scaleY } = svgSizer;

        const coordsPath = getSvgPathCoordsAndSize(svgPath_ID); // Pobieramy wspĂłĹrzÄdne i rozmiary

        if (coordsPath) {
            const { pathX, pathY, pathWidth, pathHeight } = coordsPath;

            // Tworzymy HTML element
            const htmlTag = document.createElement(block);
            htmlTag.classList.add(blockClass);
            htmlTag.id = `${svg_ID}_${svgPath_ID}`;
            htmlTag.style.position = CSSPosition;
            htmlTag.style.zIndex = CSSzIndex;
            htmlTag.style.top = `${pathY * scaleY}px`;
            htmlTag.style.left = `${pathX * scaleX}px`;
            htmlTag.style.width = `${pathWidth * scaleX}px`;
            htmlTag.style.height = `${pathHeight * scaleY}px`;


            // Pobieramy SVG (rodzic elementu path)
            const svgElement = document.getElementById(svg_ID);
            if (svgElement) {
                // Dodajemy nowy element za SVG
                svgElement.parentNode.appendChild(htmlTag);
            } else {
                console.error(`Nie znaleziono elementu SVG o ID "${svg_ID}"`);
            }
        }
    }
}



// ========================================================
// ================ POMOCNICZE ============================
// ========================================================

// Pobierz Size&Ratio dla SVG
function getScreenSizeRatioSVG(svgID) {
    const svg = document.getElementById(svgID);

    if (svg && svg.tagName === 'svg') {
        // Pobranie rzeczywistego rozmiaru na ekranie
        const width = svg.getBoundingClientRect().width;
        const height = svg.getBoundingClientRect().height;

        console.log(`Aktualny rozmiar SVG na ekranie: ${width} x ${height}px`);

        // Pobranie wartoĹci viewBox (definiuje ukĹad wspĂłĹrzÄdnych)
        const viewBox = svg.viewBox.baseVal;
        console.log(`viewBox: x=${viewBox.x}, y=${viewBox.y}, width=${viewBox.width}, height=${viewBox.height}`);

        // Obliczanie wspĂłĹczynnikĂłw skali
        const scaleX = (width / viewBox.width).toFixed(2);
        const scaleY = (height / viewBox.height).toFixed(2);

        console.log(`WspĂłĹczynnik skali dla X: ${scaleX}`);
        console.log(`WspĂłĹczynnik skali dla Y: ${scaleY}`);

        return {
            svgWidth: width,
            svgHeight: height,
            viewBoxWidth: viewBox.width,
            viewBoxHeight: viewBox.height,
            scaleX: parseFloat(scaleX),
            scaleY: parseFloat(scaleY)
        };
    } else {
        console.error(`Element with id "${svgID}" is not SVG`);
        return null;
    }
}


// Pobierz wspĂłĹrzÄdne i rozmiar ĹcieĹźki SVG => <foreignObject> => <DIV>...</DIV>
function getSvgPathCoordsAndSize(pathID) {
    const svgPath = document.getElementById(pathID);
    if (svgPath instanceof SVGPathElement) {
        const bbox = svgPath.getBBox();
        console.log(`ID ${pathID} x:`, bbox.x);
        console.log(`ID ${pathID} y:`, bbox.y);
        console.log(`ID ${pathID} width:`, bbox.width);
        console.log(`ID ${pathID} height:`, bbox.height);

        return {
            pathX: bbox.x,
            pathY: bbox.y,
            pathWidth: bbox.width,
            pathHeight: bbox.height
        };
    } else {
        console.error(`Element with id "${pathID}" is not an SVG path element.`);
        return null;
    }
}


// Zabezpiczenie inputĂłw => Cross Site Injection
function encodeHTML(str) {
    return str.replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&#39;');
}