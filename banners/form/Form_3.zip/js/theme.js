// ====================================================
// ================ THEME MODE ========================
// ==================================================== 
document.addEventListener('DOMContentLoaded', () => {

    document.getElementById('toggleTheme').addEventListener('click', toggleTheme);

    // czy użytkownik wybrał motyw
    const savedTheme = localStorage.getItem('HEisTheme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }


    // ======== Tooltops =========
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
})


function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('HEisTheme', newTheme); // Zapamiętanie wyboru

    // Zmiana logo w zależności od wybranego motywu
    const logo = document.getElementById('logo');
    if (newTheme === 'dark') {
        logo.src = 'img/hussaria_electra_logo_white.png';
    } else {
        logo.src = 'img/hussaria_electra_logo_black.png';
    }
}
