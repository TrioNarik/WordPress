// ====================================================
// ================ THEME MODE ========================
// ==================================================== 
document.addEventListener('DOMContentLoaded', () => {

    document.getElementById('toggleTheme').addEventListener('click', toggleTheme);

    // Sprawdzamy, czy użytkownik wcześniej wybrał motyw
    const savedTheme = localStorage.getItem('HEisTheme');
    if (savedTheme) {
        document.documentElement.setAttribute('data-theme', savedTheme);
    }
})


function toggleTheme() {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('HEisTheme', newTheme); // Zapamiętanie wyboru

    // Zmiana logo w zależności od wybranego motywu
    const logo = document.getElementById('logo');
    if (newTheme === 'dark') {
        logo.src = 'img/he_logo.png';
    } else {
        logo.src = 'img/hussaria-electra-100x100.png';
    }
}