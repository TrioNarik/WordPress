// === Zmiana koloru testu personalizacji
document.querySelectorAll('.color-txt').forEach(item => {
    item.addEventListener('click', function(event) {
    event.preventDefault();
    let color = this.getAttribute('data-color');
    document.getElementById('selectedColorText').style.backgroundColor = color;
    // document.getElementById('dropdownButton').textContent = this.textContent;
    });
});