const textInput = document.getElementById("personalizationText");
const customText = document.getElementById("previewText");

// ✅ Aktualizuje tekst na SVG w czasie rzeczywistym
textInput.addEventListener("input", () => {
    customText.textContent = textInput.value || "Domyślny tekst";
});

// ✅ Event Delegation dla wyrównania tekstu
const textAlignList = document.getElementById("textAlignt");
textAlignList.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;

    // Pobranie wyrównania z data-align
    const align = button.getAttribute("data-align");
    setAlignment(align);

    // Zarządzanie klasą "active"
    textAlignList.querySelectorAll("button").forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");
});

// ✅ Event Delegation dla rozmiaru tekstu
const textSizeList = document.getElementById("textSize");
textSizeList.addEventListener("click", (event) => {
    const button = event.target.closest("button");
    if (!button) return;

    // Pobranie rozmiaru z data-size
    const size = button.getAttribute("data-size");
    setSize(size);

    // Zarządzanie klasą "active"
    textSizeList.querySelectorAll("button").forEach(btn => btn.classList.remove("active"));
    button.classList.add("active");
});

// ✅ Funkcja do ustawienia wyrównania tekstu
function setAlignment(align) {
    const alignments = {
        left: { anchor: "start", x: "25", y: "18", fontSize: "2", transform: "rotate(0.5 10 10) scale(1, 0.5)" },
        middle: { anchor: "middle", x: "52", y: "120", fontSize: "4", transform: "rotate(-0.8 10 10) scale(1, 0.5)" },
        right: { anchor: "end", x: "76", y: "18", fontSize: "2", transform: "rotate(0.5 10 10) scale(1, 0.5)" }
    };

    const props = alignments[align];
    if (props) {
        customText.setAttribute("text-anchor", props.anchor);
        customText.setAttribute("x", props.x);
        customText.setAttribute("y", props.y);
        customText.setAttribute("font-size", props.fontSize);
        customText.setAttribute("transform", props.transform);
    }
}

// ✅ Funkcja do ustawienia rozmiaru tekstu
function setSize(size) {
    const sizeSettings = {
        '2': { fontSize: '2', transform: "rotate(0.5 10 10) scale(1, 0.5)" },
        '4': { fontSize: '4', transform: "rotate(-0.8 10 10) scale(1, 0.5)" },
        '6': { fontSize: '6', transform: "rotate(0.5 10 10) scale(1, 0.5)" }
    };

    const settings = sizeSettings[size];
    if (settings) {
        customText.setAttribute("font-size", settings.fontSize);
        customText.setAttribute("transform", settings.transform);
    }
}
    
