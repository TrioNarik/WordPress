<?php
return [
    'languages' => [
        'pl' => [
            'name' => 'Polski',
            'iso'  => 'pl',
            'img'  => 'pl.png'
        ],
        'en' => [
            'name' => 'English',
            'iso'  => 'en',
            'img'  => 'en.png'
        ]
    ],
];
