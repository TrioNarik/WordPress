<?php
return [
    'title' => 'Orders - Hussaria Electra',
    'header' => 'Order form',
    'form' => [
        'person' => [
            'title' => 'Personal data',
            'fields' => [
                'first_name' => 'Name / Company',
                'last_name' => 'Name / Tax Identification Number',
                'email' => 'E-mail',
                'phone' => 'Phone',
            ],
        ],
        'address' => [
            'title' => 'Invoice address',
            'fields' => [
                'street' => 'Street and number',
                'post_code' => 'Zip code',
                'city' => 'City',
                'country' => 'Country',
            ],
        ],
        'shipping' => [
            'title' => 'Shipping address',
            'fields' => [
                'checkbox' => 'Another address',
                'street' => 'Street and number',
                'post_code' => 'Zip code',
                'city' => 'City',
                'country' => 'Country',
            ],
        ],
        'order' => [
            'title' => 'The order',
        ],
        'prepayment' => [
            'active' => 1,
            'title' => 'Payment',
            'fields' => [
                'checkbox' => 'Prepayment',
                'amount' => 'Prepayment amount',
                'cash' => [
                    'active' => 1,
                    'mode' => 'Cash',
                    'timing' => 0,
                    'status' => 'accept',
                ],
                'wire' => [
                    'active' => 1,
                    'mode' => 'Bank transfer',
                    'timing' => 14,
                    'status' => 'wait',
                ],
            ],
        ],
        'order_summary' => [
            'value' => 'Order value',
            'cost' => 'Shipping cost',
            'amount' => 'Amount to be paid',
            'button' => 'Order',
            'back' => 'Back',
            'notification' => 'The product has been added!',
            'confirm' => 'Thank you for ordering!',
        ],
    ],
    'settings' => [
        'currency' => 'EUR',
        'discount' => [
            'name' => 'Discount',
            'value' => 400,
        ],
        'fees' => [
            'name' => 'Fees' ,
            'value' => 50,
        ]
    ],
    //===============
    'package' => [
        'active' => 1,
        'name' => 'Electric tack locker',
        'desc' => 'A perfect solution for storing saddles and riding equipment for demanding competitors and equestrian enthusiasts. Equipped with large wheels and an electric drive, it eliminates physical effort and ensures easy maneuverability.',
        'rate' => '12 ratings',
        'volume' => 4.96,
        'status' => 'In stock',
        'deadline' => 'When the goods are not in stock, the delivery time is extended to 3-4 weeks',
        'weight' => [
            'name' => 'Weight (kg)',
            'value' => 84
        ],
        'height' => [
            'name' => 'Height (cm)',
            'value' => 150
        ],
        'width' => [
            'name' => 'Width (cm)',
            'value' => 66
        ],
        'load' => [
            'name' => 'Max load (kg)',
            'value' => 100
        ],
        'speed' => [
            'name' => 'Max speed (km/h)',
            'value' => 4.2
        ],
        'colors' => [
            'name' => 'Color',
            'palette' => [
                'black' => [
                    'name' => 'Black',
                    'ral' => 'RAL 9005',
                    'code' => '#151515',
                ] 
            ]            
        ],
        'materials' => [
            'name' => 'Materials used',
            'value' => 'Aluminum, powder coated'
        ],
        'equipment' => [
            'name' => 'Equipment',
            'value' => '5 bridle hangers with extendable rails'
        ],
        'wheels' => [
            'name' => 'Type of wheels',
            'value' => '2 fixed, 2 swivel with brake'
        ],
        'led' => [
            'name' => 'LED lights',
            'value' => 'YES'
        ],
        'drive' => [
            'name' => 'Electric drive',
            'value' => 'YES'
        ],

        'show_price' => 1,
        'price' => 546.00,
        'promo' => '',
        'shipping' => [
            'active' => 1,
            'free' => 0,
            'price' => 105,
            'promo' => '',
            'class' => '',
            'content' => 'Delivery costs from',
        ],
        'include' => [
            'intro_products' => 'Included',
            'products' => [
                'battery' => [
                    'active' => 1,
                    'name' => 'Akumulator',
                    'desc' => 'Pojemność: 4 Ah',
                    'image' => 'battery.png',
                ],
                'charger' => [
                    'active' => 1,
                    'name' => 'Ładowarka',
                    'desc' => 'Do akumulatora',
                    'image' => 'charger.png',
                ],
                'pomp' => [
                    'active' => 1,
                    'name' => 'Pompka elektryczna',
                    'desc' => 'Bezprzewodową z funkcją powerbanku',
                    'image' => 'pomp.png',
                ],
                'lock' => [
                    'active' => 1,
                    'name' => 'Ochronne zapięcie',
                    'desc' => 'Zewnętrzne na szyfr',
                    'image' => 'lock.png',
                ],
                'custom' => [
                    'active' => 1,
                    'name' => 'Personalizacja paki',
                    'desc' => 'Dowolny kolor i styl',
                    'image' => 'custom.png',
                ],
            ],
            'intro_widgets' => 'Gadgets',
            'widgets' => [
                'bag' => [
                    'active' => 1,
                    'name' => 'Torba',
                    'desc' => 'Materiałowa torba zakupowa',
                    'image' => 'bag.png',
                ],
                'cables' => [
                    'active' => 1,
                    'name' => 'Zestaw kabli',
                    'desc' => 'Zestaw kabli do ładowania telefonu 3w1',
                    'image' => 'cables.png',
                ],
                'hat' => [
                    'active' => 1,
                    'name' => 'Czapka',
                    'desc' => 'Stylowa czapka z daszkiem',
                    'image' => 'hat.png',
                ],
                'scissors' => [
                    'active' => 1,
                    'name' => 'Nożyczki',
                    'desc' => 'Nożyczki taktyczne z zestawem śrubokrętów',
                    'image' => 'scissors.png',
                ],
                'cup' => [
                    'active' => 1,
                    'name' => 'Kubek termiczny',
                    'desc' => 'Kubek termiczny typu Stanley z możliwością personalizacją',
                    'image' => 'cup.png',
                ],
                'pharmacy' => [
                    'active' => 1,
                    'name' => 'Apteczka',
                    'desc' => 'Przybornik medyczny',
                    'image' => 'pharmacy.png',
                ],
                'board' => [
                    'active' => 1,
                    'name' => 'Tablica',
                    'desc' => 'Magnetyczna tablica suchościeralna z kompletem akcesoriów',
                    'image' => 'board.png',
                ],
            ],

        ]
    ],
    // ==============
    'products' => [
        'battery' => [
            'active' => 1,
            'name' => 'Akumulator',
            'desc' => 'Dodatkowa moc - pojemność 5Ah',
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'battery_5ah.png',
            'show_price' => 1,
            'price' => 971.70,
            'shipping' => [
                'active' => 1,
                'free' => 1,
                'price' => 18,
                'class' => 'success',
                'content' => 'Dodstawa od',
            ],
        ],
        'charger' => [
            'active' => 1,
            'name' => 'ZESTAW BATERIA+ŁADOWARKA',
            'show_price' => 1,
            'price' => 553.50,
            'shipping' => [
                'active' => 1,
                'free' => 1,
                'price' => 200,
                'class' => 'dark',
                'content' => 'Dostawa: 0 PLN',
            ],
            'active' => 1,
            'name' => 'Akumulator',
            'desc' => 'Dodatkowa moc - pojemność 5Ah',
            'status' => 'W magazynie',
            'delivery' => 'Możliwa natychmiastowa wysyłka',
            'image' => 'battery_5ah.png',
            'show_price' => 1,
            'price' => 971.70,
            'shipping' => [
                'active' => 1,
                'free' => 1,
                'price' => 18,
                'class' => 'success',
                'content' => 'Dodstawa od',
            ],
        ],
        'ramp' => [
            'active' => 1,
            'name' => 'Trap załadunkowy',
            'show_price' => 1,
            'price' => 1476.00,
            'shipping' => [
                'active' => 1,
                'free' => 1,
                'price' => 200,
                'class' => '',
                'content' => 'Dostawa: 0 PLN',
            ],
        ],
        'tack_cover' => [
            'active' => 1,
            'name' => 'Pokrowiec na elektryczną pakę',
            'show_price' => 1,
            'price' => 2078.70,
            'shipping' => [
                'active' => 1,
                'free' => 0,
                'price' => 190,
                'class' => 'warning',
                'content' => 'Dostawa',
            ],
        ],
        'ramp_cover' => [
            'active' => 1,
            'name' => 'Pokrowiec na trap załadunkowy',
            'show_price' => 1,
            'price' => 479.70,
            'shipping' => [
                'active' => 0,
                'free' => 0,
                'price' => 200,
                'class' => '',
                'content' => '',
            ],
        ],
    ],
];