<?php
return [
    'title'                         => 'Заказы - Hussaria Electra',
    'header'                        => 'Форма заказа',
    // Dana personalne
    'form_block_person'             => 'Dane personalne',
    'form_label_first_name'         => 'Imię / Nazwa firmy',
    'form_label_last_name'          => 'Nazwisko / Numer NIP',
    'form_label_email'              => 'E-mail',
    'form_label_phone'              => 'Telefon',
    // Adres
    'form_block_address'            => 'Adres do faktury',
    'form_label_street'             => 'Ulica i numer',
    'form_label_post_code'          => 'Kod pocztowy',
    'form_label_city'               => 'Miejscowość',
    'form_label_country'            => 'Kraj',
    // Wysyłka
    'form_block_shipping'           => 'Adres do wysyłki',
    'form_label_shipping_checkbox'  => 'Inny adres',
    'form_label_shipping_street'    => 'Ulica i numer',
    'form_label_shipping_post_code' => 'Kod pocztowy',
    'form_label_shipping_city'      => 'Miejscowość',
    'form_label_shipping_country'   => 'Kraj',

    // Zamówienie
    'form_block_order'              => 'Szczegóły zamówienia',

    // Przedpłata
    'form_block_prepayment_active'  => 1,
    'form_block_payment'            => 'Płatność',
    'form_label_prepay_checkbox'    => 'Przedpłata',
    'form_label_prepay_amount'      => 'Kwota przedpłaty',
    'form_label_prepay_cash'                => [
        'active' => 1,
        'mode' => 'Gotówka/Płatność kartą',
        'timing' => 0,
        'status' => 'accept'
    ],
    'form_label_prepay_wire'                => [
        'active' => 1,
        'mode' => 'Przelew',
        'timing' => 14,
        'status' => 'wait'
    ],

    // Podsumowanie
    'form_block_order_value'        => 'Wartość zamówienia',
    'form_block_order_cost'         => 'Koszt dostawy',
    'form_label_prepay_checkbox'    => 'Przedpłata',
    'form_label_payment_amount'     => 'Pozostała kwota do zapłaty',
    'form_label_order_button'       => 'Cделать заказ',
    'form_label_back_button'        => 'Powrót',
    'form_label_order_confirm'      => 'Dziękujemy za zamówienie!',

    // Produkty[]
    'product_tack_locker'           => [
        'active'            => 1,
        'name'              => 'Elektryczna paka',
        'show_price'        => 1,
        'price'             => 24477.00,
        'currency'          => 'RUB',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'success',
            'content'   => 'Dostawa: 0 RUB'
        ]
    ],
    'product_tack_cover'            => [
        'active'        => 1,
        'name'          => 'Pokrowiec na elektryczną pakę',
        'show_price'    => 1,
        'price'         => 2078.70,
        'currency'      => 'RUB',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'warning',
            'content'   => 'Dostawa: 10% RUB'
        ]
    ],
    'product_tack_customization'    => [
        'active'        => 1,
        'name'          => 'Personalizacja',
        'show_price'    => 1,
        'price'         => 615.00,
        'currency'      => 'RUB',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'danger',
            'content'   => 'Dostawa: 200 RUB'
        ],
        'form_label'    => 'Dodatkowe uwagi'
    ],
    'product_battery'               => [
        'active'        => 1,
        'name'          => 'Akumulator 40V 4Ah',
        'show_price'    => 1,
        'price'         => 971.70,
        'currency'      => 'RUB',
        'shipping'          => [
            'active'    => 0,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'success',
            'content'   => 'Dostawa: 0 RUB'
        ]
    ],
    'product_charger'               => [
        'active'        => 1,
        'name'          => 'Ładowarka 40V 4A',
        'show_price'    => 1,
        'price'         => 553.50,
        'currency'      => 'RUB',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'dark',
            'content'   => 'Dostawa: 0 RUB'
        ]
    ],
    'product_ramp'                  => [
        'active'        => 1,
        'name'          => 'Trap załadunkowy',
        'show_price'    => 1,
        'price'         => 1476.00,
        'currency'      => 'RUB',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => '',
            'content'   => 'Dostawa: 0 RUB'
        ]
    ],
    'product_ramp_cover'            => [
        'active'        => 1,
        'name'          => 'Pokrowiec na trap załadunkowy',
        'show_price'    => 1,
        'price'         => 479.70,
        'currency'      => 'RUB',
        'shipping'          => [
            'active'    => 0,
            'free'      => 0,
            'price'     => 200,
            'class'     => '',
            'content'   => ''
        ]
    ],

];
