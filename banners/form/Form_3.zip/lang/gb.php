<?php
return [
    'title'                         => 'Orders - Hussaria Electra',
    'header'                        => 'Order form',
    // Dana personalne
    'form_block_person'             => 'Personal data',
    'form_label_first_name'         => 'First name / Company name',
    'form_label_last_name'          => 'Last name / Tax Identification Number',
    'form_label_email'              => 'E-mail',
    'form_label_phone'              => 'Phone',
    // Adres
    'form_block_address'            => 'Billing address',
    'form_label_street'             => 'Street',
    'form_label_post_code'          => 'Post code',
    'form_label_city'               => 'City',
    'form_label_country'            => 'Country',
    // Wysyłka
    'form_block_shipping'           => 'Shipping address',
    'form_label_shipping_checkbox'  => 'Another address',
    'form_label_shipping_street'    => 'Street',
    'form_label_shipping_post_code' => 'Post code',
    'form_label_shipping_city'      => 'City',
    'form_label_shipping_country'   => 'Country',

    // Zamówienie
    'form_block_order'              => 'Order details',

    // Przedpłata
    'form_block_prepayment_active'  => 1,
    'form_block_payment'            => 'Payment',
    'form_label_prepay_checkbox'    => 'Prepayment',
    'form_label_prepay_amount'      => 'Prepayment amount',
    'form_label_prepay_cash'                => [
        'active' => 1,
        'mode' => 'Cash',
        'timing' => 0,
        'status' => 'accept'
    ],
    'form_label_prepay_wire'                => [
        'active' => 1,
        'mode' => 'Wire',
        'timing' => 14,
        'status' => 'wait'
    ],

    // Podsumowanie
    'form_block_order_value'        => 'Order value',
    'form_block_order_cost'         => 'Koszt dostawy',
    'form_label_prepay_checkbox'    => 'Prepayment',
    'form_label_payment_amount'     => 'Remaining amount to be paid',
    'form_label_order_button'       => 'Order now',
    'form_label_back_button'        => 'Return',
    'form_label_order_confirm'      => 'Thank you for ordering!',

    // Produkty[]
    'product_tack_locker'           => [
        'active'            => 1,
        'name'              => 'Electric tack locker',
        'show_price'        => 1,
        'price'             => 4900,
        'currency'          => 'GBP',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'success',
            'content'   => 'Delivery: 250 GBP'
        ]
    ],
    'product_tack_cover'            => [
        'active'        => 1,
        'name'          => 'Tack locker cover',
        'show_price'    => 1,
        'price'         => 2078.70,
        'currency'      => 'GBP',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'class'     => 'warning',
            'content'   => 'Delivery: 5% GBP'
        ]
    ],
    'product_tack_customization'    => [
        'active'        => 1,
        'name'          => 'Customization',
        'show_price'    => 1,
        'price'         => 125.00,
        'currency'      => 'GBP',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'danger',
            'content'   => 'Delivery: 0 GBP'
        ],
        'form_label'    => 'Additional notes'
    ],
    'product_battery'               => [
        'active'        => 1,
        'name'          => 'Battery 40V 4Ah',
        'show_price'    => 1,
        'price'         => 971.70,
        'currency'      => 'GBP',
        'shipping'          => [
            'active'    => 0,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'success',
            'content'   => 'Delivery: 0 PLN'
        ]
    ],
    'product_charger'               => [
        'active'        => 1,
        'name'          => 'Charger 40V 4A',
        'show_price'    => 1,
        'price'         => 168.50,
        'currency'      => 'GBP',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'dark',
            'content'   => 'Delivery: 0 GBP'
        ]
    ],
    'product_ramp'                  => [
        'active'        => 1,
        'name'          => 'Loading ramp',
        'show_price'    => 1,
        'price'         => 1476.00,
        'currency'      => 'GBP',
        'shipping'          => [
            'active'    => 1,
            'free'      => 1,
            'price'     => 200,
            'class'     => 'secondary',
            'content'   => 'Delivery: 0 GBP'
        ]
    ],
    'product_ramp_cover'            => [
        'active'        => 1,
        'name'          => 'Ramp cover',
        'show_price'    => 1,
        'price'         => 479.70,
        'currency'      => 'GBP',
        'shipping'          => [
            'active'    => 0,
            'free'      => 0,
            'price'     => 200,
            'class'     => '',
            'content'   => ''
        ]
    ],

];
