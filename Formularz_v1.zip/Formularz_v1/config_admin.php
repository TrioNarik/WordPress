<?php
return [
    'admin' => [
        'mail' => 'admin@example.com',
        'secret_key' => 'fdc91d1b8d46eda896acf7ca3da923a1'
    ]
];
