<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zamówienia - Dynamiczny Formularz</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Formularz Zamówienia</h1>
        <form id="orderForm">
            <label>
                Imię i nazwisko:
                <input type="text" name="name" required>
            </label>
            <label>
                Firma:
                <input type="text" name="company">
            </label>
            <label>
                Adres:
                <input type="text" name="address">
            </label>
            <label>
                E-mail:
                <input type="text" name="email">
            </label>
            <label>
                Telefon:
                <input type="text" name="phone">
            </label>
            <label>
                <input type="checkbox" id="differentShippingAddress"> Inny adres wysyłki
            </label>
            <div id="shippingAddressField">
                <label for="shippingAddress">Adres wysyłki:</label>
                <input type="text" id="shippingAddress" name="shippingAddress" placeholder="Wprowadź adres wysyłki">
            </div>
            <h2>Produkty</h2>
            <div id="products">
                <label>
                    <input type="checkbox" name="product[]" value="Paka" data-price="100"> Paka 
                    <input type="number" class="product-price" data-product="Paka" value="100" min="0" step="10"> PLN
                </label>
                <label>
                    <input type="checkbox" name="product[]" value="Akumulator" data-price="50"> Akumulator 
                    <input type="number" class="product-price" data-product="Akumulator" value="50" min="0" step="10"> PLN
                </label>
                <label>
                    <input type="checkbox" name="product[]" value="Pokrowiec" data-price="30"> Pokrowiec 
                    <input type="number" class="product-price" data-product="Pokrowiec" value="30" min="0" step="10"> PLN
                </label>
            </div>

            <h3>Łączna wartość: <span id="totalPrice">0</span> PLN</h3>
            <button type="submit">Wyślij zamówienie</button>
        </form>
        <div id="confirmationMessage" style="display: none;">Dziękujemy za zamówienie!</div>
    </div>
    <script src="js/form.js"></script>
</body>
</html>
