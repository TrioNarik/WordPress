<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

// ===============================================
// Media pliki Front & BO => CSS/JS ==============
// ===============================================
function MKD_FRONT_CrossSellTrialsForWooCommerce_enqueue_styles() {
    wp_enqueue_style('mkd_cart-gratis-upsell-trial', plugin_dir_url(__FILE__) . 'assets/css/front_settings.css');
    
    wp_enqueue_script('mkd_cart-gratis-upsell-trial', plugin_dir_url(__FILE__) . 'assets/js/upsell-trial.js', array(), null, true);
}

add_action('wp_enqueue_scripts', 'MKD_FRONT_CrossSellTrialsForWooCommerce_enqueue_styles');


function MKD_ADMIN_CrossSellTrialsForWooCommerce_enqueue_admin_styles() {
    wp_enqueue_style('mkd_cart-gratis-upsell-trial-admin', plugin_dir_url(__FILE__) . 'assets/css/admin_settings.css');
}

add_action('admin_enqueue_scripts', 'MKD_ADMIN_CrossSellTrialsForWooCommerce_enqueue_admin_styles');
// ===============================================


// ===============================================
// Dodaj link do Ustawień wtyczki   ==============
// ===============================================
function MKD_add_settings_link_CrossSellTrialsForWooCommerce($links) {
    error_log('MKD_add_settings_link_CrossSellTrialsForWooCommerce Called!');
    $settings_link = '<a href="admin.php?page=mkd_cross-sell-trials_settings">' . __('Settings', 'mkd_cross-sell-trials-shopping-cart') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'MKD_add_settings_link_CrossSellTrialsForWooCommerce');


// ===============================================
// Settings Page pluginu =========================
// ===============================================
function MKD_add_settings_page_CrossSellTrialsForWooCommerce() {
    add_submenu_page(
        null, // page parent - null, aby ukryć w menu
        __('Settings ddddddddddWtyczki', 'mkd_cross-sell-trials-shopping-cart'), // page title
        __('Ustawienia ddddddddddd', 'mkd_cross-sell-trials-shopping-cart'), // menu title
        'manage_options', // capability
        'mkd_cross-sell-trials_settings', // Menu [Page settings] slug
        'render_strona_ustawien' // callback function
    );
}

add_action('admin_menu', 'MKD_add_settings_page_CrossSellTrialsForWooCommerce');



// Funkcja renderująca zawartość strony ustawień
function render_strona_ustawien() {
    ?>
    <div class="wrap">
        <h1>Ustawienia Wtyczki</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('plugin_settings');
            do_settings_sections('plugin_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}