<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


class MKD_Helper_CrossSellTrialsForWooCommerce {

    protected $plugin_version;
    protected $plugin_name;
    protected $plugin_url;
    protected $plugin_requires;
    protected $plugin_textDomain; // lang => KEY
    protected $plugin_pathDomain; // lang => DIR

    public function __construct($main_plugin_file) {
        // Pobierz informacje o wtyczce z pliku głównego
        $plugin_data = get_file_data($main_plugin_file, array(
            'Name' => 'Plugin Name',
            'Version' => 'Version',
            'URL' => 'Author URI',
            'Requires' => 'Requires',
            'Domain' => 'Text Domain',
            'DomainPath' => 'Domain Path',

        ));
    
        // Pobierz podstawowe informacje:
        $this->plugin_version    = $plugin_data['Version'];
        $this->plugin_name       = $plugin_data['Name'];
        $this->plugin_url        = $plugin_data['URL'];
        $this->plugin_requires   = $plugin_data['Requires'];
        $this->plugin_textDomain = $plugin_data['Domain'];
        $this->plugin_pathDomain = $plugin_data['DomainPath'];
    }


    /**
     * Pobierz wersję wtyczki
     *
     * @return string
     */
    public function get_plugin_version() {
        return $this->plugin_version;
    }

    /**
     * Pobierz nazwę wtyczki
     *
     * @return string
     */
    public function get_plugin_name() {
        return $this->plugin_name;
    }

    /**
     * Pobierz URL wtyczki
     *
     * @return string
     */
    public function get_plugin_url() {
        return $this->plugin_url;
    }

    /**
     * Pobierz Wymagania wtyczki
     *
     * @return string
     */
    public function get_plugin_requires() {
        return $this->plugin_requires;
    }

    /**
     * Pobierz Lang Key wtyczki
     *
     * @return string
     */
    public function get_plugin_textDomain() {
        return $this->plugin_textDomain;
    }

    /**
     * Pobierz Lang Dir wtyczki
     *
     * @return string
     */
    public function get_plugin_pathDomain() {
        return $this->plugin_pathDomain;
    }

    /**
     * Sprawdza, czy w WooCommerce zainstalowany
     *
     * @return bool True, jeśli dostępny WooComerce
     */
    function is_woocommerce_installed() {

        return class_exists('WooCommerce') && is_plugin_active('woocommerce/woocommerce.php');

    }
    
}