<?php
/**
 * Plugin Name: MKD · Cross-sell Trials in cart for WooCommerce
 * Description: Are you offering the best «Try Before You Buy» Model [TBYB]? To discover the exceptional quality of your products, suggest for you Customers a few additional product samples [or trials for Free] in the Shopping Cart by adding them to the current Orders. The benefits to consumers are immediate and obvious: the risks of purchasing an item sight/touch unseen are eliminated. It’s time to re-evaluate your strategy and make sure you’re offering the best possible shopping experience to your Customers.
 * Version: 2.0.4
 * Author: MKDnet
 * Author URI:
 * Text Domain: mkd_cross-sell-trials-shopping-cart
 * Domain Path: languages
 * Requires: WooCommerce plugin [version 5.3 or higher]
 */


if (!defined('ABSPATH')) {
	exit();
}


// ===============================================
// Załaduj podstawowe pliki ======================
// ===============================================
function MKD_include_files_CrossSellTrialsForWooCommerce() {
    if ( is_admin() ) {
        require_once(plugin_dir_path(__FILE__) . 'includes/Helpers/plugin-info.php');
        require_once(plugin_dir_path(__FILE__) . 'includes/Helpers/functions.php');

    }
}

add_action('plugins_loaded', 'MKD_include_files_CrossSellTrialsForWooCommerce');


// ===============================================
// Wymagania wtyczki =============================
// ===============================================
function MKD_no_woocommerce_display_message_CrossSellTrialsForWooCommerce() {
    
    // Sprawdź, czy WooCommerce jest zainstalowane
    $helper = new MKD_Helper_CrossSellTrialsForWooCommerce(__FILE__);

    if (!$helper->is_woocommerce_installed()) {

        echo '<div class="notice notice-error"><p>';
        echo '<strong>'. __($helper->get_plugin_name(), 'mkd_cross-sell-trials-shopping-cart') .' '. __('has been deactivated', 'mkd_cross-sell-trials-shopping-cart'). '!</strong> ' . __('Please install and activate', 'mkd_cross-sell-trials-shopping-cart') . ' ' . $helper->get_plugin_requires();
        echo '</p></div>';

        // Wyłącz wtyczkę
        deactivate_plugins(plugin_basename(__FILE__));
    }
}
// Wyłącz plugin z powiadomieniem, jeśli WooCommerce nie jest zainstalowane
add_action('admin_notices', 'MKD_no_woocommerce_display_message_CrossSellTrialsForWooCommerce');


// ===============================================
// Multi-lang ====================================
// internacjonalizacja (i18n) => __('', key) || _e('', key) || esc_html_e('', key) - może zawierać fragmenty HTML
// ===============================================
function MKD_CrossSellTrialsForWooCommerce_load_textdomain() {

    $helper = new MKD_Helper_CrossSellTrialsForWooCommerce(__FILE__);

    // Key, który jest identyfikatorem (domeną tekstową => Text Domain), false = pliki tłumaczeń są w katalogu wtyczki, motywu (true)
    load_plugin_textdomain($helper->get_plugin_textDomain(), false, dirname(plugin_basename(__FILE__)) . '/' . $helper->get_plugin_pathDomain());

    // define( 'TRANSLATE_KEY', $helper->get_plugin_textDomain() );
    
}

add_action('plugins_loaded', 'MKD_CrossSellTrialsForWooCommerce_load_textdomain');





// ===============================================
// Dodaj link do Ustawień wtyczki   ==============
// ===============================================
function MKD_add_settings_link_CrossSellTrialsForWooCommerce($links) {
    $settings_link = '<a href="admin.php?page=mkd_cross-sell-trials_settings">' . __('Settings', 'mkd_cross-sell-trials-shopping-cart') . '</a>';
    array_push($links, $settings_link);
    return $links;
}

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'MKD_add_settings_link_CrossSellTrialsForWooCommerce');


// ===============================================
// Settings Page pluginu =========================
// ===============================================
function MKD_add_settings_page_CrossSellTrialsForWooCommerce() {
    add_submenu_page(
        null, // page parent - null, aby ukryć w menu
        __('Settings ddddddddddWtyczki', 'mkd_cross-sell-trials-shopping-cart'), // page title
        __('Ustawienia ddddddddddd', 'mkd_cross-sell-trials-shopping-cart'), // menu title
        'manage_options', // capability
        'mkd_cross-sell-trials_settings', // Menu [Page settings] slug
        'render_strona_ustawien' // callback function
    );
}

add_action('admin_menu', 'MKD_add_settings_page_CrossSellTrialsForWooCommerce');



// Funkcja renderująca zawartość strony ustawień
function render_strona_ustawien() {
    ?>
    <div class="wrap">
        <h1>Ustawienia Wtyczki</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('plugin_settings');
            do_settings_sections('plugin_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// Dodaj ustawienia do panelu administracyjnego
function dodaj_ustawienia_ukrywania_probek() {
    add_settings_section('plugin_settings', 'Ustawienia Wtyczkifgfgfgfgffgfgfg', 'ustawienia_opis', 'plugin_settings');
    add_settings_field('ukrywana_kategoria', 'Kategoria do ukrycia', 'wybierz_kategorie', 'plugin_settings', 'plugin_settings');
    add_settings_field('minimalna_kwota_zakupow', 'Minimalna kwota zakupów dla darmowych próbek', 'ustaw_minimalna_kwote', 'plugin_settings', 'plugin_settings');
    add_settings_field('ilosc_probek_do_wyboru', 'Ilość próbek do wyboru', 'ustaw_ilosc_probek', 'plugin_settings', 'plugin_settings');
    add_settings_field('ilosc_probek_do_wyswietlenia', 'Ilość próbek do wyświetlenia na stronie produktu', 'ustaw_ilosc_probek_do_wyswietlenia', 'plugin_settings', 'plugin_settings');
    register_setting('plugin_settings', 'ukrywana_kategoria');
    register_setting('plugin_settings', 'minimalna_kwota_zakupow');
    register_setting('plugin_settings', 'ilosc_probek_do_wyboru');
    register_setting('plugin_settings', 'ilosc_probek_do_wyswietlenia');
}

// Opis sekcji ustawień
function ustawienia_opis() {
    echo '<p>Wybierz kategorię, którą chcesz ukryć z widoku sklepu.</p>';
}




// Pole wyboru kategorii
function wybierz_kategorie() {
    $kategorie = get_categories(array('taxonomy' => 'product_cat', 'hide_empty' => false));
    $ukrywana_kategoria = get_option('ukrywana_kategoria');
     ?>
    <select name="ukrywana_kategoria">
        <option value="">Wybierz kategorię</option>
        <?php
        foreach ($kategorie as $kategoria) {
            echo '<option value="' . esc_attr($kategoria->slug) . '" ' . selected($ukrywana_kategoria, $kategoria->slug, false) . '>' . esc_html($kategoria->name) . '</option>';
        }
        ?>
    </select>
    <?php
}

// Pole wprowadzania minimalnej kwoty zakupów
function ustaw_minimalna_kwote() {
    $minimalna_kwota = get_option('minimalna_kwota_zakupow');
    ?>
    <input type="number" name="minimalna_kwota_zakupow" value="<?php echo esc_attr($minimalna_kwota); ?>" placeholder="Podaj minimalną kwotę zakupów">
    <?php
}

// Pole wprowadzania ilości próbek do wyboru
function ustaw_ilosc_probek() {
    $ilosc_probek = get_option('ilosc_probek_do_wyboru');
    ?>
    <input type="number" name="ilosc_probek_do_wyboru" value="<?php echo esc_attr($ilosc_probek); ?>" placeholder="Ilość próbek do wyboru">
    <?php
}

// Pole wprowadzania ilości próbek do wyświetlenia na stronie produktu
function ustaw_ilosc_probek_do_wyswietlenia() {
    $ilosc_probek_do_wyswietlenia = get_option('ilosc_probek_do_wyswietlenia');
    ?>
    <input type="number" name="ilosc_probek_do_wyswietlenia" value="<?php echo esc_attr($ilosc_probek_do_wyswietlenia); ?>" placeholder="Ilość próbek do wyświetlenia na stronie produktu">
    <?php
}

add_action('admin_init', 'dodaj_ustawienia_ukrywania_probek');

// Funkcja ukrywająca produkty na podstawie ustawień
function ukryj_produkty_probek($query) {
    if (!is_admin() && $query->is_main_query()) {
        $ukrywana_kategoria = get_option('ukrywana_kategoria');
        $minimalna_kwota = (float)get_option('minimalna_kwota_zakupow');
        $ilosc_probek_do_wyboru = (int)get_option('ilosc_probek_do_wyboru');
        $ilosc_probek_do_wyswietlenia = (int)get_option('ilosc_probek_do_wyswietlenia');

        if (!empty($ukrywana_kategoria)) {
            $tax_query = $query->get('tax_query');

            if (!$tax_query) {
                $tax_query = array();
            }

            $tax_query[] = array(
                'taxonomy' => 'product_cat',
                'field' => 'slug',
                'terms' => array($ukrywana_kategoria),
                'operator' => 'NOT IN',
            );

            $query->set('tax_query', $tax_query);
        }

        if ($minimalna_kwota > 0 && WC()->cart->subtotal < $minimalna_kwota) {
            // Jeśli kwota zakupów jest poniżej minimalnej, nie dodawaj próbek
            WC()->session->__unset('wybrane_probki');
        }

        // Ustaw ilość próbek do wyboru i wyświetlenia
        WC()->session->set('ilosc_probek_do_wyboru', $ilosc_probek_do_wyboru);
        WC()->session->set('ilosc_probek_do_wyswietlenia', $ilosc_probek_do_wyswietlenia);

        // Aktualizuj niestandardowe pole koszyka z informacjami o wybranych próbkach
        $wybrane_probki = WC()->session->get('wybrane_probki');
        // Dodaj kod do aktualizacji niestandardowego pola koszyka na podstawie wyboru próbek
    }
}

add_action('pre_get_posts', 'ukryj_produkty_probek');

// Funkcja dodająca przycisk do dodawania próbek na stronie koszyka
function dodaj_przycisk_dodawania_probek() {
    $ilosc_probek_do_wyswietlenia = WC()->session->get('ilosc_probek_do_wyswietlenia');
    $ilosc_probek_do_wyboru = WC()->session->get('ilosc_probek_do_wyboru');
    $ukrywana_kategoria = get_option('ukrywana_kategoria');

    echo '<div class="woocommerce-message">';
    echo '<p>Darmowe próbki dostępne! Wybierz ' . $ilosc_probek_do_wyboru . ' z ' . $ilosc_probek_do_wyswietlenia . ' dostępnych próbek.</p>';
    echo '</div>';

    // Dodaj kod do wyświetlania przycisku na stronie koszyka
    ?>
    <form method="post" action="">
        <?php
        for ($i = 1; $i <= $ilosc_probek_do_wyboru; $i++) {
            echo '<label for="probka_' . $i . '">Próbka ' . $i . ': </label>';
            echo '<select name="wybrane_probki[]" id="probka_' . $i . '" class="probka-select">';
            // Pobierz dostępne próbki
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'product_cat' => $ukrywana_kategoria,
            );
            $probki = new WP_Query($args);
            while ($probki->have_posts()) {
                $probki->the_post();
                $product_id = get_the_ID();
                echo '<option value="' . $product_id . '">' . get_the_title() . '</option>';
            }
            wp_reset_query();
            echo '</select>';
            echo '<br>';
        }
        ?>
        <input type="submit" name="dodaj_probki_do_koszyka" value="Dodaj do koszyka">
    </form>
    <?php
}

add_action('woocommerce_before_cart', 'dodaj_przycisk_dodawania_probek');

// Funkcja obsługująca dodawanie próbek do koszyka
function dodaj_probki_do_koszyka() {
    if (isset($_POST['dodaj_probki_do_koszyka'])) {
        $wybrane_probki = isset($_POST['wybrane_probki']) ? array_map('intval', $_POST['wybrane_probki']) : array();
        WC()->session->set('wybrane_probki', $wybrane_probki);

        foreach ($wybrane_probki as $probka_id) {
            $product = wc_get_product($probka_id);
            if ($product) {
                WC()->cart->add_to_cart($probka_id);
            }
        }
    }
}

add_action('init', 'dodaj_probki_do_koszyka');
